# The look, the pace and the self-check

Measured from the leading channel's most-viewed episode (frame by frame, 21 Oct 2026). We learn the technique (timing,
camera grammar, light); every character, set and story stays our own. Nothing confirms how the viral channels make
their videos: never say or imply they're made with any tool.

## Pace, long form

| | The genre | Our targets |
|---|---|---|
| Chapter 1 (cold open) | about 27 cuts a minute | 26 or more; median shot 1.5 to 2.5 s |
| Chapters 2 to 8 | slower in the middle, bursts on each demo | 14 to 24 cuts a minute; median 2 to 3 s |
| Long holds | up to about 12 s, always with action inside | over 4.2 s gets an automatic punch-in; nothing over 6 s (schematics 9) |
| Re-hooks | a change of promise every minute or so | a chapter card and an open loop every 45 to 80 s |

- Cuts come from **changing shot size**, not motion: wide, then an insert, then a medium, then a close-up of a face,
  then a reaction. No two neighbours share a recipe and set (check.py warns).
- **Punch-ins** (plan.py): a shot held past 4.2 s is split on a word into a second segment 22% closer. It reads as a
  cut, costs nothing to draw, and keeps the middle of a long video moving. Turn off per shot with `"punch": false`.
- Cut on the word: every shot starts 2 frames before its `say` words.

## Light does most of the work

- A dusk palette (purple to orange sky, a low sun) by day; deep blue with lamps and screens at night.
- **Every light comes from something you can see:** a window with the sun in it, a pendant, a lamp, string lights,
  streetlamps, a lit doorway, city windows. Pools of light, dark corners. The sets do this for you.
- A warm rim light on every character on the lit side; red on the turn (`mood.red` above 0.5 switches it).
- Haze, dust in the beams, soft bokeh; blurred dark foregrounds (`"foreground"`, `ots`); soft sets behind close-ups.
- Grain and a soft vignette finish every frame.

## Shot vocabulary

- **Establishing wide** (`wide`, `reveal`): the whole lit place, people small in it. Open every new place on one.
- **Medium** and **close-up**: the acting. **Extreme close-up** (`xcu`): realisations, fear, the glint.
- **Insert** and **top-down**: an object huge in frame, a hand reaching in. Use them for every important object.
- **Over the shoulder** (`ots`): conversations and confrontations.
- **Low angle** (`lowangle`): power, triumph, a threat against the sky.
- **Schematic**: the science; one idea per shot, numbers counting, a stamp.
- **Title card** (end of chapter 1) and **chapter cards** (start of chapters 2 to 8).

## Characters

- Mostly three-quarter (`face` left or right), rarely to camera; the near hand does the acting.
- They act with poses and faces: a pose change every second or two in a busy shot, holds in between. Faces swap through
  a blink, never morph.
- Life comes from around them too: the camera move, dust, steam, a punch-in, a flash, a mark.
- One hero who never changes (Pip, `pipHood`). Every costume is a look on one rig, so nobody drifts off-model.

## On-screen text

Almost none: the title, the chapter cards, the schematic labels, and small marks (a chip, a tag, a stamp). No speech
bubbles, no captions of the voice (captions go in captions.srt for YouTube instead).

## The storyboard self-check (step 6)

Open `out/<slug>/chNN/storyboard.jpg`, then every still in `board/` at full size. For each shot:

1. **One read in a second.** At phone size, who and what is clear without the voice. If not: closer recipe, fewer props.
2. **Sizes change.** No two neighbours share a recipe and set; the chapter has wides, mediums, close-ups and an insert.
3. **The character is in frame and in the light.** Head not cut off, not behind a prop or the island; the face is the
   brightest thing near it. Fix with `at`, `face`, or a different recipe.
4. **Props sit on things.** On an anchor, in a hand, or on an insert's surface; nothing floating (unless the power
   holds it in the air on purpose).
5. **Continuity.** The same people in the same places through a scene; the same set for one location.
6. **The power reads.** The look (chip, tint) on every paused shot; the glint when it switches on; the world frozen
   (`freeze`) while the hero moves.
7. **Text is short and spelled right.** Titles 26 characters or fewer a line, marks 18, diagram lines 22.
8. **Ours.** Nothing resembles a famous character, a channel's hero, a real person or a brand.

Write down what fails, fix chapter.json, run `plan.py`, re-render just those stills
(`node stills.mjs <slug> N S3 S7`), rebuild the sheet, look again. When it passes: `"board_ok": true`.

## The motion check (optional, recommended for chapter 1)

`python render.py <slug> N --draft` then `python motiongrid.py <slug> N --draft`. Read the grids like a flipbook: poses
change with an overshoot, walks move the feet, nothing pops, the action lands on its words.
