# Running this with a free model (OpenCode)

A 7 to 10 minute episode is about 25 small jobs. Free models do each job well when the job is small, the format is
fixed, and a checker says exactly what's wrong. This engine is built that way: you write JSON only, every step has a
checker, and `status.py` always knows the next step. Follow these rules and a free model makes the same episode a big
model does; it just takes more sessions.

## The loop

```
/wi-next <slug>        (or: python <skill>/scripts/status.py <slug>, then do what NEXT says)
```
Do ONE step. Run its checker. Fix. Run status again. Repeat. That's it.

- **One session per chapter** (or two chapters at most). Start a fresh session for the next chapter: the files hold
  all the state, and status.py tells the new session where things are. Long sessions fill the context and free models
  start forgetting the rules.
- **Read before writing.** Before the script: the chapter's entry in outline.json. Before the shots: recipes.md and
  the same chapter of the example (`episodes/pause/chNN/chapter.json`).
- **Copy, then change.** Copy a shot from the example that does something similar, then change the set, the cast and
  the `say`. Don't invent field names.
- **Write shots in batches of 6 to 10**, then run check.py. Easier to fix than 30 at once.
- **Don't edit generated files** (words.json, timeline.json, index.tsx, episodes/index.ts). Re-run the script instead.

## The commands (in OpenCode)

| Command | Does |
|---|---|
| `/wi-new <topic>` | starts an episode: outline skeleton, then fills it, then checks it |
| `/wi-next <slug>` | does exactly the next step from status.py, then stops |
| `/wi-chapter <slug> <n>` | takes chapter n from script to approved storyboard and sound |
| `/wi-finish <slug>` | renders and masters, then reports |

Install: copy `opencode/commands/*.md` into your project's `.opencode/commands/`.

## Model settings

- Use the strongest free model OpenCode offers at the time, with reasoning set high (in OpenCode: `/models`, then
  Ctrl+T for the reasoning level). The original skill was tested with GLM-5.3-Flash Free in October 2026.
- If a model keeps failing a step, switch model for that step only: the files don't care who wrote them.

## When things go wrong

| Symptom | Fix |
|---|---|
| check.py: `"say": "..." was not found` | copy the first 2 to 4 words of the line exactly from the script; shots must go in spoken order |
| plan.py: a shot "would start at ... not after ..." | two shots name the same words, or a shot's words come before the previous shot's |
| the chapter runs long or short | voice.py prints the length against the target: cut or add lines, then re-run voice.py and plan.py |
| a still looks wrong | fix the shot in chapter.json, `plan.py`, then `stills.mjs <slug> N S4` for just that shot |
| a number is blocked | put the fact in outline.json "science" with its working and source first |
| edge-tts fails | check the connection; or `"voice": {"provider": "kokoro"}` (offline); or `--provider draft` to keep planning |
| render is slow | normal: render one chapter at a time (`render.py <slug> 3`), overnight for the rest; it resumes |
| lost track | `status.py <slug>` |

## Prompts that work

Starting a chapter's script:
> Read outline.json chapter 3 (beat, goal, open_loop) and the end of chapter 2's script. Write chapter 3's "script"
> in chapter.json: 5 to 8 entries, second person, 3 to 12 words a sentence, every sentence a picture, about 180 words,
> the first line answering chapter 2's open loop, the last line the open loop from the outline. Then run check.py.

Writing shots:
> Read references/recipes.md and episodes/pause/ch03/chapter.json. For chapter 3 of <slug>, write shots S2 to S10 for
> the first lines of the script. One shot per sentence or picture, "say" = its first words exactly, sizes changing every
> cut, the power's look and "freeze": 0 while it runs. Then run check.py <slug> 3 and fix every error.

Self-check:
> Open out/<slug>/ch03/storyboard.jpg and each still in board/. For each shot, answer the 8 checklist questions in
> look.md. List the failures, fix them in chapter.json, re-run plan.py and stills.mjs for those shots, and look again.
