# The long-form What If formula

The original skill decoded the What If channels' scripts (Ifverse, FunNotSoFun, IFinity, Could've Been Tales, 21 Oct
2026): **the full episodes run 7 to 10 minutes and hit all seven beats.** The short engine made the cold open of one
(beats 1 to 4 squeezed into 20 seconds). This engine makes the whole thing: the seven beats, each given room, as 8
chapters of about a minute. The formula is shared; the stories are ours.

## The seven beats as 8 chapters (about 8 minutes)

| # | Chapter | Beat | Seconds | Words | What happens | Ends on (open loop) |
|---|---|---|---|---|---|---|
| 1 | Cold open | 1 | 40-50 | 100-130 | 3 or 4 quick demos of the power, each with its word (small and selfish, useful, clever, a little uncanny), then the title card | "It sounds perfect. But nobody told you the rules." |
| 2 | The rules | 2 | 50-65 | 130-170 | how it started (a specific ordinary morning), the rules, the first test, a laugh | "But there was a fourth rule." |
| 3 | The fun part | 3 | 65-80 | 170-210 | escalating everyday wins: school, queues, homework, a friend, a prank. The best minute | "And that's when Mo noticed." |
| 4 | Too far | 3b | 45-60 | 120-160 | greed: bigger and bolder; the first small sign of the cost (foreshadow) | "And you'd been pausing a lot." |
| 5 | The catch | 4 | 60-75 | 160-200 | the real science with real numbers ("That's real."), then what it means for you | "And it gets worse. Because someone was watching." |
| 6 | Someone noticed | 5 | 55-65 | 140-170 | a man in a suit, a car outside, an offer that is really a threat | "Then he mentioned your sister." |
| 7 | The choice | 6 | 50-65 | 130-170 | family at stake (the little sister); the cost of saving her; the choice | the power's word, whispered |
| 8 | The ending | 7 | 45-60 | 120-160 | the choice plays out, a twist, a question for the comments, "Part 2" | a question, never an answer |

The words budget is 2.6 words a second after the pauses are tightened. Under 7 minutes? Add a demo, a fun beat or a
consequence. Over 10? Cut the weakest win in chapter 3.

## Retention: why long form needs more than the short form

Long videos lose viewers in the middle, not at the start. The fixes are structural, and the engine builds most of
them in:

- **The hook is the first 15 seconds.** No intro, no logo: chapter 1 starts on the first demo. The title card lands at
  the end of the cold open, after the viewer has already learned the grammar of the power.
- **Re-hook every 60 to 90 seconds.** Every chapter ends on an open loop (a question, a threat, "but...") and the next
  chapter opens on a chapter card that names what's coming. That's the long-form version of a pattern interrupt: a
  change of picture, sound (a riser and a boom) and promise at the moment attention dips.
- **Return to the premise.** The power's word, its sound and its look come back in every chapter, so the throughline
  stays visible past minute 8. Say the word on its own shot.
- **Progressive rhythm.** Fast at the start (26+ cuts a minute in chapter 1), calmer in the middle (14 to 20) with
  bursts of quick cuts on each demo and each reveal, then fast again for the climax. plan.py prints the pace per
  chapter and adds punch-ins to any shot held over 4 seconds.
- **Escalate inside every chapter.** Small, then bigger, then a little wrong. The last win in a chapter should make the
  viewer slightly uneasy: it sets up the next chapter.
- **Pay off every loop you open.** A loop that never pays off costs trust. The first line of each chapter answers the
  last line of the one before.
- **One real fact, with a number, checked.** It's what makes the genre more than a cartoon. "That's real." straight
  after it, and the sources in the description.

## Writing rules

- **Second person, short sentences, every sentence a picture.** "You knock a glass off the table. Pause." beats
  "Imagine if you were able to stop time whenever you wanted."
- **3 to 12 words a sentence.** check.py flags anything over 16.
- **The power has a word, a sound and a look.** Say the word in every demo; the engine plays its sound and look.
- **Dialogue is rare and short,** in the narrator's voice: "Interesting thing, time, he said." No speech bubbles.
- **No real people, brands or famous characters.** The cast is ours: Pip (you), Mo (best friend), the sister, Mum, the
  man in the suit.
- **Numbers only from "science".** Work the arithmetic in outline.json first (claim, working, source), then use the
  number in the script. Never round a number into a different claim. check.py enforces it.
- **End on a question,** never a resolution: "So who else can pause? Tell me in the comments."

## Choosing a topic

- An everyday power with clear rules and a hidden cost: time (pause, rewind, skip), copies, senses (hear thoughts, see
  an hour ahead), body (never sleep, ten times faster), money, luck.
- The cost should come from real science (energy, biology, physics, economics), so chapter 5 can teach something true.
- It must carry 8 minutes: does it have 6 everyday wins, a real cost, a reason someone powerful would care, and a way
  to put family at risk? If not, pick another.
- Don't remake a channel's episode: search YouTube for the premise first, and change the power or the rule if it
  exists. Most powers have been done somewhere; the story, the rule and the turn are what make it ours.

## The outline, filled in

See `studio/src/episodes/pause/outline.json`: every field filled, 8 chapters, 6 science facts with their working.
