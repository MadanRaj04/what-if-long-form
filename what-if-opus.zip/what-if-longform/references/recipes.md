# Shots as JSON: the recipe language

Every shot in a chapter is one JSON object in `chapter.json` "shots". The recipe engine draws it, lights it, frames it
and moves the camera; you only say what's in it. Only use the names on this page: `check.py` rejects anything else and
tells you the allowed values.

The smallest shot:
```json
{"id": "S5", "recipe": "closeup", "set": "kitchen", "say": "You take it back.", "cast": [{"who": "pipHood"}]}
```

A typical shot:
```json
{"id": "S3", "recipe": "medium", "set": "kitchen", "say": "Pause.", "look": "pause", "freeze": 0, "key": 14,
 "note": "the world stops; Pip's eyes light up",
 "cast": [{"who": "pipHood", "at": [0.45, 0.4], "face": "right", "act": [[0, "reach"], [10, "point"]],
           "expr": [[0, "shock"], [10, "smug"]], "glint": [2, 1]}],
 "props": [{"kind": "glass", "at": [1130, 640], "rot": 55}]}
```

## Fields every shot has

| Field | What | Example |
|---|---|---|
| `id` | S1, S2, S3... in order (S3b to slot one in later) | `"S7"` |
| `recipe` | the framing, see below | `"medium"` |
| `set` | where, see below (not needed for insert, topdown, schematic) | `"street"` |
| `say` | the first 2 to 5 words of the line the shot starts on, **exactly as in the script** (punctuation doesn't matter). The shot cuts in on those words | `"Your bus is pulling"` |
| `key` | the frame of the shot the storyboard shows (when the action has happened) | `14` |
| `note` | what we see, in a few words (goes on the storyboard) | `"the traffic stops dead"` |

Frames: 30 a second. A shot's own clock starts at 0 when it cuts in. `act`, `expr`, `t`, `paste`, `glint` are frames
on that clock. Most shots last 45 to 90 frames: put actions at 4 to 20 so they happen while the shot is up.

## Recipes (the framing)

| Recipe | What it is | Needs |
|---|---|---|
| `wide` | the whole set, everyone in it small | set |
| `medium` | waist up on the first cast member | set, cast |
| `closeup` | head and shoulders, the set soft behind | set, cast |
| `xcu` | the face fills the frame | set, cast |
| `twoshot` | two people, framed together | set, 2 cast |
| `ots` | over the shoulder: a big dark blurred head in front, the first cast member beyond | set, cast |
| `lowangle` | looking up at someone (on rooftop or sky: against the sky) | set, cast |
| `walk` | the camera follows the first cast member walking | set, cast with `walk` |
| `reveal` | a wide that pulls out | set |
| `insert` | a surface filling the frame, props on it, an arm reaching in | `props` with screen `at` |
| `topdown` | straight down on a surface (papers, a desk), slowly turning | `props` with screen `at` |
| `title` | a wide with the title card | set, `title` (2 lines) |
| `chapter` | the chapter card over the blurred set | `title`: ["PART 3", "THE NAME"] |
| `schematic` | the science diagram | `diagram` |

Default camera moves are built in (wides and mediums push in slowly, walks follow, reveals pull out), so a shot is
never static. Change with `"camera"`.

## Sets

| Set | What | Slots for people | Prop anchors |
|---|---|---|---|
| `study` | dusk, desk with laptop and lamp, window, bookcase | left, center, right (behind the desk) | desk, desk2, floor |
| `studyNight` | the study at night, moonlight, the desk lamp | same | desk, desk2, floor |
| `kitchen` | dusk, island with stools, fridge, window | left, center, right (behind the island) | island, island2, counter, floor |
| `bedroom` | night, bed, nightstand lamp and clock, window | left, center, right, **bed** (sitting up in bed) | nightstand, bed, floor |
| `classroom` | board, windows, rows of kids | left, center, right (front of class); [0.3, 0.2] is at the board | desk, board, floor |
| `stairwell` | side-on stairs, upper landing, bottom landing | landing (=left), stairs (=center), bottom (=right) | landing, bottom, step |
| `rooftop` | dusk sky, big sun, city, string lights | farLeft, left, center, right, farRight | deck, deck2, parapet |
| `office` | night, the suit's desk, blinds, filing cabinets | left, center, right (behind the desk); [0.5, 0.72] in front of it | desk, floor |
| `street` | dusk street, shops, cars, streetlamps, bench | farLeft, left, center, right, farRight | bench, ground |
| `sky` | open sky and skyline, for "you" moments | farLeft, left, center, right, farRight | ground |
| `schematic` | the blueprint grid (use the schematic recipe) | | |

`at` can also be exact: rooms take `[u, w]` (u across 0..1, w toward camera 0..1, e.g. `[0.36, 0.4]`); flat sets
(stairwell, rooftop, street, sky) take `[x]` in world units (0..1920, e.g. `[1560]`). Keep the same person in the
same place across the shots of one scene (continuity).

Set options (`"opts"`): bedroom `clock` ("03:00"), `lamp` (0..1); classroom `board` ("E = mc\u00b2"), `laugh` (0..1);
rooftop `sunY`, `clock` (true: a clock in the sun), `blackout` [0, 1, 8, 40], `lightsOut`, `cityLit`; street `night`
(true), `traffic` (false), `blackout`; study `desk` (false), `shelf` (0..1); kitchen `island` (false); office
`lamp`, `desk` (false). Values in [from, to, startFrame, endFrame] form animate.

## Cast

`"cast": [{"who": "pipHood", "at": "left", "face": "right", "act": [[0, "idle"], [8, "point"]], "expr": [[0, "neutral"], [8, "smug"]]}]`

| Field | Values |
|---|---|
| `who` | `pipHood` (the hero, "you"), `mo` (best friend), `sis` (little sister: add `"scale": 0.72`), `mom`, `suit` (the man in the suit), `pip`, `pipInk` (hero variants) |
| `at` | a slot or exact position (see Sets) |
| `face` | `left`, `right`, `camera` (which way they look; default: toward the middle) |
| `act` | poses over time: `idle`, `point`, `cheer`, `shrug`, `think`, `shock`, `wave`, `reach`, `lean` (smug lean back), `present` (ta-da), `fist` (determined), `scared`, `sad`, `hold` (holding something), `stop` (palm out), `sit` |
| `expr` | faces over time: `neutral`, `happy`, `smug`, `shock`, `worried`, `oops`, `cool` (shades on), `dizzy`, `tired` |
| `walk` | `{"to": "right", "from": 0, "dur": 60}`: walks from `at` to `to` |
| `glint` | `[frame, strength]`: the power lights the eyes (`"glintColor": "#FF5A4A"` for a villain) |
| `frozen` | `true`: stops with the world on a `freeze` shot |
| `paste` | a frame: appears with the power's pop (copies, summons) |
| `blur` | `true`: big, dark and blurred in front of camera |
| `scale` | size multiplier (`0.72` for a child, `1.1` for someone grown) |

Each pose change gets anticipation, overshoot and settle; faces swap through a blink; everyone breathes and blinks.

## Props

`"props": [{"kind": "mug", "at": "desk"}, {"kind": "phone", "at": "hand", "s": 0.5, "on": 1}]`

Kinds: `cookie`, `cookieTop`, `cookies` (a stack, `n`), `mug`, `glass`, `plate`, `plateTop`, `paper` (`done`, `grade`,
`fill`), `papers` (`n`), `phone` (`on`, `caller`, `buzz`), `book` (`turn`), `books` (`n`), `clock` (`text`), `calendar`
(`n` crossed days), `pizza` (`bite`), `pizzaBox`, `ball`, `cat` (`mood`: sleep, alert, peek), `laptop`, `cash` (`n`),
`envelope`, `badge`, `box`.

| Field | What |
|---|---|
| `at` | a set anchor (table above), `"hand"` (the near hand of cast `hand`, default 0), or `[x, y]`. In `insert`/`topdown`, `[x, y]` on screen (1920 x 1080) |
| `s` | size multiplier. Inserts want 1.5 to 4 |
| `t` / `paste` / `drop` | appears at that frame: a pop / the power's pop and ring / falls into place |
| `rot`, `on`, `bite`, `fill`, `turn`, `buzz` | numbers, or [from, to, startFrame, endFrame] to animate |
| `back` | draw behind the people |
| `glitch` | a flickering ghost copy |
| `live` | keeps moving on a `freeze` shot |

## Marks on screen (`"ui"`)

`"ui": [{"kind": "marquee", "target": "prop0", "t": 8}, {"kind": "tag", "target": "cast0", "text": "A+", "mark": "check", "t": 4}]`

Kinds: `marquee` (a selection box), `tag` (a short value, `mark`: check or x), `toast` (COPIED, SAVED), `float` (+1,
x10), `sparkle`, `rings` (a realisation), `dizzy`, `question` (a big ? over a head), `label` (a mono label), `stamp`
("THAT'S REAL", "CLASSIFIED"), `hud` (a chip with `icon`: pause, rewind, copy, paste, skip, dot), `dial` (`count`:
[from, to, f0, f1] and `unit`), `gauge` (`p`), `arrow` (target [x0, y0, x1, y1]).
`target`: `"cast0"`, `"head0"`, `"prop0"` (the first of each), or a screen point `[x, y]` or box `[x, y, w, h]`.
Text on screen stays short (18 characters or fewer). The genre keeps text off the picture: no captions of the voice,
no speech bubbles.

## The power

- `"look": "pause"`: the look from outline.json "looks" runs while this shot is up (grade, chip, frame, tint).
- `"freeze": 0`: the world stops (set, props, cast marked `frozen`); everyone else keeps moving. A time power.
- `glint` on the hero when it switches on; `paste` on props or cast for things that appear; `marquee` to pick things.
- Say the power's word on its own shot ("Pause." gets a medium or close-up with the glint).

## The science beat (`schematic`)

```json
{"id": "S4", "recipe": "schematic", "say": "Light moves", "key": 50,
 "diagram": {"layout": "count", "heading": "THE SPEED OF LIGHT", "count": {"to": 299792, "label": "KILOMETRES EVERY SECOND", "t": 6, "dur": 36}}}
```

| Layout | Fields |
|---|---|
| `equation` | `items`: 1 to 3 of `{"text", "sub", "icon"}`, joined by arrows (A -> B -> C) |
| `count` | `count`: `{"to", "from", "label", "suffix", "format": comma, short, time, decimal, "t", "dur"}` |
| `icons` | `icons`: `{"icon", "n" (up to 30), "label"}`: a grid lighting up |
| `compare` | `bars`: up to 4 of `{"label", "value", "display"}` |
| `timeline` | `items`: up to 6 points along a line |
| `list` | `items`: up to 6 ticked lines |

Any layout also takes `heading`, `dial` (`{"to", "unit": "min", "label"}`) and `stamp` + `stampT` ("THAT'S REAL" at
frame stampT). Icons: tower, wind, solar, dam, factory, person, clock, bolt, heart, eye, globe, cookie, coin, brain,
sun, moon, house, car, phone, drop. Keep each text 22 characters or fewer. Every number shown must be in outline
"science".

## Inserts and top-downs

```json
{"id": "S4", "recipe": "insert", "surface": "stone", "say": "It just hangs", "props": [{"kind": "glass", "at": [960, 520], "s": 2.4}],
 "arm": {"from": "right", "keys": [[0, 1600, 300], [16, 1040, 430]], "point": false}}
```
`surface`: wood, stone (kitchen), paper. `arm`: a sleeve and mitten reaching in from `from` (left, right, top, bottom);
`keys` are [frame, x, y] of the hand on screen; `point` true (finger) or false (open hand); `who` for the sleeve's
colours. Bring the arm in from the side the character is on in the neighbouring shots.

## Camera

`"camera": {"move": "pushIn", "amount": 1.5}`. Moves: static, pushIn, pullOut, panLeft, panRight, tiltUp, handheld,
follow, crashZoom (a fast punch in for a shock). Also `zoom` (frame closer: 1.5), `dx`/`dy` (shift in world units),
`roll` (a few degrees of dutch angle for unease).

## Mood

`"mood": {"red": 0.6}` floods the shot red (the turn; animate with [0, 0.7, 0, 30]); `"dim": 0.3` darkens it.
`"foreground": "left" | "right" | "bottom" | "both"` adds a dark blurred shape near camera for depth.

## Chapter extras

- `"fx"`: one-frame flashes and shakes on cues: `{"at": "S3", "kind": "flash", "color": "#DDF2FF", "o": 0.5}`,
  `{"at": "S9+4", "kind": "shake", "len": 8, "amp": 10}`.
- `"punch": false` on a shot stops the automatic punch-in (plan.py splits holds over 4.2 s into a second, closer cut).
- `"edit"`: cut by hand for reversals and cut-backs (rare): see plan.py.
- `"custom": true`: draw the shot yourself in `chNN/shots.tsx` (see kit.md). scaffold.py makes the stub.
