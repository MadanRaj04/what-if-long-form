"""Step 2 (per chapter): the voice. Text to speech with word timings, then the pauses tightened to the genre's pace.

    python <skill>/scripts/voice.py <slug> <chapter> [--force]
    python <skill>/scripts/voice.py <slug> all
    python <skill>/scripts/voice.py <slug> 3 --provider draft     (override the provider for this run)

Providers (outline.json "voice": {"provider": ...}; a chapter can override it with its own "voice"):
  edge        FREE, online, no key: Microsoft Edge's read-aloud voices via the edge-tts package (pip install edge-tts),
              with word timings. Default voice en-US-AndrewMultilingualNeural, "rate": "+6%". Check its terms before
              you monetise.
  kokoro      FREE, offline, Apache-2.0 model: pip install kokoro soundfile (and espeak-ng). Word timings built in.
              Voices: am_michael, am_adam, af_heart, bm_george...  Good for a monetised channel.
  elevenlabs  Paid (credits), needs ELEVENLABS_API_KEY. The original engine's voice.
  file        Your own recording: put it at public/<slug>/chNN/take.wav (or .mp3) and the words are aligned to it.
  draft       Offline placeholder: a soft tone per word at the right pace, so you can plan and board a chapter
              before the real voice. Replace it before the final render (status.py reminds you).

Writes public/<slug>/chNN/voice.wav, src/episodes/<slug>/chNN/words.json and out/<slug>/chNN/words_raw.json.
The call is cached by text + voice settings, so re-running to retune "gaps" or "lead" is free and offline.

chapter.json (all optional): "gaps": {"word": 0.12, "comma": 0.22, "sentence": 0.34, "question": 0.5, "pairs": {"real|So": 0.6}},
"lead": seconds of silence before the first word (default 1.8 when the chapter opens on a chapter card, else 0.15).
"""
import asyncio, base64, hashlib, json, re, sys, time

import numpy as np

from wi import (SR, SKILL, text_sha, api, ch_dir, chapter_text, decode, has_todo, load_chapter, load_json, load_outline, log_cost, need_studio, norm,
                out_dir, pub_dir, save_json, write_wav, WPS, chapters)
from align import attach, align, tokens

need_studio()
PROV = sys.argv[sys.argv.index('--provider') + 1] if '--provider' in sys.argv else None
args = [a for a in sys.argv[1:] if not a.startswith('--') and a != PROV]
if len(args) < 2:
    raise SystemExit('usage: voice.py <slug> <chapter number | all> [--force]')
slug = args[0]
force = '--force' in sys.argv
outline = load_outline(slug)
todo = chapters(slug) if args[1] == 'all' else [int(args[1])]

DEFAULTS = {
    'edge': {'voice': 'en-US-AndrewMultilingualNeural', 'rate': '+6%', 'pitch': '+0Hz'},
    'kokoro': {'voice': 'am_michael', 'speed': 1.05, 'lang': 'a'},
    'elevenlabs': {'voice': 'TX3LPaxmHKxFdv7VOQHJ', 'model': 'eleven_multilingual_v2', 'settings': {'stability': 0.4, 'similarity_boost': 0.8, 'style': 0.35, 'use_speaker_boost': True}},
    'file': {}, 'draft': {},
}


def settings_for(ch):
    v = dict(outline.get('voice', {}))
    v.update(ch.get('voice', {}))
    prov = PROV or v.get('provider', 'edge')
    if prov not in DEFAULTS:
        raise SystemExit(f'Unknown voice provider "{prov}". Use one of: {", ".join(DEFAULTS)}')
    out = dict(DEFAULTS[prov])
    if not PROV or PROV == v.get('provider', 'edge'):
        out.update({k: val for k, val in v.items() if k != 'provider'})
    out['provider'] = prov
    return out


# ---------------------------------------------------------------- providers: each returns (audio_path, words or None)
def tts_edge(text, V, raw):
    try:
        import edge_tts
    except ImportError:
        raise SystemExit('The free edge voice needs the edge-tts package: pip install edge-tts   (or set "provider": "kokoro" or "draft")')

    async def run():
        kw = dict(rate=V.get('rate', '+0%'), pitch=V.get('pitch', '+0Hz'))
        try:
            c = edge_tts.Communicate(text, V['voice'], boundary='WordBoundary', **kw)
        except TypeError:  # edge-tts before 7.0 sent word boundaries by default
            c = edge_tts.Communicate(text, V['voice'], **kw)
        audio, words = bytearray(), []
        async for chunk in c.stream():
            if chunk['type'] == 'audio':
                audio.extend(chunk['data'])
            elif chunk['type'] == 'WordBoundary':
                s = chunk['offset'] / 1e7
                words.append({'w': chunk['text'], 's': s, 'e': s + chunk['duration'] / 1e7})
        return bytes(audio), words

    for attempt in range(3):
        try:
            audio, words = asyncio.run(run())
            break
        except Exception as e:
            if attempt == 2:
                raise SystemExit(f'edge-tts failed three times ({e}). Check your connection, or use "provider": "kokoro" (offline) or "draft".')
            time.sleep(3 + attempt * 4)
    p = raw.with_suffix('.mp3')
    p.write_bytes(audio)
    return p, (attach(words, text) if words else None)


def tts_kokoro(text, V, raw):
    try:
        from kokoro import KPipeline
    except ImportError:
        raise SystemExit('The kokoro voice needs: pip install kokoro soundfile  (and espeak-ng on the system). Or use "provider": "edge".')
    pipe = KPipeline(lang_code=V.get('lang', 'a'))
    sr = 24000
    chunks, words, offset = [], [], 0.0
    for res in pipe(text, voice=V['voice'], speed=float(V.get('speed', 1.0))):
        audio = res.audio
        if audio is None:
            continue
        a = audio.detach().cpu().numpy() if hasattr(audio, 'detach') else np.asarray(audio)
        for tk in (res.tokens or []):
            st, en = getattr(tk, 'start_ts', None), getattr(tk, 'end_ts', None)
            if st is None or en is None or not re.search(r'\w', tk.text or ''):
                continue
            words.append({'w': tk.text, 's': offset + float(st), 'e': offset + float(en)})
        chunks.append(a)
        offset += len(a) / sr
    y = np.concatenate(chunks) if chunks else np.zeros(sr)
    p = raw.with_suffix('.wav')
    write_wav(p, y, sr=sr)
    return p, (attach(words, text) if words else None)


def tts_elevenlabs(text, V, raw, n):
    t0 = time.time()
    res = json.loads(api(f'/v1/text-to-speech/{V["voice"]}/with-timestamps?output_format=mp3_44100_128', {'text': text, 'model_id': V['model'], 'voice_settings': V['settings']}))
    p = raw.with_suffix('.mp3')
    p.write_bytes(base64.b64decode(res['audio_base64']))
    al = res['alignment']
    words, cur = [], None
    for ch, s, e in zip(al['characters'], al['character_start_times_seconds'], al['character_end_times_seconds']):
        if re.match(r"[\w'\u2019]", ch):
            if cur is None:
                cur = {'w': '', 's': s, 'e': e}
            cur['w'] += ch
            cur['e'] = e
        elif cur is not None:
            words.append(cur)
            cur = None
    if cur:
        words.append(cur)
    log_cost(slug, f'voice ch{n:02d}', len(text), f'{len(text)} characters (credits are about 0.2 to 0.45 a character: check the usage page)')
    return p, attach(words, text)


def tts_file(text, V, raw, n):
    for ext in ('wav', 'mp3', 'm4a', 'flac'):
        p = pub_dir(slug, n) / f'take.{ext}'
        if p.exists():
            return p, None
    raise SystemExit(f'No recording: put your take at {pub_dir(slug, n)}/take.wav (or .mp3), reading the chapter script exactly.')


def tts_draft(text, V, raw):
    toks = tokens(text)
    words, t = [], 0.3
    for tk in toks:
        d = 0.1 + 0.047 * len(tk['w'])
        words.append({'w': tk['w'], 's': round(t, 3), 'e': round(t + d, 3), 'p': tk['p']})
        t += d + (0.45 if re.search(r'[.?!]', tk['p']) else 0.22 if re.search(r'[,:;\u2014-]', tk['p']) else 0.045)
    y = np.zeros(int((t + 0.4) * SR))
    for k, w in enumerate(words):
        a, b = int(w['s'] * SR), int(w['e'] * SR)
        tt = np.arange(b - a) / SR
        y[a:b] += 0.12 * np.sin(2 * np.pi * (180 + 30 * (k % 4)) * tt) * np.sin(np.pi * tt / max(1e-3, tt[-1] if len(tt) else 1))
    p = raw.with_suffix('.wav')
    write_wav(p, y)
    return p, words


# ---------------------------------------------------------------- per chapter
def do_chapter(n):
    ch = load_chapter(slug, n)
    text = chapter_text(ch)
    if not text or has_todo(ch.get('script', [])):
        raise SystemExit(f'Chapter {n}: the script still has TODOs or is empty. Write the lines in {ch_dir(slug, n)}/chapter.json, then run check.py.')
    V = settings_for(ch)
    prov = V['provider']
    sig = hashlib.sha1(json.dumps([text, V], sort_keys=True).encode()).hexdigest()[:12]
    od = out_dir(slug, n)
    meta = load_json(od / 'voice_meta.json', {})
    raw_words = od / 'words_raw.json'
    raw_audio = meta.get('raw')
    if force or meta.get('sig') != sig or not raw_audio or not (pub_dir(slug, n) / raw_audio).exists() or not raw_words.exists():
        nwords = len(text.split())
        print(f'chapter {n}: {nwords} words, {len(text)} characters -> {prov} ({V.get("voice", "")})')
        raw = pub_dir(slug, n) / 'voice_raw'
        if prov == 'edge':
            path, words = tts_edge(text, V, raw)
        elif prov == 'kokoro':
            path, words = tts_kokoro(text, V, raw)
        elif prov == 'elevenlabs':
            path, words = tts_elevenlabs(text, V, raw, n)
        elif prov == 'file':
            path, words = tts_file(text, V, raw, n)
        else:
            path, words = tts_draft(text, V, raw)
        if not words:
            words = align(path, text)
        save_json(raw_words, words)
        save_json(od / 'voice_meta.json', {'sig': sig, 'raw': path.name, 'provider': prov, 'chars': len(text), 'draft': prov == 'draft', 'text': text_sha(text)})
        raw_audio = path.name
    else:
        print(f'chapter {n}: voice unchanged, reusing it (no call)')
    # ---- tighten the pauses (as the genre does) and put the lead-in silence in front
    words = load_json(raw_words)
    G = {'word': 0.12, 'comma': 0.22, 'sentence': 0.34, 'question': 0.5, 'pairs': {}}
    G.update(outline.get('gaps', {}))
    G.update(ch.get('gaps', {}))
    x = decode(pub_dir(slug, n) / raw_audio)
    bare = lambda w: re.sub(r'[^\w]', '', w)
    cuts = []
    for a, b in zip(words, words[1:]):
        gap = b['s'] - a['e']
        key = bare(a['w']) + '|' + bare(b['w'])
        if key in G['pairs']:
            keep = G['pairs'][key]
        elif '?' in a['p'] or '!' in a['p']:
            keep = G['question']
        elif any(c in a['p'] for c in '.:;\u2026'):
            keep = G['sentence']
        elif any(c in a['p'] for c in ',\u2014-'):
            keep = G['comma']
        else:
            keep = G['word']
        if gap > keep:
            mid = (a['e'] + b['s']) / 2
            rm = gap - keep
            cuts.append((mid - rm / 2, mid + rm / 2))
    # trim the head and tail silence too
    head = max(0.0, words[0]['s'] - 0.05) if words else 0.0
    tail_end = (words[-1]['e'] + 0.25) if words else len(x) / SR
    parts, last = [], head
    for s, e in cuts:
        parts.append(x[int(last * SR):int(s * SR)])
        last = e
    parts.append(x[int(last * SR):int(min(len(x) / SR, tail_end) * SR)])
    fade = int(0.004 * SR)
    for i, part in enumerate(parts):
        part = part.copy()
        if len(part) > 2 * fade:
            if i > 0:
                part[:fade] *= np.linspace(0, 1, fade)
            if i < len(parts) - 1:
                part[-fade:] *= np.linspace(1, 0, fade)
        parts[i] = part
    y = np.concatenate(parts) if parts else x
    shots = ch.get('shots') or []
    lead = float(ch.get('lead', 1.8 if (shots and shots[0].get('recipe') == 'chapter') else 0.15))
    y = np.concatenate([np.zeros(int(lead * SR)), y])
    write_wav(pub_dir(slug, n) / 'voice.wav', y)

    def shift(t):
        return t - head - sum(min(e, t) - s for s, e in cuts if t > s) + lead

    out = [{'w': w['w'], 's': round(shift(w['s']), 3), 'e': round(shift(w['e']), 3), 'p': w.get('p', '')} for w in words]
    save_json(ch_dir(slug, n) / 'words.json', out)
    secs = len(y) / SR
    target = next((c.get('seconds') for c in outline.get('chapters', []) if int(c['n']) == n), None)
    pace = len(out) / max(0.1, secs - lead)
    print(f'chapter {n}: tightened {len(cuts)} pauses -> {secs:.1f} s with a {lead:.1f} s lead-in ({pace:.2f} words/s)' + (f'; target {target} s' if target else ''))
    if target and abs(secs - target) > target * 0.25:
        print(f'  ! {secs:.0f} s is far from the {target} s planned: '
              + ('cut lines (or raise "rate")' if secs > target else 'add a line or two, or a beat of silence with "pairs"'))
    if prov == 'draft':
        print('  (draft voice: fine for planning and the storyboard; switch the provider and re-run before sound and render)')


for n in todo:
    do_chapter(n)
print(f'next: python {SKILL}/scripts/plan.py {slug} {todo[0] if len(todo) == 1 else "all"}')
