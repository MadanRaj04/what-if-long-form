"""Step 5 (per chapter): the storyboard sheet. Lays the board stills out as one captioned contact sheet: shot, recipe,
start time, the words over it, and the note. This is what gets reviewed (by you, then by the person) before sound
and the render.

    python <skill>/scripts/board.py <slug> <chapter> [--cols 3]

Reads out/<slug>/chNN/board/<shot>.png (stills.mjs) and the chapter's timeline.json. Writes out/<slug>/chNN/storyboard.jpg.
"""
import pathlib, sys

from PIL import Image, ImageDraw, ImageFont

from wi import SKILL, STUDIO, ch_dir, load_json, load_outline, need_studio, out_dir, save_json

need_studio()
args = [a for a in sys.argv[1:] if not a.startswith('--')]
slug, n = args[0], int(args[1])
cols = int(sys.argv[sys.argv.index('--cols') + 1]) if '--cols' in sys.argv else 3
tl = load_json(ch_dir(slug, n) / 'timeline.json')
outline = load_outline(slug)
src = out_dir(slug, n) / 'board'


def font(size, bold=True):
    cands = [STUDIO / 'public' / 'fonts' / 'board.ttf', STUDIO / 'public' / 'fonts' / 'board.otf']
    cands += [pathlib.Path(p) for p in ['C:/Windows/Fonts/segoeuib.ttf' if bold else 'C:/Windows/Fonts/segoeui.ttf', 'C:/Windows/Fonts/arialbd.ttf',
                                         '/System/Library/Fonts/Supplemental/Arial Bold.ttf', '/System/Library/Fonts/Helvetica.ttc',
                                         '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']]
    for c in cands:
        if c.exists():
            return ImageFont.truetype(str(c), size)
    return ImageFont.load_default()


head, body, note = font(34), font(28), font(23, False)
W, H, CAP, PAD = 960, 540, 160, 24
shots = tl['shots']
rows = (len(shots) + cols - 1) // cols
sheet = Image.new('RGB', (cols * W + (cols + 1) * PAD, rows * (H + CAP + PAD) + PAD + 90), (20, 17, 26))
d = ImageDraw.Draw(sheet)
d.text((PAD, 26), f'{outline.get("youtube_title", slug)}  \u00b7  chapter {n}: {tl.get("title", "")}  \u00b7  {tl["total"] / tl["fps"]:.1f} s, {len(tl["segments"])} cuts', font=head, fill=(246, 239, 227))


def fit(text, f, width):
    words, lines, cur = text.split(), [], ''
    for w in words:
        t = (cur + ' ' + w).strip()
        if d.textlength(t, font=f) <= width:
            cur = t
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    if len(lines) > 2:
        lines = lines[:2]
        lines[1] = lines[1][: max(0, len(lines[1]) - 2)] + '\u2026'
    return lines


for i, s in enumerate(shots):
    x = PAD + (i % cols) * (W + PAD)
    y = 90 + PAD + (i // cols) * (H + CAP + PAD)
    p = src / f'{s["id"]}.png'
    if p.exists():
        sheet.paste(Image.open(p).convert('RGB').resize((W, H)), (x, y))
    else:
        d.rectangle([x, y, x + W, y + H], fill=(60, 30, 40))
        d.text((x + 20, y + 20), f'missing {p.name}: run stills.mjs', font=body, fill=(255, 120, 120))
    d.rectangle([x, y + H, x + W, y + H + CAP], fill=(32, 27, 40))
    d.text((x + 18, y + H + 12), f'{i + 1}  {s["id"]}  {s["size"].upper()}', font=head, fill=(255, 177, 90))
    at = f'{s["first"] / tl["fps"]:.1f} s'
    d.text((x + W - 18 - d.textlength(at, font=note), y + H + 20), at, font=note, fill=(170, 160, 185))
    line = f'"{s["line"]}"' if s.get('line') else '(no words)'
    yy = y + H + 58
    for ln in fit(line, body, W - 36):
        d.text((x + 18, yy), ln, font=body, fill=(246, 239, 227))
        yy += 34
    if s.get('note'):
        d.text((x + 18, yy + 2), fit(s['note'], note, W - 36)[0], font=note, fill=(170, 160, 185))
out = out_dir(slug, n) / 'storyboard.jpg'
sheet.save(out, quality=86)
save_json(out_dir(slug, n) / 'board_meta.json', {'src': tl.get('src', '')})
print(out, sheet.size)
print(f'next: look at it and every still against the checklist in {SKILL}/references/look.md; fix, re-render those shots, '
      f'then set "board_ok": true in chapter.json')
