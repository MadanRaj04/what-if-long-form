"""Step 7 check (per chapter): is every word clear of the effects and the music? Measures the stems at their mix
volumes in 0.4 s windows and lists the spoken moments where effects or music come within `margin` dB of the voice.
Fix a flagged moment by lowering or moving that event (sound "events", or "levels"), then re-run sfx.py.

    python <skill>/scripts/mixcheck.py <slug> <chapter | all> [--margin 3]
"""
import sys

import numpy as np

from wi import SR, ch_dir, chapters, decode, load_json, need_studio, stem

need_studio()
args = [a for a in sys.argv[1:] if not a.startswith('--')]
slug = args[0]
todo = chapters(slug) if args[1] == 'all' else [int(args[1])]
margin = float(sys.argv[sys.argv.index('--margin') + 1]) if '--margin' in sys.argv else 3.0


def db(x):
    return 20 * np.log10(np.sqrt(np.mean(x ** 2)) + 1e-9)


for n in todo:
    tl = load_json(ch_dir(slug, n) / 'timeline.json')
    A = tl['audio']
    stems = {k: decode(stem(slug, n, k)) * A.get(f'{k}Vol', 1) for k in ['voice', 'sfx', 'music'] if stem(slug, n, k) and A.get(k)}
    if 'voice' not in stems:
        print(f'chapter {n}: no voice stem yet')
        continue
    m = min(len(x) for x in stems.values())
    W = int(0.4 * SR)
    starts = range(0, m - W, W // 2)
    levels = [db(stems['voice'][i:i + W]) for i in starts]
    loud = [v for v in levels if v > -60]
    speaking = float(np.percentile(loud, 70)) - 8 if loud else -30
    flags = []
    for i, v in zip(starts, levels):
        if v < speaking:
            continue
        for k in ['sfx', 'music']:
            if k in stems:
                o = db(stems[k][i:i + W])
                if o > v - margin:
                    fr = int(i / SR * tl['fps'])
                    shot = next((s['shot'] for s in tl['segments'] if s['a'] <= fr < s['b']), '?')
                    flags.append((round(i / SR, 1), shot, k, round(o - v, 1)))
    mix = sum(x[:m] for x in stems.values())
    print(f'chapter {n}: {len(flags)} moments where effects or music come within {margin:g} dB of the voice (time s, shot, stem, dB over the voice)')
    for f in flags[:40]:
        print('   ', f)
    if len(flags) > 40:
        print(f'    ... and {len(flags) - 40} more: lower "sfx_lu" in "levels" by 2 to 3 and re-run sfx.py')
    print(f'  mix peak before mastering: {np.abs(mix).max():.3f}' + ('  (ok)' if np.abs(mix).max() < 1 else '  ! over 1.0: lower the levels'))
