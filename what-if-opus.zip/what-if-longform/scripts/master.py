"""Step 9: the master and everything you upload with it.

    python <skill>/scripts/master.py <slug>

From out/<slug>/<slug>-raw.mp4 (render.py), writes:
  <slug>-final.mp4    the mix brought to -14 LUFS with true peaks under -1 dBTP (two-pass loudnorm, video untouched)
  captions.srt        subtitles from the voice's word timings (upload them: YouTube indexes captions)
  chapters.txt        YouTube chapter timestamps (paste into the description; the first is 0:00)
  description.md      a ready description: the hook, the chapters, the sources for every fact, the question
  report.json         length, loudness, pace per chapter, costs
"""
import json, re, subprocess, sys

from wi import SKILL, ch_dir, chapters, duration, load_chapter, load_json, load_outline, loudness, need_studio, out_dir, save_json

need_studio()
slug = sys.argv[1]
outline = load_outline(slug)
od = out_dir(slug)
raw = od / f'{slug}-raw.mp4'
final = od / f'{slug}-final.mp4'
if not raw.exists():
    raise SystemExit(f'No {raw}: run python {SKILL}/scripts/render.py {slug} first.')

I, TP, LRA = -14.0, -1.5, 11
first = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(raw), '-af', f'loudnorm=I={I}:TP={TP}:LRA={LRA}:print_format=json', '-f', 'null', '-'],
                       capture_output=True, text=True, encoding='utf-8', errors='ignore').stderr
m = json.loads(first[first.rfind('{'):first.rfind('}') + 1])
filt = (f"loudnorm=I={I}:TP={TP}:LRA={LRA}:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}"
        f":measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', str(raw), '-c:v', 'copy', '-af', filt, '-ar', '48000', '-c:a', 'aac', '-b:a', '256k', '-movflags', '+faststart', str(final)], check=True)
lufs, _ = loudness(final)
tp = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(final), '-af', f'loudnorm=I={I}:TP={TP}:print_format=json', '-f', 'null', '-'],
                    capture_output=True, text=True, encoding='utf-8', errors='ignore').stderr
true_peak = float(json.loads(tp[tp.rfind('{'):tp.rfind('}') + 1])['input_tp'])
dur = duration(final)

# ---------------------------------------------------------------- chapter start times (from the chapter renders)
starts, t, pace = {}, 0.0, {}
for n in chapters(slug):
    starts[n] = t
    v = od / 'chapters' / f'ch{n:02d}.mp4'
    tl = load_json(ch_dir(slug, n) / 'timeline.json', {})
    t += duration(v) if v.exists() else tl['total'] / tl['fps']
    pace[n] = round((len(tl['segments']) - 1) / (tl['total'] / tl['fps']) * 60, 1)


def stamp(s, srt=False):
    if srt:
        ms = int(round(s * 1000))
        return f'{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}'
    s = int(s)
    return f'{s // 3600}:{s // 60 % 60:02d}:{s % 60:02d}' if s >= 3600 else f'{s // 60}:{s % 60:02d}'


# ---------------------------------------------------------------- captions
cues = []
for n in chapters(slug):
    words = load_json(ch_dir(slug, n) / 'words.json', [])
    cur = []
    for w in words:
        cur.append(w)
        text = ' '.join(x['w'] + x.get('p', '') for x in cur)
        end_sentence = bool(re.search(r'[.?!]', w.get('p', '')))
        if len(text) > 38 or cur[-1]['e'] - cur[0]['s'] > 2.6 or end_sentence:
            cues.append((starts[n] + cur[0]['s'], starts[n] + cur[-1]['e'] + 0.15, text))
            cur = []
    if cur:
        cues.append((starts[n] + cur[0]['s'], starts[n] + cur[-1]['e'] + 0.15, ' '.join(x['w'] + x.get('p', '') for x in cur)))
srt = []
for i, (a, b, text) in enumerate(cues):
    b = min(b, cues[i + 1][0] - 0.02) if i + 1 < len(cues) else b
    srt.append(f'{i + 1}\n{stamp(a, True)} --> {stamp(b, True)}\n{text}\n')
(od / 'captions.srt').write_text('\n'.join(srt), encoding='utf-8')

# ---------------------------------------------------------------- YouTube chapters and the description
lines = []
for c in outline['chapters']:
    n = int(c['n'])
    lines.append(f"{stamp(starts[n])} {c['title']}")
(od / 'chapters.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
src = '\n'.join(f"- {s['claim']} ({s['source']})" for s in outline.get('science', []))
voice = outline.get('voice', {}).get('provider', 'edge')
desc = f"""{outline.get('youtube_title', outline.get('topic', ''))}

{outline.get('logline', '')}

{outline.get('end', {}).get('question', '')} Tell me in the comments.

Chapters
{chr(10).join(lines)}

Is any of this real? The science, worked out:
{src}

Animated in code (Remotion). Voice: {voice}. All characters and stories are original.
"""
(od / 'description.md').write_text(desc, encoding='utf-8')

costs = load_json(od / 'costs.json', [])
report = {'episode': outline['id'], 'file': str(final), 'minutes': round(dur / 60, 2), 'lufs': lufs, 'true_peak_dbtp': true_peak,
          'chapters': {f'ch{n:02d}': {'start': stamp(starts[n]), 'cuts_per_min': pace[n]} for n in chapters(slug)},
          'captions': len(cues), 'paid_credits': sum(c.get('credits', 0) for c in costs)}
save_json(od / 'report.json', report)
print(json.dumps(report, indent=1))
if not 7 <= dur / 60 <= 10.5:
    print(f'! {dur / 60:.1f} minutes: outside 7 to 10.')
print('loudness OK' if abs(lufs + 14) <= 0.5 and true_peak <= -1.0 else '! loudness off target: check the report')
thumb = od / 'thumbnail.png'
print(f'Upload: {final}\n  with captions.srt, chapters.txt (in the description), description.md' + (', thumbnail.png' if thumb.exists() else
      f'\n  thumbnail: node {SKILL}/scripts/stills.mjs {slug} --thumb'))
