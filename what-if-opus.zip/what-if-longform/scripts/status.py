"""Where is the episode, and what is the ONE next step? Run this at the start of every session (and whenever you're
unsure). It reads the files on disk, so it's always right, even after a crash or a new session with no memory.

    python <skill>/scripts/status.py <slug>

Stages per chapter: script -> voice -> shots -> plan -> board -> approved -> sound -> render. Then: master.
"""
import sys

from wi import SKILL, plan_src, ch_dir, chapter_fp, chapter_text, chapters, has_todo, load_chapter, load_json, load_outline, need_studio, out_dir, pub_dir, text_sha

need_studio()
if len(sys.argv) < 2:
    raise SystemExit('usage: status.py <slug>')
slug = sys.argv[1]
o = load_outline(slug)
S = f'python {SKILL}/scripts'

if has_todo(o):
    print(f'outline: has TODOs.\nNEXT: fill outline.json (read {SKILL}/references/formula.md), then: {S}/check.py {slug}')
    sys.exit(0)


def mtime(p):
    return p.stat().st_mtime if p.exists() else 0


rows, nxt = [], None
for n in chapters(slug):
    d = ch_dir(slug, n)
    stage, step = 'done', None
    if not (d / 'chapter.json').exists():
        stage, step = 'no files', f'{S}/new.py {slug} --chapters'
    else:
        ch = load_chapter(slug, n)
        meta = load_json(out_dir(slug, n) / 'voice_meta.json', {})
        tl = load_json(d / 'timeline.json', {}) or {}
        shots = [s for s in ch.get('shots', []) if s.get('recipe') != 'chapter']
        if has_todo(ch.get('script', [])) or not chapter_text(ch):
            stage, step = 'script', f'write chapter {n}\'s lines in {d}/chapter.json, then: {S}/check.py {slug} {n}'
        elif not (d / 'words.json').exists() or meta.get('text') != text_sha(chapter_text(ch)):
            stage, step = 'voice', f'{S}/voice.py {slug} {n}'
        elif not shots:
            stage, step = 'shots', f'write chapter {n}\'s shots (references/recipes.md), then: {S}/check.py {slug} {n} && {S}/plan.py {slug} {n}'
        elif tl.get('placeholder') or tl.get('src') != plan_src(slug, n):
            stage, step = 'plan', f'{S}/check.py {slug} {n} && {S}/plan.py {slug} {n}'
        elif load_json(out_dir(slug, n) / 'board_meta.json', {}).get('src') != tl.get('src'):
            stage, step = 'board', f'node {SKILL}/scripts/stills.mjs {slug} {n} && {S}/board.py {slug} {n}'
        elif not ch.get('board_ok'):
            stage, step = 'approve', (f'look at out/{slug}/ch{n:02d}/storyboard.jpg and every still against the checklist in references/look.md; '
                                      f'fix and re-render the shots that fail; when it passes set "board_ok": true in chapter.json')
        elif meta.get('draft'):
            stage, step = 'real voice', f'make the real voice (outline.json "voice": edge or kokoro, no --provider draft): {S}/voice.py {slug} {n} && {S}/plan.py {slug} {n}'
        elif not (pub_dir(slug, n) / 'sfx.wav').exists() or not tl.get('audio', {}).get('sfx') or tl['audio'].get('src') != tl.get('src'):
            stage, step = 'sound', f'{S}/sfx.py {slug} {n} && {S}/mixcheck.py {slug} {n}'
        else:
            vid = out_dir(slug) / 'chapters' / f'ch{n:02d}.mp4'
            fp = load_json(out_dir(slug) / 'chapters' / 'fingerprints.json', {}).get(f'ch{n:02d}')
            if not vid.exists() or fp != chapter_fp(slug, n):
                stage, step = 'render', f'{S}/render.py {slug} {n}'
    rows.append((n, stage))
    if step and not nxt:
        nxt = step

print(f'{o.get("youtube_title", slug)}  ({len(rows)} chapters)')
for n, st in rows:
    c = next(c for c in o['chapters'] if int(c['n']) == n)
    print(f'  ch{n:02d} {c["title"][:28]:<28} {st}')
final = out_dir(slug) / f'{slug}-final.mp4'
if nxt:
    print(f'NEXT: {nxt}')
elif not final.exists():
    print(f'NEXT: {S}/master.py {slug}')
else:
    print(f'Finished: {final}. Upload it with out/{slug}/captions.srt, chapters.txt, description.md and thumbnail.png.')
