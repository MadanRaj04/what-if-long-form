"""Step 4 (per chapter): put the shots on the voice. Each shot starts on the words it names in "say" (or an "at" cue);
the edit, the punch-ins that split long holds, the effects and the audio stems go into the chapter's timeline.json,
which the engine plays. Also writes out/<slug>/chNN/shotlist.md, prints the pace against the long-form targets, and
regenerates the chapter's glue code.

    python <skill>/scripts/plan.py <slug> <chapter | all>

A shot's start, first match wins:
  "say": "Copy a cookie"   the shot cuts in on these words (2 to 5 words, as spoken; matched in order through the chapter)
  "at": "cookie"           a cue: a word ("paste#2" its 2nd time), "+18" frames after the previous cut, "s:4.2", "f:126"
  neither                  the shot shares the time evenly between its neighbours (fine for quick runs of inserts)
The first shot always starts at frame 0. Cuts land 2 frames before their word (the genre's habit).

chapter.json options: "tail" seconds after the last word (default 0.7; 2.0 on the last chapter), "punch": false to
stop the automatic punch-ins, or a number of seconds a hold may run before it gets one (default 4.2),
"edit": [...] to cut by hand ({"shot", "at" | "say", "look", "reverse", "from", "to"}), for reversals and cut-backs.
"""
import math, statistics, sys

from wi import SKILL, plan_src, ch_dir, chapters, find_phrase, find_word, load_chapter, load_json, load_outline, need_studio, out_dir, resolve, save_json, stem
from scaffold import scaffold

need_studio()
args = [a for a in sys.argv[1:] if not a.startswith('--')]
if len(args) < 2:
    raise SystemExit('usage: plan.py <slug> <chapter | all>')
slug = args[0]
outline = load_outline(slug)
todo = chapters(slug) if args[1] == 'all' else [int(args[1])]
NOPUNCH = {'chapter', 'title', 'schematic', 'insert', 'topdown', 'xcu'}
LONGHOLD = {'chapter': 4.5, 'title': 5.0, 'schematic': 9.0}


def plan(n):
    ch = load_chapter(slug, n)
    FPS = outline.get('fps', 30)
    LEAD = ch.get('lead_frames', 2)
    words = load_json(ch_dir(slug, n) / 'words.json', [])
    if not words:
        raise SystemExit(f'Chapter {n} has no words.json yet: run  python {SKILL}/scripts/voice.py {slug} {n}  '
                         '(use "provider": "draft" in outline.json "voice" to plan before the real voice).')
    shots = {}
    for s in ch.get('shots', []):
        if s['id'] in shots:
            raise SystemExit(f'Chapter {n}: two shots are called {s["id"]}. Every shot id must be different (S1, S2, S3...).')
        shots[s['id']] = s
    if not shots:
        raise SystemExit(f'Chapter {n} has no shots yet. Write them in chapter.json (references/recipes.md), then run check.py.')
    edit = ch.get('edit') or [{k: v for k, v in (('shot', s['id']), ('at', s.get('at')), ('say', s.get('say')), ('look', s.get('look'))) if v is not None} for s in ch['shots']]
    # ---------------------------------------------------------------- cut points
    starts = [None] * len(edit)
    ptr, wprev, prev = 0, 0, None
    for k, e in enumerate(edit):
        if e['shot'] not in shots:
            raise SystemExit(f'Chapter {n}: the edit uses shot {e["shot"]}, which isn\'t in "shots".')
        a = None
        if e.get('say'):
            i = find_phrase(words, e['say'], ptr)
            ptr = i + 1
            a = max(0, round(words[i]['s'] * FPS) - LEAD)
        elif e.get('at') is not None:
            at = str(e['at'])
            if at.startswith(('f:', 's:')):
                a = resolve(at, words, FPS)
            elif at.startswith('+'):
                if prev is None:
                    raise SystemExit(f'Chapter {n}, shot {e["shot"]}: "+{at[1:]}" needs the shot before it to have a start ("say" or "at").')
                a = prev + int(at[1:])
            else:
                base, _, off = at.partition('+') if '+' in at else (at, '', '0')
                if '#' in base:
                    w, nth = base.split('#')
                    i = find_word(words, w, wprev, int(nth))
                else:
                    i = find_word(words, base, wprev)
                wprev = i + 1
                ptr = max(ptr, i + 1)
                a = max(0, round(words[i]['s'] * FPS) - LEAD + int(off or 0))
        if k == 0:
            a = 0
        starts[k] = a
        if a is not None:
            prev = a
    last = ch.get('tail', 2.0 if n == max(chapters(slug)) else 0.7)
    end = resolve(ch['end'], words, FPS) if 'end' in ch else round((words[-1]['e'] + last) * FPS)
    # shots without a start share the time between their neighbours
    k = 0
    while k < len(starts):
        if starts[k] is not None:
            k += 1
            continue
        j = k
        while j < len(starts) and starts[j] is None:
            j += 1
        a0 = starts[k - 1]
        b0 = starts[j] if j < len(starts) else end
        step = (b0 - a0) / (j - k + 1)
        for m in range(k, j):
            starts[m] = round(a0 + step * (m - k + 1))
        k = j
    for k in range(1, len(starts)):
        if starts[k] <= starts[k - 1]:
            e = edit[k]
            raise SystemExit(f'Chapter {n}: shot {e["shot"]} would start at {starts[k] / FPS:.2f} s, not after {edit[k - 1]["shot"]} ({starts[k - 1] / FPS:.2f} s). '
                             'Shots go in the order they are spoken: check its "say" words come later in the script than the previous shot\'s, '
                             'or that two shots don\'t name the same words.')
    if end <= starts[-1] + 6:
        raise SystemExit(f'Chapter {n}: the last shot starts at {starts[-1] / FPS:.1f} s, too close to the end ({end / FPS:.1f} s). Move its "say" earlier or raise "tail".')
    # ---------------------------------------------------------------- segments and clocks
    segments, last_clock = [], {}
    for k, e in enumerate(edit):
        a, b = starts[k], starts[k + 1] if k + 1 < len(starts) else end
        if e.get('reverse'):
            t0 = e.get('from', last_clock.get(e['shot'], b - a))
            t1 = e.get('to', 0)
        else:
            t0 = e.get('from', 0)
            t1 = t0 + (b - a)
        last_clock[e['shot']] = t1
        seg = {'shot': e['shot'], 'a': a, 'b': b, 't0': t0, 't1': t1}
        if e.get('look'):
            seg['look'] = e['look']
        segments.append(seg)
    # ---------------------------------------------------------------- punch-ins: split long holds into two or three cuts
    punch = ch.get('punch', 4.2)
    if punch:
        out = []
        for s in segments:
            dur = (s['b'] - s['a']) / FPS
            recipe = shots[s['shot']].get('recipe', '')
            if s['t1'] < s['t0'] or dur <= punch or recipe in NOPUNCH or shots[s['shot']].get('punch') is False:
                out.append(s)
                continue
            pieces = min(3, math.ceil(dur / 3.2))
            cuts = []
            for p in range(1, pieces):
                want = s['a'] + (s['b'] - s['a']) * p / pieces
                cands = [round(w['s'] * FPS) - LEAD for w in words if s['a'] + 1.1 * FPS < round(w['s'] * FPS) - LEAD < s['b'] - 1.1 * FPS]
                if cands:
                    cuts.append(min(cands, key=lambda c: abs(c - want)))
            cuts = sorted(set(cuts))
            bounds = [s['a'], *cuts, s['b']]
            for q in range(len(bounds) - 1):
                part = dict(s)
                part['a'], part['b'] = bounds[q], bounds[q + 1]
                part['t0'] = s['t0'] + (bounds[q] - s['a'])
                part['t1'] = part['t0'] + (bounds[q + 1] - bounds[q])
                if q % 2 == 1:
                    part['zoom'] = 1.22
                out.append(part)
        segments = out
    for s in segments:
        s['line'] = ' '.join(w['w'] + w.get('p', '').strip() for w in words if s['a'] <= round(w['s'] * FPS) - LEAD < s['b'])
    ids = list(dict.fromkeys(s['shot'] for s in segments))
    info = []
    for sid in ids:
        segs = [s for s in segments if s['shot'] == sid]
        length = max([s['t1'] for s in segs] + [s['t0'] for s in segs])
        d = shots[sid]
        info.append({'id': sid, 'size': d.get('recipe', ''), 'key': min(d.get('key', (segs[0]['b'] - segs[0]['a']) // 2), max(0, length - 1)),
                     'len': length, 'first': segs[0]['a'], 'line': segs[0]['line'], 'note': d.get('note', '')})
    for sid in shots:
        if sid not in ids:
            print(f'  note: shot {sid} is defined but never used')
    # ---------------------------------------------------------------- fx and audio
    fx = []
    for e in ch.get('fx', []):
        item = {k: v for k, v in e.items() if k != 'at'}
        item['f'] = resolve(e['at'], words, FPS, segments, ids)
        fx.append(item)
    old = load_json(ch_dir(slug, n) / 'timeline.json', {}) or {}
    audio = {k: v for k, v in old.get('audio', {}).items() if k.endswith('Vol') or k == 'src'}
    for k in ['voice', 'sfx', 'music']:
        f = stem(slug, n, k)
        if f:
            audio[k] = f'{slug}/ch{n:02d}/{f.name}'
    meta = load_json(out_dir(slug, n) / 'voice_meta.json', {})
    tl = {'slug': slug, 'chapter': n, 'title': ch.get('title', ''), 'fps': FPS, 'total': end, 'segments': segments, 'shots': info, 'fx': fx, 'audio': audio,
          'draft_voice': bool(meta.get('draft')), 'src': plan_src(slug, n)}
    save_json(ch_dir(slug, n) / 'timeline.json', tl)
    # ---------------------------------------------------------------- pace report and shot list
    cuts = [s['a'] for s in segments[1:]]
    lens = [(s['b'] - s['a']) / FPS for s in segments]
    dur = end / FPS
    per_min = len(cuts) / dur * 60
    target = 26 if n == 1 else 14
    print(f'chapter {n}: {len(segments)} segments from {len(ids)} shots, {dur:.1f} s; {per_min:.0f} cuts/min (target {target}+), '
          f'median shot {statistics.median(lens):.1f} s, longest {max(lens):.1f} s')
    if per_min < target:
        print(f'  ! slower than the target: add shots (inserts and close-ups are quick to make) or split long ones with "say"')
    for s in segments:
        lim = LONGHOLD.get(shots[s['shot']].get('recipe', ''), 6.0)
        if (s['b'] - s['a']) / FPS > lim:
            print(f'  ! {s["shot"]} holds {(s["b"] - s["a"]) / FPS:.1f} s (over {lim:.0f} s): split it with another shot, or give it a camera move and action inside')
    rows = ['| # | Shot | Recipe | Set | In | Length | Look | Words |', '|---|---|---|---|---|---|---|---|']
    for k, s in enumerate(segments):
        d = shots[s['shot']]
        rows.append(f"| {k + 1} | {s['shot']}{' (punch)' if s.get('zoom') else ''} | {d.get('recipe', '')} | {d.get('set', '')} | {s['a'] / FPS:.2f} s | {(s['b'] - s['a']) / FPS:.2f} s | {s.get('look', '')} | {s['line']} |")
    md = f"# Chapter {n}: {ch.get('title', '')}\n\n{dur:.1f} s, {len(segments)} segments, {per_min:.0f} cuts/min\n\n" + '\n'.join(rows) + '\n'
    (out_dir(slug, n) / 'shotlist.md').write_text(md, encoding='utf-8')
    return dur


total = 0
for n in todo:
    total += plan(n)
scaffold(slug)
if len(todo) > 1:
    print(f'all chapters: {total / 60:.1f} minutes')
print(f'next: node {SKILL}/scripts/stills.mjs {slug} {todo[0] if len(todo) == 1 else 1}   then   python {SKILL}/scripts/board.py {slug} {todo[0] if len(todo) == 1 else 1}')
