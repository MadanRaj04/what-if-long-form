"""Word timings when the voice didn't come with them (your own recording, or a TTS without timestamps).

Two ways, best first:
  1. faster-whisper, if installed (pip install faster-whisper): transcribes with word timestamps, then maps them onto
     your script's own words so spelling and punctuation stay yours. Free, runs locally, about a minute a chapter on a
     laptop CPU with the base.en model.
  2. An estimate from the audio itself: finds where speech is (energy), puts the longest silences at sentence ends and
     spreads the words through the voiced time by their length. Good enough to cut shots on; check the board.

    python <skill>/scripts/align.py <audio> "<script text>"     prints the words with times (for testing)
"""
import difflib, re, sys

import numpy as np

from wi import SR, decode, norm


def tokens(text):
    """Script words with their trailing punctuation: [{'w': 'Copy', 'p': ''}, {'w': 'cookie', 'p': '.'}]."""
    out = []
    for tok in text.split():
        m = re.match(r"^([^\w']*)([\w'\u2019\-]+)(.*)$", tok)
        if not m:
            if out:
                out[-1]['p'] += tok
            continue
        out.append({'w': m.group(2), 'p': m.group(3)})
    return out


def attach(words, text):
    """Give timed words the script's spelling and punctuation, matching them in order (numbers read as words etc.
    still line up by position). `words`: [{'w','s','e'}] from any engine. Returns [{'w','s','e','p'}] in script order."""
    toks = tokens(text)
    a = [norm(w['w']) for w in words]
    b = [norm(t['w']) for t in toks]
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    timed = [None] * len(toks)
    for blk in sm.get_matching_blocks():
        for k in range(blk.size):
            timed[blk.b + k] = (words[blk.a + k]['s'], words[blk.a + k]['e'])
    # fill unmatched script words by interpolating between their timed neighbours
    n = len(toks)
    i = 0
    total_end = words[-1]['e'] if words else 0.0
    while i < n:
        if timed[i] is not None:
            i += 1
            continue
        j = i
        while j < n and timed[j] is None:
            j += 1
        s0 = timed[i - 1][1] if i > 0 else (words[0]['s'] if words else 0.0)
        s1 = timed[j][0] if j < n else total_end
        span = max(0.05, s1 - s0)
        L = sum(len(toks[k]['w']) + 1 for k in range(i, j))
        acc = s0
        for k in range(i, j):
            d = span * (len(toks[k]['w']) + 1) / L
            timed[k] = (acc, acc + d * 0.92)
            acc += d
        i = j
    return [{'w': t['w'], 's': round(timed[k][0], 3), 'e': round(timed[k][1], 3), 'p': t['p']} for k, t in enumerate(toks)]


def whisper_words(path):
    from faster_whisper import WhisperModel  # noqa
    model = WhisperModel('base.en', device='cpu', compute_type='int8')
    segs, _ = model.transcribe(str(path), word_timestamps=True, vad_filter=False)
    out = []
    for s in segs:
        for w in s.words or []:
            out.append({'w': w.word.strip(), 's': float(w.start), 'e': float(w.end)})
    return out


def estimate(path, text):
    """Spread the script's words over where the audio is voiced, sentence ends on the longest silences."""
    x = decode(path)
    hop = int(0.01 * SR)
    frames = len(x) // hop
    rms = np.sqrt(np.convolve(x[: frames * hop].reshape(frames, hop).__pow__(2).mean(1), np.ones(5) / 5, mode='same'))
    thr = max(1e-4, np.percentile(rms, 95) * 0.08)
    voiced = rms > thr
    toks = tokens(text)
    if not toks:
        return []
    # voiced runs
    runs = []
    i = 0
    while i < frames:
        if voiced[i]:
            j = i
            while j < frames and voiced[j]:
                j += 1
            runs.append([i, j])
            i = j
        else:
            i += 1
    # merge runs separated by tiny gaps (inside words)
    merged = []
    for r in runs:
        if merged and r[0] - merged[-1][1] < 8:
            merged[-1][1] = r[1]
        else:
            merged.append(r)
    if not merged:
        merged = [[0, frames]]
    # assign tokens to runs by weight
    weights = np.array([len(t['w']) + 1.5 for t in toks], dtype=float)
    total_voiced = sum(b - a for a, b in merged)
    out = []
    cum = np.cumsum(weights) / weights.sum() * total_voiced
    starts = np.concatenate([[0], cum[:-1]])

    def at(v):
        acc = 0
        for a, b in merged:
            if v <= acc + (b - a):
                return (a + (v - acc)) * hop / SR
            acc += b - a
        return merged[-1][1] * hop / SR

    for k, t in enumerate(toks):
        out.append({'w': t['w'], 's': round(at(starts[k] + 0.5), 3), 'e': round(at(cum[k] - 0.5), 3), 'p': t['p']})
    return out


def align(path, text):
    try:
        ww = whisper_words(path)
        if ww:
            print(f'aligned with faster-whisper: {len(ww)} words heard')
            return attach(ww, text)
    except ImportError:
        print('faster-whisper not installed: estimating word times from the audio (pip install faster-whisper for exact times)')
    except Exception as e:  # a broken install shouldn't stop the pipeline
        print(f'faster-whisper failed ({e}); estimating word times from the audio')
    return estimate(path, text)


if __name__ == '__main__':
    for w in align(sys.argv[1], sys.argv[2]):
        print(f"{w['w']}{w['p']}@{w['s']}")
