"""The checker: run it after every edit. It reads outline.json and the chapters, and tells you exactly what is wrong
and how to fix it, before anything costs time (a render) or money (a voice). Errors (x) must be fixed; warnings (!)
are quality notes worth fixing.

    python <skill>/scripts/check.py <slug>            the outline (and every chapter that has a script)
    python <skill>/scripts/check.py <slug> <n>        one chapter: script, then shots (and "say" against the voice if it exists)

It also guards the facts: every number in a script line must appear in a claim in outline.json "science", so the
voice never says a number nobody worked out.
"""
import re, sys

from wi import (SKILL, ANCHORS, CAST, EXPRS, FACES, ICONS, LAYOUTS, MOODS, MOVES, POSES, PROPS, RECIPES, ROOMS, SETS, SLOTS, UIS, WPS,
                ch_dir, chapter_text, find_phrase, has_todo, load_chapter, load_json, load_outline, need_studio)

need_studio()
args = [a for a in sys.argv[1:] if not a.startswith('--')]
if not args:
    raise SystemExit('usage: check.py <slug> [chapter]')
slug = args[0]
only = int(args[1]) if len(args) > 1 else None
E, W = [], []


def err(where, msg):
    E.append(f'x {where}: {msg}')


def warn(where, msg):
    W.append(f'! {where}: {msg}')


NUMWORDS = {'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen',
            'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'hundred',
            'thousand', 'million', 'billion', 'trillion', 'quadrillion', 'percent', 'half', 'quarter', 'double', 'triple', 'twice'}
EVERYDAY = {'one', 'two', 'three', 'half', 'twice', 'double'}  # small everyday counts don't need a source
OPEN_LOOP = re.compile(r"\?|\bbut\b|\buntil\b|\bexcept\b|\bthen\b|\bthat's when\b|\bnext\b|\bwhat\b|\bwho\b|\bwhy\b|\bnever\b|\bwrong\b|\bproblem\b|\bcatch\b|\bunless\b|\bworse\b|\bwatching\b|\bnoticed\b|\bsomeone\b|\btoo much\b|\ba lot\b|\bagain\b|\bonly\b|\.\.\.|\u2026", re.I)


def numbers_in(text):
    out = set(re.findall(r'\d[\d,.]*', text))
    out |= {w for w in re.findall(r"[a-z]+", text.lower()) if w in NUMWORDS and w not in EVERYDAY}
    return out


# ---------------------------------------------------------------- the outline
o = load_outline(slug)
science_text = ' '.join(f"{s.get('claim', '')} {s.get('working', '')}" for s in o.get('science', [])).lower()
looks = set((o.get('looks') or {}).keys())
nch = len(o.get('chapters', []))
if only is None:
    if has_todo(o):
        for k, v in o.items():
            if 'TODO' in str(v):
                err('outline', f'"{k}" still has a TODO. Replace every "TODO..." with the real thing.')
    if not re.match(r'^[A-Z][A-Za-z0-9]*$', str(o.get('id', ''))):
        err('outline', '"id" must be PascalCase letters and digits (it names the compositions), e.g. "PauseTime".')
    if o.get('slug') != slug:
        err('outline', f'"slug" must be "{slug}" (the folder name).')
    t = o.get('title', [])
    if not (isinstance(t, list) and len(t) == 2):
        err('outline', '"title" is two lines: ["WHAT IF YOU COULD", "PAUSE EVERYONE?"].')
    elif len(t[1]) > 26:
        warn('outline', f'title line 2 is {len(t[1])} characters: 26 or fewer reads at phone size.')
    if not 5 <= nch <= 12:
        err('outline', f'{nch} chapters: a 7-10 minute episode has 6 to 10 (the template has 8).')
    secs = sum(c.get('seconds', 0) for c in o.get('chapters', []))
    if not 420 <= secs <= 600:
        (err if not 300 <= secs <= 720 else warn)('outline', f'the chapters add up to {secs / 60:.1f} minutes; aim for 7 to 10 (420 to 600 s).')
    for i, c in enumerate(o.get('chapters', [])):
        w = f'outline chapter {c.get("n", i + 1)}'
        if int(c.get('n', -1)) != i + 1:
            err(w, f'"n" must be {i + 1} (chapters are numbered 1, 2, 3 in order).')
        for k in ('title', 'beat', 'seconds', 'goal'):
            if not c.get(k):
                err(w, f'missing "{k}".')
        if c.get('mood') and c['mood'] not in MOODS:
            err(w, f'mood "{c["mood"]}" is not one of {", ".join(MOODS)}.')
        for s in c.get('sets', []):
            if s not in SETS and 'TODO' not in s:
                err(w, f'set "{s}" doesn\'t exist. Sets: {", ".join(SETS)}.')
        if i < nch - 1 and c.get('open_loop') and not OPEN_LOOP.search(c['open_loop']):
            warn(w, 'the open loop should leave a question hanging ("...and that\'s when...", "but...", a question).')
    p = o.get('power', {})
    if not p.get('word'):
        err('outline', '"power.word": the one word said every time the power is used.')
    if p.get('look') and p['look'] not in looks:
        err('outline', f'"power.look" is "{p["look"]}" but "looks" has only: {", ".join(looks) or "nothing"}.')
    v = o.get('voice', {})
    if v.get('provider', 'edge') not in ('edge', 'kokoro', 'elevenlabs', 'file', 'draft'):
        err('outline', 'voice.provider must be edge, kokoro, elevenlabs, file or draft.')
    for k, s in enumerate(o.get('science', [])):
        for f in ('claim', 'working', 'source'):
            if not s.get(f) or 'TODO' in s.get(f, ''):
                err(f'outline science {k + 1}', f'"{f}" is empty: every fact needs the claim, the arithmetic and the source.')
    if not o.get('science'):
        err('outline', '"science": at least one real, checked fact with a number for "The catch" (beat 4).')
    th = o.get('thumbnail', {})
    if th.get('set') and th['set'] not in SETS:
        err('outline thumbnail', f'set "{th["set"]}" doesn\'t exist.')
    if th.get('expr') and th['expr'] not in EXPRS:
        err('outline thumbnail', f'expr "{th["expr"]}" is not one of {", ".join(EXPRS)}.')


# ---------------------------------------------------------------- chapters
def check_shot(n, s, i, prev, words, ptr):
    w = f'ch{n} {s.get("id", f"shot #{i + 1}")}'
    r = s.get('recipe')
    if not re.match(r'^S\d+[a-z]?$', str(s.get('id', ''))):
        err(w, 'every shot needs an "id" like "S1", "S2", "S3b".')
    if r not in RECIPES:
        err(w, f'recipe "{r}" doesn\'t exist. Recipes: {", ".join(RECIPES)}.')
        return ptr
    st = s.get('set')
    if st is not None and st not in SETS:
        err(w, f'set "{st}" doesn\'t exist. Sets: {", ".join(SETS)}.')
    if r in ('wide', 'medium', 'closeup', 'xcu', 'twoshot', 'ots', 'lowangle', 'walk', 'reveal', 'title') and not st:
        err(w, f'a {r} needs a "set".')
    cast = s.get('cast', [])
    if r in ('medium', 'closeup', 'xcu', 'ots', 'lowangle', 'walk') and not cast:
        err(w, f'a {r} is framed on a character: add "cast": [{{"who": "pipHood"}}].')
    if r == 'twoshot' and len(cast) < 2:
        err(w, 'a twoshot needs two people in "cast".')
    if r == 'walk' and cast and not cast[0].get('walk'):
        err(w, 'a walk needs the first cast member to have "walk": {"to": "right"}.')
    if r in ('title', 'chapter') and not (isinstance(s.get('title'), list) and len(s['title']) == 2):
        err(w, f'a {r} needs "title": two lines (title: ["WHAT IF YOU COULD", "..."]; chapter: ["PART 2", "THE RULES"]).')
    if r == 'schematic':
        d = s.get('diagram')
        if not d:
            err(w, 'a schematic needs a "diagram" (references/recipes.md, "The science beat").')
        else:
            if d.get('layout') not in LAYOUTS:
                err(w, f'diagram layout "{d.get("layout")}" is not one of {", ".join(LAYOUTS)}.')
            for it in d.get('items', []):
                if it.get('icon') and it['icon'] not in ICONS:
                    err(w, f'icon "{it["icon"]}" doesn\'t exist. Icons: {", ".join(ICONS)}.')
                if len(it.get('text', '')) > 22:
                    warn(w, f'diagram text "{it["text"]}" is long: keep each to 22 characters or fewer.')
            if d.get('icons') and d['icons'].get('icon') not in ICONS:
                err(w, f'icons.icon "{d["icons"].get("icon")}" doesn\'t exist.')
            if d.get('layout') == 'count' and not d.get('count'):
                err(w, 'a count layout needs "count": {"to": 299792, "label": "KM EVERY SECOND"}.')
            if d.get('layout') == 'compare' and not d.get('bars'):
                err(w, 'a compare layout needs "bars": [{"label": "...", "value": 1}, ...].')
            for k, v in [('heading', d.get('heading', ''))] + [(f'item {j + 1}', it.get('text', '')) for j, it in enumerate(d.get('items', []))]:
                for num in re.findall(r'\d[\d,.]*', v):
                    if num.replace(',', '') not in science_text.replace(',', '') and len(num.replace(',', '').replace('.', '')) > 1:
                        warn(w, f'the diagram shows "{num}", which isn\'t in outline "science": put the working there.')
    for j, c in enumerate(cast):
        cw = f'{w} cast {j}'
        if c.get('who') not in CAST:
            err(cw, f'who "{c.get("who")}" isn\'t in the cast: {", ".join(CAST)}.')
        at = c.get('at')
        if isinstance(at, str) and at not in SLOTS:
            err(cw, f'at "{at}" is not a slot ({", ".join(SLOTS)}) or a list like [0.4, 0.5].')
        if at == 'bed' and st != 'bedroom':
            err(cw, 'only the bedroom has a "bed".')
        if c.get('face') and c['face'] not in FACES:
            err(cw, f'face "{c["face"]}" is not one of {", ".join(FACES)}.')
        last = -1
        for k in c.get('act', []):
            if not (isinstance(k, list) and len(k) == 2 and isinstance(k[0], (int, float)) and k[1] in POSES):
                err(cw, f'act entries are [frame, pose] with a pose from: {", ".join(POSES)}. Got {k}.')
                break
            if k[0] <= last:
                err(cw, 'act frames must go up: [[0, "idle"], [8, "point"], [20, "cheer"]].')
            last = k[0]
        last = -1
        for k in c.get('expr', []):
            if not (isinstance(k, list) and len(k) == 2 and k[1] in EXPRS):
                err(cw, f'expr entries are [frame, face] with a face from: {", ".join(EXPRS)}. Got {k}.')
                break
            if k[0] <= last:
                err(cw, 'expr frames must go up.')
            last = k[0]
        if c.get('walk') and isinstance(c['walk'].get('to'), str) and c['walk']['to'] not in SLOTS:
            err(cw, f'walk.to "{c["walk"]["to"]}" is not a slot.')
    for j, p in enumerate(s.get('props', [])):
        pw = f'{w} prop {j}'
        if p.get('kind') not in PROPS:
            err(pw, f'kind "{p.get("kind")}" doesn\'t exist. Props: {", ".join(PROPS)}.')
        at = p.get('at')
        if isinstance(at, str) and at != 'hand':
            if r in ('insert', 'topdown'):
                err(pw, f'in an {r}, props go at screen points like [960, 540].')
            elif st and at not in ANCHORS.get(st, []):
                err(pw, f'"{at}" isn\'t a place on the {st} set. Use one of {", ".join(ANCHORS.get(st, [])) or "(none)"}, "hand", or [x, y].')
        if at == 'hand' and not cast:
            err(pw, '"at": "hand" needs someone in "cast" to hold it.')
    for j, u in enumerate(s.get('ui', [])):
        uw = f'{w} ui {j}'
        if u.get('kind') not in UIS:
            err(uw, f'kind "{u.get("kind")}" doesn\'t exist. Marks: {", ".join(UIS)}.')
        tg = u.get('target')
        if isinstance(tg, str):
            m = re.match(r'^(cast|prop|head)(\d+)$', tg)
            if not m:
                err(uw, f'target "{tg}" must be "cast0", "head0", "prop0" or a screen point/box.')
            else:
                k = int(m.group(2))
                if m.group(1) in ('cast', 'head') and k >= len(cast):
                    err(uw, f'target {tg}: there is no cast member {k}.')
                if m.group(1) == 'prop' and k >= len(s.get('props', [])):
                    err(uw, f'target {tg}: there is no prop {k}.')
        if u.get('kind') in ('tag', 'toast', 'label', 'stamp') and not u.get('text') and u.get('kind') != 'stamp':
            warn(uw, f'a {u.get("kind")} usually has a short "text".')
        if u.get('text') and len(u['text']) > 18:
            warn(uw, f'"{u["text"]}" is long for an on-screen mark (18 characters or fewer).')
    if s.get('freeze') is not None and not isinstance(s['freeze'], (int, float)):
        err(w, '"freeze" is the frame the world stops at (0 = from the start).')
    if any(c.get('frozen') for c in cast) and s.get('freeze') is None:
        warn(w, 'a cast member is "frozen" but the shot has no "freeze": add "freeze": 0 to stop the world.')
    cam = s.get('camera', {})
    if cam.get('move') and cam['move'] not in MOVES:
        err(w, f'camera.move "{cam["move"]}" is not one of {", ".join(MOVES)}.')
    if s.get('look') and s['look'] not in looks:
        err(w, f'look "{s["look"]}" isn\'t defined in outline.json "looks" ({", ".join(looks) or "none"}).')
    if r in ('insert', 'topdown') and s.get('arm'):
        if not all(isinstance(k, list) and len(k) == 3 for k in s['arm'].get('keys', [])):
            err(w, 'arm.keys are [frame, x, y] on screen: [[0, 1400, 300], [8, 1050, 420]].')
    if i > 0 and not (s.get('say') or s.get('at')):
        warn(w, 'no "say": it will share time with its neighbours. Give it the first words of its line to cut on the word.')
    if s.get('say') and words:
        try:
            ptr = find_phrase(words, s['say'], ptr) + 1
        except SystemExit as e:
            err(w, str(e))
    if prev and prev.get('recipe') == r and prev.get('set') == st and r not in ('schematic', 'chapter', 'insert'):
        warn(w, f'same recipe and set as {prev.get("id")} ({r} on {st}): change the size or angle every cut (wide, medium, close-up, insert...).')
    return ptr


def check_chapter(n):
    ch = load_chapter(slug, n)
    w = f'ch{n}'
    script = ch.get('script', [])
    if has_todo(script) or not chapter_text(ch):
        err(w, 'the script still has TODO lines: write them (short lines, second person, every line a picture).')
        return
    text = chapter_text(ch)
    nw = len(text.split())
    secs = next((c.get('seconds', 60) for c in o.get('chapters', []) if int(c['n']) == n), 60)
    budget = secs * WPS
    if abs(nw - budget) > budget * 0.25:
        warn(w, f'{nw} words for {secs} s (budget about {budget:.0f}): ' + ('cut lines.' if nw > budget else 'add a line or two.'))
    for k, b in enumerate(script):
        for sent in re.split(r'(?<=[.?!])\s+', b.get('text', '')):
            if len(sent.split()) > 16:
                warn(f'{w} line {k + 1}', f'"{sent[:50]}..." is {len(sent.split())} words: split it (3 to 12 words a sentence reads best aloud).')
        nums = numbers_in(b.get('text', ''))
        for num in nums:
            if num.replace(',', '') not in science_text.replace(',', '') and num not in science_text:
                err(f'{w} line {k + 1}', f'the number "{num}" isn\'t in outline.json "science". Work it out there (claim, working, source) or say it without a number.')
    if n < nch and not OPEN_LOOP.search(script[-1].get('text', '')):
        warn(w, 'the last line should open a loop into the next chapter (a question, "but...", "that\'s when...").')
    if n == 1:
        pw = (o.get('power', {}).get('word') or '').split()[0].strip('.?!').lower() if o.get('power', {}).get('word') else ''
        if pw and text.lower().count(pw) < 3:
            warn(w, f'the cold open says the power word "{pw}" {text.lower().count(pw)} times: say it in every demo (3 or more).')
    shots = ch.get('shots', [])
    if not shots or (len(shots) == 1 and shots[0].get('recipe') == 'chapter'):
        warn(w, 'no shots yet: write them after the voice (references/recipes.md). About one shot per 2 to 3 seconds.')
        return
    words = load_json(ch_dir(slug, n) / 'words.json', [])
    ptr, prev = 0, None
    for i, s in enumerate(shots):
        ptr = check_shot(n, s, i, prev, words, ptr)
        prev = s
    if n > 1 and shots[0].get('recipe') != 'chapter':
        warn(w, 'chapters after the first open on a chapter card: make S1 {"recipe": "chapter", "title": ["PART n", "NAME"], "at": "f:0"}.')
    kinds = {s.get('recipe') for s in shots}
    if not kinds & {'closeup', 'xcu', 'insert', 'topdown'}:
        warn(w, 'no close-up or insert: every chapter needs size changes (a face, a hand, an object).')
    per = len(shots) / max(1, secs) * 60
    if per < (20 if n == 1 else 11):
        warn(w, f'{len(shots)} shots for {secs} s is slow ({per:.0f} a minute): aim for {"26+" if n == 1 else "14+"} cuts a minute (punch-ins add a few).')
    ids = [s.get('id') for s in shots]
    if len(ids) != len(set(ids)):
        err(w, 'two shots have the same id.')


targets = [only] if only else [int(c['n']) for c in o.get('chapters', []) if (ch_dir(slug, int(c['n'])) / 'chapter.json').exists()]
for n in targets:
    if not (ch_dir(slug, n) / 'chapter.json').exists():
        err(f'ch{n}', f'no chapter file yet: python {SKILL}/scripts/new.py {slug} --chapters')
        continue
    check_chapter(n)

for x in E + W:
    print(x)
print(f'{len(E)} errors, {len(W)} warnings' + ('' if E else '  -> OK'))
sys.exit(1 if E else 0)
