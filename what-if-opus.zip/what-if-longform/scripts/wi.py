"""Shared helpers for the long-form What If scripts: paths, chapters, cues, audio, keys, costs and the vocabulary the
validator checks against (it mirrors studio/src/engine/spec.ts).

Every script runs from the studio folder (the copy of studio/ where you ran npm install) and takes the episode slug,
and usually a chapter number:
    python <skill>/scripts/plan.py pause 3

An episode:   src/episodes/<slug>/outline.json            (you write it: the whole story, chapter by chapter)
A chapter:    src/episodes/<slug>/chNN/chapter.json       (you write it: the script lines and the shots)
              src/episodes/<slug>/chNN/words.json, timeline.json, index.tsx   (the scripts write these)
Audio:        public/<slug>/chNN/voice.wav, sfx.wav, music.wav
Review:       out/<slug>/chNN/ (storyboard, stills, grids), out/<slug>/ (renders, final, captions, report)
Libraries:    library/sfx/ (generated or downloaded clips), library/music/<mood>/ (your own music, optional)
"""
import hashlib, json, os, pathlib, re, subprocess, sys, time, urllib.request, wave

import numpy as np

SR = 44100
WPS = 2.6  # words a second after the pauses are tightened: the budget every chapter's script is checked against
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

STUDIO = pathlib.Path.cwd()
SKILL = pathlib.Path(__file__).resolve().parent.parent


def need_studio():
    if not (STUDIO / 'src' / 'episodes').exists():
        raise SystemExit('Run this from the studio folder (the one with src/episodes and package.json). '
                         f'You are in {STUDIO}. Try: cd what-if-studio')


LIB = STUDIO / 'library' / 'sfx'
MUSIC_LIB = STUDIO / 'library' / 'music'

# ---------------------------------------------------------------- the vocabulary (mirror of spec.ts)
SETS = ['study', 'studyNight', 'kitchen', 'bedroom', 'classroom', 'stairwell', 'rooftop', 'office', 'street', 'schematic', 'sky']
RECIPES = ['wide', 'medium', 'closeup', 'xcu', 'twoshot', 'ots', 'lowangle', 'insert', 'topdown', 'title', 'chapter', 'schematic', 'walk', 'reveal']
CAST = ['pip', 'pipHood', 'pipInk', 'mo', 'sis', 'mom', 'suit']
POSES = ['idle', 'point', 'cheer', 'shrug', 'think', 'shock', 'wave', 'reach', 'lean', 'present', 'fist', 'scared', 'sad', 'hold', 'stop', 'sit']
EXPRS = ['neutral', 'happy', 'smug', 'shock', 'worried', 'oops', 'cool', 'dizzy', 'tired']
FACES = ['left', 'right', 'camera', 'away']
SLOTS = ['left', 'center', 'right', 'farLeft', 'farRight', 'bed', 'landing', 'stairs', 'bottom']
PROPS = ['cookie', 'cookieTop', 'cookies', 'mug', 'plate', 'plateTop', 'paper', 'papers', 'phone', 'book', 'books', 'clock', 'calendar', 'pizza',
         'pizzaBox', 'ball', 'cat', 'laptop', 'cash', 'envelope', 'badge', 'glass', 'box']
UIS = ['marquee', 'tag', 'toast', 'float', 'sparkle', 'rings', 'dizzy', 'hud', 'dial', 'gauge', 'label', 'stamp', 'arrow', 'question']
MOVES = ['static', 'pushIn', 'pullOut', 'panLeft', 'panRight', 'handheld', 'follow', 'tiltUp', 'crashZoom']
LAYOUTS = ['equation', 'count', 'icons', 'compare', 'timeline', 'list']
ICONS = ['tower', 'wind', 'solar', 'dam', 'factory', 'person', 'clock', 'bolt', 'heart', 'eye', 'globe', 'cookie', 'coin', 'brain', 'sun', 'moon', 'house', 'car', 'phone', 'drop']
ANCHORS = {
    'study': ['desk', 'desk2', 'floor'], 'studyNight': ['desk', 'desk2', 'floor'], 'kitchen': ['island', 'island2', 'counter', 'floor'],
    'bedroom': ['nightstand', 'bed', 'floor'], 'classroom': ['desk', 'board', 'floor'], 'stairwell': ['landing', 'bottom', 'step', 'floor'],
    'rooftop': ['deck', 'deck2', 'parapet', 'floor'], 'office': ['desk', 'floor'], 'street': ['bench', 'ground', 'floor'], 'schematic': [], 'sky': ['ground', 'floor'],
}
MOODS = ['playful', 'wonder', 'tense', 'eerie', 'sad', 'action', 'triumph', 'none']
ROOMS = {'study', 'studyNight', 'kitchen', 'bedroom', 'classroom', 'office'}


# ---------------------------------------------------------------- paths
def ep_dir(slug):
    return STUDIO / 'src' / 'episodes' / slug


def ch_name(n):
    return f'ch{int(n):02d}'


def ch_dir(slug, n):
    return ep_dir(slug) / ch_name(n)


def pub_dir(slug, n=None):
    d = STUDIO / 'public' / slug / (ch_name(n) if n is not None else '')
    d.mkdir(parents=True, exist_ok=True)
    return d


def out_dir(slug, n=None):
    d = STUDIO / 'out' / slug / (ch_name(n) if n is not None else '')
    d.mkdir(parents=True, exist_ok=True)
    return d


def stem(slug, n, name):
    for ext in ('wav', 'mp3'):
        q = STUDIO / 'public' / slug / ch_name(n) / f'{name}.{ext}'
        if q.exists():
            return q
    return None


def load_json(p, default=None):
    p = pathlib.Path(p)
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text(encoding='utf-8-sig'))
    except json.JSONDecodeError as e:
        raise SystemExit(f'{p} is not valid JSON: {e.msg} at line {e.lineno}, column {e.colno}. Fix that line and run again.')


def save_json(p, data):
    pathlib.Path(p).write_text(json.dumps(data, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')


def load_outline(slug):
    p = ep_dir(slug) / 'outline.json'
    if not p.exists():
        raise SystemExit(f'No outline at {p}. Start one with: python {SKILL}/scripts/new.py {slug} "What if ...?"')
    return load_json(p)


def load_chapter(slug, n):
    p = ch_dir(slug, n) / 'chapter.json'
    if not p.exists():
        raise SystemExit(f'No chapter file at {p}. Create the chapter files with: python {SKILL}/scripts/new.py {slug} --chapters')
    return load_json(p)


def chapters(slug):
    """Chapter numbers in the outline, in order."""
    o = load_outline(slug)
    return [int(c['n']) for c in o.get('chapters', [])]


def pascal(s):
    return ''.join(w[:1].upper() + w[1:] for w in re.split(r'[^A-Za-z0-9]+', s) if w)


def comp_id(outline, n):
    return f"{outline['id']}Ch{int(n):02d}"


def chapter_text(ch):
    return ' '.join(b['text'].strip() for b in ch.get('script', []) if b.get('text', '').strip())


def has_todo(x):
    return 'TODO' in json.dumps(x, ensure_ascii=False)


def fingerprint(*paths):
    """A short hash of files' contents (missing files count as empty), for 'is this up to date?' checks."""
    h = hashlib.sha1()
    for p in paths:
        p = pathlib.Path(p)
        if p.is_dir():
            for q in sorted(p.rglob('*')):
                if q.is_file():
                    h.update(q.name.encode())
                    h.update(str(q.stat().st_mtime_ns).encode())
        elif p.exists():
            h.update(p.read_bytes())
        h.update(b'|')
    return h.hexdigest()[:16]


# ---------------------------------------------------------------- keys (only ElevenLabs needs one, and it's optional)
KEY_NAMES = ['ELEVENLABS_API_KEY']


def read_env(p):
    raw = p.read_bytes()
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return raw.decode('utf-16', errors='ignore')
    return raw.decode('utf-8-sig', errors='ignore')


def env_value(name):
    if os.environ.get(name):
        return os.environ[name]
    for d in [STUDIO, *STUDIO.parents]:
        p = d / '.env'
        if p.exists():
            for line in read_env(p).splitlines():
                if line.strip().startswith(name + '='):
                    return line.split('=', 1)[1].strip().strip('"').strip("'")
    return None


def api_key():
    for n in KEY_NAMES:
        v = env_value(n)
        if v:
            return v
    raise SystemExit('No ElevenLabs key. It is optional: use the free voice ("provider": "edge" or "kokoro" in outline.json "voice") '
                     'and the free sound ("engine": "free"), or set ELEVENLABS_API_KEY in a .env file.')


def api(path, body=None, timeout=180):
    req = urllib.request.Request('https://api.elevenlabs.io' + path, headers={'xi-api-key': api_key(), 'Content-Type': 'application/json'})
    if body is not None:
        req.data = json.dumps(body).encode()
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def log_cost(slug, step, used, note=''):
    p = out_dir(slug) / 'costs.json'
    rows = load_json(p, [])
    rows.append({'step': step, 'credits': used, 'note': note, 'at': time.strftime('%Y-%m-%d %H:%M')})
    save_json(p, rows)
    total = sum(r['credits'] for r in rows)
    print(f'{step}: {used} credits{f" ({note})" if note else ""}; this episode so far: {total}')


# ---------------------------------------------------------------- words and cues
def norm(w):
    return re.sub(r"[^\w']", '', w.lower().replace('\u2019', "'"))


def find_word(words, target, start=0, nth=1):
    t = norm(target)
    seen = 0
    for i in range(start, len(words)):
        if norm(words[i]['w']) == t:
            seen += 1
            if seen == nth:
                return i
    near = ' '.join(w['w'] for w in words[start:start + 14])
    raise SystemExit(f'Cue word "{target}" (#{nth}) not found after word {start}. The next words are: "{near}" ...')


def find_phrase(words, phrase, start=0):
    """Where the words of `phrase` start in the voice's words, at or after `start`. Tolerant: the first 4 words are
    tried, then 3, 2, 1, so a small difference in punctuation or a contraction doesn't break the match."""
    want = [norm(w) for w in phrase.split() if norm(w)]
    if not want:
        raise SystemExit('A shot has an empty "say".')
    seq = [norm(w['w']) for w in words]
    for k in (4, 3, 2, 1):
        pat = want[:k]
        if len(pat) < min(k, len(want)):
            continue
        for i in range(start, len(seq) - len(pat) + 1):
            if seq[i:i + len(pat)] == pat:
                return i
    near = ' '.join(w['w'] for w in words[start:start + 16])
    raise SystemExit(f'"say": "{phrase}" was not found after word {start}. The next words in the voice are: "{near}" ... '
                     'Copy the first few words of the line exactly as they appear there.')


CUE = re.compile(r'^(?P<base>[^+\-#]+?)(?:#(?P<nth>\d+))?(?P<off>[+-]\d+)?$')


def resolve(cue, words, fps, segments=None, shot_ids=()):
    """A cue to a frame in the chapter: f:123, s:4.2, S3+2 (2 frames into shot S3's first segment), word+3, word#2."""
    cue = str(cue).strip()
    if cue.startswith('f:'):
        return int(round(float(cue[2:])))
    if cue.startswith('s:'):
        return int(round(float(cue[2:]) * fps))
    m = CUE.match(cue)
    if not m:
        raise SystemExit(f'Bad cue "{cue}"')
    base, nth, off = m['base'], int(m['nth'] or 1), int(m['off'] or 0)
    if segments is not None and base in shot_ids:
        segs = [s for s in segments if s['shot'] == base]
        if len(segs) < nth:
            raise SystemExit(f'Cue "{cue}": shot {base} has only {len(segs)} segment(s)')
        return segs[nth - 1]['a'] + off
    return round(words[find_word(words, base, 0, nth)]['s'] * fps) + off


# ---------------------------------------------------------------- audio
def decode(path, sr=SR):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-f', 'f32le', '-ac', '1', '-ar', str(sr), '-'], capture_output=True, check=True).stdout
    return np.frombuffer(raw, dtype=np.float32).astype(np.float64)


def write_wav(path, x, peak=None, sr=SR):
    x = np.asarray(x, dtype=np.float64)
    if peak is not None:
        x = x / max(1e-9, np.abs(x).max()) * peak
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes())


def loudness(path_or_args):
    args = path_or_args if isinstance(path_or_args, list) else ['-i', str(path_or_args)]
    r = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', *args, '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True, encoding='utf-8', errors='ignore')
    summ = r.stderr[r.stderr.rfind('Summary:'):]
    i = re.search(r'I:\s+(-?[\d.]+|-inf) LUFS', summ)
    p = re.search(r'Peak:\s+(-?[\d.]+|-inf) dBFS', summ)
    f = lambda m: float(m.group(1)) if m and m.group(1) != '-inf' else float('-inf')
    return f(i), f(p)


def duration(path):
    out = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(path)], capture_output=True, text=True).stdout.strip()
    return float(out or 0)


def clip_path(name, key):
    h = hashlib.sha1(json.dumps(key, sort_keys=True).encode()).hexdigest()[:8]
    LIB.mkdir(parents=True, exist_ok=True)
    return LIB / f'{name}-{h}.wav'


def npx():
    return 'npx.cmd' if sys.platform == 'win32' else 'npx'


def chapter_fp(slug, n):
    """What a chapter's render depends on: its JSON, timeline, the outline, its audio, the engine. Changes mean re-render."""
    return fingerprint(ch_dir(slug, n) / 'chapter.json', ch_dir(slug, n) / 'timeline.json', ep_dir(slug) / 'outline.json',
                       STUDIO / 'public' / slug / ch_name(n), STUDIO / 'src' / 'engine')


def text_sha(text):
    return hashlib.sha1(text.encode('utf-8')).hexdigest()[:12]


def plan_src(slug, n):
    """What a chapter's plan depends on: chapter.json without the review flag and the sound section, and the words."""
    ch = load_json(ch_dir(slug, n) / 'chapter.json', {}) or {}
    ch = {k: v for k, v in ch.items() if k not in ('board_ok', 'sound')}
    words = (ch_dir(slug, n) / 'words.json')
    return hashlib.sha1((json.dumps(ch, sort_keys=True) + (words.read_text(encoding='utf-8') if words.exists() else '')).encode()).hexdigest()[:12]
