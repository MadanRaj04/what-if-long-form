"""The motion check (per chapter): frame grids from a render, one sheet per shot, each frame labelled, so a walk, a
fall, a paste or a punch-in can be read at a glance without scrubbing. Render a fast draft first:
    python <skill>/scripts/render.py <slug> 3 --draft
    python <skill>/scripts/motiongrid.py <slug> 3 [S3 S5 ...] [--draft] [--step 2]
    python <skill>/scripts/motiongrid.py <slug> 3 --range 120:180 --draft
Writes out/<slug>/chNN/motion/<shot>.jpg
"""
import subprocess, sys

from PIL import Image, ImageDraw, ImageFont

from wi import ch_dir, load_json, need_studio, out_dir

need_studio()
args = sys.argv[1:]
slug, n = args[0], int(args[1])


def opt(name, default=None):
    return args[args.index(name) + 1] if name in args else default


video = str(out_dir(slug) / ('drafts' if '--draft' in args else 'chapters') / f'ch{n:02d}.mp4')
step = int(opt('--step', 2))
tl = load_json(ch_dir(slug, n) / 'timeline.json')
out = out_dir(slug, n) / 'motion'
out.mkdir(exist_ok=True)
skip = {opt('--step'), opt('--range')}
want = [a for a in args[2:] if not a.startswith('--') and a not in skip]
jobs = []
if opt('--range'):
    a, b = map(int, opt('--range').split(':'))
    jobs.append((f'range-{a}-{b}', list(range(a, b + 1, step))))
else:
    for s in tl['shots']:
        if want and s['id'] not in want:
            continue
        frames = []
        for g in tl['segments']:
            if g['shot'] == s['id']:
                frames += list(range(g['a'], g['b'], step))
        jobs.append((s['id'], frames[:60]))
try:
    font = ImageFont.truetype('arial.ttf', 22)
except OSError:
    font = ImageFont.load_default()
W, H, cols = 480, 270, 6
for name, frames in jobs:
    rows = (len(frames) + cols - 1) // cols
    sheet = Image.new('RGB', (cols * W, max(1, rows) * H))
    for i, f in enumerate(frames):
        raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', video, '-vf', f'select=eq(n\\,{f}),scale={W}:{H}', '-vframes', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'],
                             capture_output=True, check=True).stdout
        tmp = out / '_f.png'
        tmp.write_bytes(raw)
        im = Image.open(tmp).convert('RGB')
        dr = ImageDraw.Draw(im)
        dr.rectangle([0, 0, 64, 28], fill=(0, 0, 0))
        dr.text((5, 2), str(f), fill=(255, 255, 0), font=font)
        sheet.paste(im, ((i % cols) * W, (i // cols) * H))
    p = out / f'{name}.jpg'
    sheet.save(p, quality=85)
    print(p)
(out / '_f.png').unlink(missing_ok=True)
