"""Step 7 (per chapter): the sound. Builds the effects, the room ambience and the music bed for a chapter, lines every
hit up on its frame, ducks the music under the voice and sets the levels. Free by default: everything comes from your
own files in library/ first, then from synth.py. Nothing to write for a good first pass: "auto" reads the shots and
adds a sound for every visible action (a selection box, a paste, a stamp, a walk, a chapter card, a change of place,
the power's look) and a bed for every location.

    python <skill>/scripts/sfx.py <slug> <chapter | all> [--dry]

chapter.json "sound" (all optional):
  "auto": true                      the automatic events and ambiences (default on)
  "events": [[cue, clip, gain, align, until], ...]   your own, on top: cue like plan.py ("S3+4", "word+2", "f:120")
                                    align "onset" (the attack lands on the cue), "peak" or "end"; until = where to cut it
  "repeats": [{"at": cue, "clip": "tick", "n": 10, "every": 3, "gain": [0.1, 0.2], "pitch": [0.9, 1.2]}]
  "clips": {"door": {"file": "door.wav"}, "zap": {"synth": "glitch", "dur": 0.4, "pitch": 1.3}, "boom2": ["prompt", 1.5]}
  "music": {"mood": "tense", "file": "my-track.mp3", "until": "S9", "gain_lu": -12} or false
  "ambience": false                 no room beds
  "levels": {"sfx_lu": -3, "bed_lu": -21, "music_lu": -12}   loudness of each stem against the voice
A clip name is found in this order: "clips" above, library/sfx/<name>.wav|mp3 (your recordings), then the synth list
(python synth.py demo to hear them all). A ["prompt", seconds] clip uses ElevenLabs when outline "sound" has
"engine": "elevenlabs" and a key is set; otherwise the prompt picks the closest free synth.
"""
import hashlib, json, sys, time

import numpy as np

import synth
from wi import (SR, LIB, MUSIC_LIB, SKILL, api, ch_dir, chapters, decode, env_value, find_word, load_chapter, load_json, load_outline, log_cost,
                loudness, need_studio, out_dir, pub_dir, resolve, save_json, stem, write_wav)

need_studio()
args = [a for a in sys.argv[1:] if not a.startswith('--')]
if len(args) < 2:
    raise SystemExit('usage: sfx.py <slug> <chapter | all> [--dry]')
slug = args[0]
dry = '--dry' in sys.argv
outline = load_outline(slug)
todo = chapters(slug) if args[1] == 'all' else [int(args[1])]
AMB = {'study': 'room', 'studyNight': 'night', 'kitchen': 'room', 'bedroom': 'night', 'classroom': 'murmur', 'stairwell': 'room', 'rooftop': 'wind',
       'office': 'hum', 'street': 'city', 'schematic': 'hum', 'sky': 'wind'}
CACHE = {}


def h(s):
    return int(hashlib.sha1(str(s).encode()).hexdigest()[:6], 16)


def eleven(name, prompt, secs):
    p = LIB / f'{name}-{hashlib.sha1(f"{prompt}|{secs}".encode()).hexdigest()[:8]}.mp3'
    if not p.exists():
        if dry:
            print(f'  would generate {name} with ElevenLabs')
            return None
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(api('/v1/sound-generation?output_format=mp3_44100_128', {'text': prompt, 'duration_seconds': secs, 'prompt_influence': 0.45}))
        log_cost(slug, f'sound {name}', 0, f'{secs} s clip; check the usage page for its credits')
    return decode(p)


def clip(name, spec_clips, engine, dur=None, pitch=1.0, seed=1):
    key = (name, dur, round(pitch, 3), seed)
    if key in CACHE:
        return CACHE[key]
    x, src = None, ''
    spec = spec_clips.get(name)
    if isinstance(spec, str):
        spec = {'synth': spec[6:]} if spec.startswith('synth:') else {'file': spec[5:]} if spec.startswith('file:') else {'synth': spec}
    if isinstance(spec, list):
        prompt, secs = spec[0], float(spec[1])
        if engine == 'elevenlabs' and env_value('ELEVENLABS_API_KEY'):
            x, src = eleven(name, prompt, secs), 'elevenlabs'
        if x is None:
            x, src = synth.make(synth.from_prompt(prompt) if synth.from_prompt(prompt) != 'music' else 'shimmer', secs if synth.from_prompt(prompt) in synth.BEDS else None, pitch, seed), 'synth (from prompt)'
    elif isinstance(spec, dict):
        if spec.get('file'):
            f = LIB / spec['file']
            if not f.exists():
                raise SystemExit(f'clip "{name}": no file {f}')
            x, src = decode(f), 'file'
        else:
            x, src = synth.make(spec.get('synth', name), spec.get('dur', dur), spec.get('pitch', pitch), spec.get('seed', seed)), 'synth'
    else:
        for ext in ('wav', 'mp3', 'ogg', 'flac'):
            f = LIB / f'{name}.{ext}'
            if f.exists():
                x, src = decode(f), 'library'
                break
        if x is None:
            if name not in synth.ALL:
                raise SystemExit(f'Unknown clip "{name}": define it in "clips", put {name}.wav in library/sfx/, or use a synth: {", ".join(sorted(synth.ALL))}')
            x, src = synth.make(name, dur, pitch, seed), 'synth'
    x = x / max(1e-9, np.abs(x).max())
    CACHE[key] = (x, src)
    return CACHE[key]


def movavg(x, k):
    """A centred moving average of length k, in linear time (np.convolve is quadratic on a whole chapter)."""
    k = max(1, int(k))
    c = np.cumsum(np.concatenate([np.zeros(1), x]))
    y = (c[k:] - c[:-k]) / k
    pad = len(x) - len(y)
    return np.concatenate([np.full(pad // 2, y[0] if len(y) else 0), y, np.full(pad - pad // 2, y[-1] if len(y) else 0)])


def onset(x, mode):
    a = np.abs(x)
    win = max(1, int(0.01 * SR))
    sm = movavg(a, win)
    if mode == 'peak':
        return int(np.argmax(sm))
    if mode == 'end':
        return len(x)
    return int(np.argmax(sm > 0.2 * sm.max()))


def put(buf, frame, x, gain, fps, align='onset', cut=None):
    i = int(frame / fps * SR) - onset(x, align)
    if i < 0:
        x, i = x[-i:], 0
    if cut is not None:
        nkeep = max(0, int(cut / fps * SR) - i)
        x = x[:nkeep].copy()
        f = min(len(x), int(0.08 * SR))
        if f:
            x[-f:] *= np.linspace(1, 0, f)
    j = min(len(buf), i + len(x))
    if j > i:
        buf[i:j] += x[: j - i] * gain


def lufs(x, tmpname):
    if np.abs(x).max() < 1e-6:
        return float('-inf')
    p = out_dir(slug) / f'_{tmpname}.wav'
    write_wav(p, x, peak=0.9)
    L, _ = loudness(p)
    p.unlink(missing_ok=True)
    return L + 20 * np.log10(np.abs(x).max() / 0.9)


# ---------------------------------------------------------------- automatic events from the shots
def auto_events(ch, tl, fps):
    shots = {s['id']: s for s in ch.get('shots', [])}
    segs = tl['segments']
    ev = []  # (frame, clip, gain, align, until, pitch)

    def first_seen(sid):
        return next((s for s in segs if s['shot'] == sid and s['t1'] >= s['t0']), None)

    def at(sid, tl_local):
        s = first_seen(sid)
        if not s or tl_local < s['t0'] or tl_local >= s['t0'] + (s['b'] - s['a']) + 1:
            # the moment isn't on screen: drop it rather than mistime it
            return None
        return s['a'] + (tl_local - s['t0'])

    prev_set = None
    for k, s in enumerate(segs):
        sp = shots.get(s['shot'], {})
        r = sp.get('recipe')
        cur_set = sp.get('set') or prev_set
        if k > 0 and not s.get('zoom') and segs[k - 1]['shot'] != s['shot']:
            if r == 'chapter':
                ev += [(s['a'], 'riser', 0.28, 'end', None, 1.0), (s['a'], 'boom', 0.42, 'onset', None, 1.0)]
            elif r == 'title':
                ev += [(s['a'], 'riser', 0.2, 'end', None, 1.1), (s['a'], 'boom', 0.32, 'onset', None, 0.9)]
            elif r == 'schematic' and shots.get(segs[k - 1]['shot'], {}).get('recipe') != 'schematic':
                ev.append((s['a'], 'swoosh', 0.2, 'peak', None, 0.8))
            elif cur_set != prev_set and r not in ('insert', 'topdown'):
                ev.append((s['a'], 'swoosh', 0.16, 'peak', None, 1.0 + 0.1 * (k % 3)))
        if (sp.get('camera') or {}).get('move') == 'crashZoom' and not s.get('zoom'):
            ev.append((s['a'] + 3, 'whoosh', 0.3, 'peak', None, 1.3))
        prev_set = cur_set if r not in ('chapter', 'schematic') else prev_set
    # the power's look: its sound at the start of each run
    look_sound = (outline.get('power') or {}).get('sound', 'shimmer')
    run_prev = None
    for s in segs:
        lk = s.get('look')
        if lk and (not run_prev or run_prev.get('look') != lk or run_prev['b'] != s['a']):
            ev += [(s['a'], look_sound, 0.38, 'onset', None, 1.0), (s['a'], 'whoosh', 0.14, 'peak', None, 1.5)]
        run_prev = s
    for sid, sp in shots.items():
        for u in sp.get('ui', []):
            t = u.get('t', 0)
            kind = u.get('kind')
            m = {'marquee': ('select', 0.3), 'toast': ('pop', 0.25), 'float': ('pop', 0.2), 'sparkle': ('sparkle', 0.25), 'rings': ('shimmer', 0.2),
                 'dizzy': ('dizzy', 0.25), 'question': ('pop', 0.3), 'stamp': ('stamp', 0.45), 'hud': ('click', 0.2), 'arrow': ('swoosh', 0.1), 'label': ('click', 0.15)}
            if kind == 'tag':
                f = at(sid, t)
                if f is not None:
                    ev.append((f, 'pop', 0.2, 'onset', None, 1.1))
                    if u.get('mark'):
                        ev.append((f + 8, 'ding' if u['mark'] == 'check' else 'buzzer', 0.3, 'onset', None, 1.0))
            elif kind == 'dial' and u.get('count'):
                c = u['count']
                for q in range(min(24, max(1, int((c[3] - c[2]) / 5)))):
                    f = at(sid, c[2] + q * 5)
                    if f is not None:
                        ev.append((f, 'tick', 0.08, 'onset', None, 1.0 + 0.02 * q))
            elif kind in m:
                f = at(sid, t)
                if f is not None:
                    ev.append((f, m[kind][0], m[kind][1], 'onset', None, 1.0))
        for j, p in enumerate(sp.get('props', [])):
            if p.get('paste') is not None and (f := at(sid, p['paste'])) is not None:
                ev.append((f, 'paste', 0.45, 'onset', None, 1.0 + 0.05 * (j % 3)))
            if p.get('drop') is not None and (f := at(sid, p['drop'])) is not None:
                ev.append((f, 'thud', 0.4, 'onset', None, 1.0))
            if p.get('t') is not None and (f := at(sid, p['t'])) is not None:
                ev.append((f, 'pop', 0.18, 'onset', None, 1.0 + 0.07 * (j % 4)))
            if p.get('glitch') and (f := at(sid, 2)) is not None:
                ev.append((f, 'glitch', 0.18, 'onset', None, 1.0))
        for c in sp.get('cast', []):
            if c.get('paste') is not None and (f := at(sid, c['paste'])) is not None:
                ev.append((f, 'paste', 0.5, 'onset', None, 0.9))
            for fr, pose in (c.get('act') or [])[1:]:
                snd = {'shock': ('gasp', 0.2), 'scared': ('gasp', 0.18), 'cheer': ('sparkle', 0.2), 'fist': ('thud', 0.15), 'stop': ('whoosh', 0.12), 'point': ('click', 0.08)}.get(pose)
                if snd and (f := at(sid, fr)) is not None:
                    ev.append((f, snd[0], snd[1], 'onset', None, 1.0))
            if c.get('walk'):
                w0 = c['walk'].get('from', 0)
                for q in range(12):
                    if (f := at(sid, w0 + 4 + q * 15)) is not None:
                        ev.append((f, 'step', 0.16, 'onset', None, 0.9 + 0.15 * (q % 2)))
        d = sp.get('diagram')
        if d:
            lay = d.get('layout')
            if lay == 'equation':
                for k in range(min(3, len(d.get('items', [])))):
                    if (f := at(sid, 6 + k * 14)) is not None:
                        ev.append((f, 'pop', 0.2, 'onset', None, 0.9 + 0.12 * k))
            if lay in ('timeline', 'list'):
                for k in range(min(6, len(d.get('items', [])))):
                    if (f := at(sid, (8 if lay == 'timeline' else 4) + k * 12)) is not None:
                        ev.append((f, 'pop' if lay == 'timeline' else 'tick', 0.18, 'onset', None, 1.0 + 0.06 * k))
            if lay == 'compare':
                for k in range(min(4, len(d.get('bars', [])))):
                    if (f := at(sid, 4 + k * 10)) is not None:
                        ev.append((f, 'swoosh', 0.12, 'peak', None, 0.9 + 0.1 * k))
            if lay == 'icons' and (f := at(sid, 6)) is not None:
                ev.append((f, 'shimmer', 0.22, 'onset', None, 1.0))
            if d.get('count'):
                c0 = d['count'].get('t', 8)
                dur = d['count'].get('dur', 34)
                for q in range(min(25, dur // 3)):
                    if (f := at(sid, c0 + q * 3)) is not None:
                        ev.append((f, 'tick', 0.07, 'onset', None, 1.0 + 0.015 * q))
            if d.get('dial'):
                for q in range(16):
                    if (f := at(sid, d['dial'].get('t', 10) + q * 4)) is not None:
                        ev.append((f, 'tick', 0.06, 'onset', None, 0.9))
            if d.get('stamp'):
                L = next((x['len'] for x in tl['shots'] if x['id'] == sid), 90)
                if (f := at(sid, d.get('stampT', max(20, L - 34)))) is not None:
                    ev.append((f, 'stamp', 0.5, 'onset', None, 1.0))
    for e in tl.get('fx', []):
        if e.get('kind') == 'flash':
            ev.append((e['f'], 'thud', 0.28, 'onset', None, 0.8))
    return ev


def ambience_runs(ch, tl):
    shots = {s['id']: s for s in ch.get('shots', [])}
    runs, cur = [], None
    for s in tl['segments']:
        sp = shots.get(s['shot'], {})
        r = sp.get('recipe')
        kind = AMB.get(sp.get('set')) if r not in ('chapter', 'insert', 'topdown', 'title') or sp.get('set') else None
        if r == 'schematic':
            kind = 'hum'
        if kind is None:
            kind = cur[0] if cur else 'room'
        if cur and cur[0] == kind and cur[2] == s['a']:
            cur[2] = s['b']
        else:
            cur = [kind, s['a'], s['b']]
            runs.append(cur)
    return runs


def music_for(ch, n, dur):
    M = ch.get('sound', {}).get('music', {})
    if M is False:
        return None, 'none'
    mood = (M or {}).get('mood') or ch.get('mood') or next((c.get('mood') for c in outline.get('chapters', []) if int(c['n']) == n), 'playful')
    if mood == 'none':
        return None, 'none'
    if M and M.get('file'):
        f = MUSIC_LIB / M['file']
        if not f.exists():
            f = MUSIC_LIB / mood / M['file']
        if not f.exists():
            raise SystemExit(f'music file {M["file"]} not found in library/music/')
        x, src = decode(f), f'file {f.name}'
    else:
        files = sorted([p for p in (MUSIC_LIB / mood).glob('*') if p.suffix.lower() in ('.mp3', '.wav', '.ogg', '.flac', '.m4a')]) if (MUSIC_LIB / mood).exists() else []
        if files:
            f = files[h(f'{slug}{n}') % len(files)]
            x, src = decode(f), f'library/music/{mood}/{f.name}'
        else:
            x, src = synth.music(mood, dur + 2, seed=h(f'{slug}-{n}') % 9973), f'synth ({mood})'
    need = int(dur * SR)
    if len(x) < need:  # loop with a crossfade
        xf = int(1.5 * SR)
        y = x.copy()
        while len(y) < need:
            ramp = np.linspace(0, 1, xf)
            y[-xf:] = y[-xf:] * (1 - ramp) + x[:xf] * ramp
            y = np.concatenate([y, x[xf:]])
        x = y
    return x[:need], src


def mix(n):
    ch = load_chapter(slug, n)
    tl = load_json(ch_dir(slug, n) / 'timeline.json')
    if not tl or tl.get('placeholder'):
        raise SystemExit(f'Chapter {n} has no real timeline yet: run voice.py and plan.py first.')
    words = load_json(ch_dir(slug, n) / 'words.json', [])
    fps = tl['fps']
    ids = [s['id'] for s in tl['shots']]
    cue = lambda c: resolve(c, words, fps, tl['segments'], ids)
    S = ch.get('sound', {}) or {}
    OS = outline.get('sound', {}) or {}
    engine = OS.get('engine', 'free')
    clips = {**OS.get('clips', {}), **S.get('clips', {})}
    DUR = tl['total'] / fps + 0.6
    n_s = int(DUR * SR)
    events = auto_events(ch, tl, fps) if S.get('auto', True) else []
    for e in S.get('events', []):
        events.append((cue(e[0]), e[1], float(e[2]), e[3] if len(e) > 3 and e[3] else 'onset', cue(e[4]) if len(e) > 4 and e[4] else None, 1.0))
    if dry:
        used = sorted({e[1] for e in events})
        print(f'chapter {n}: {len(events)} events using {", ".join(used)}')
        return
    eff = np.zeros(n_s)
    srcs = {}
    for f, name, gain, align, until, pitch in sorted(events, key=lambda e: e[0]):
        x, src = clip(name, clips, engine, None, pitch, 1)
        srcs[name] = src
        put(eff, f, x, gain, fps, align, until)
    for r in S.get('repeats', []):
        base, src = clip(r['clip'], clips, engine)
        srcs[r['clip']] = src
        g0, g1 = r.get('gain', [0.3, 0.3])
        p0, p1 = r.get('pitch', [1, 1])
        start = cue(r['at'])
        for i in range(r['n']):
            k = p0 + (p1 - p0) * ((i * 37) % 11) / 10
            shifted = np.interp(np.arange(0, len(base), k), np.arange(len(base)), base)
            put(eff, start + r.get('every', 2) * i, shifted, g0 + (g1 - g0) * ((i * 53) % 7) / 6, fps)
    bed = np.zeros(n_s)
    if S.get('ambience', True):
        for kind, a, b in ambience_runs(ch, tl):
            L = (b - a) / fps + 0.6
            x, src = clip(kind, clips, engine, L, 1.0, h(f'{slug}{n}{a}') % 997)
            x = x.copy()
            fl = min(len(x) // 3, int(0.3 * SR))
            if fl:
                x[:fl] *= np.linspace(0, 1, fl)
                x[-fl:] *= np.linspace(1, 0, fl)
            put(bed, max(0, a - 0.15 * fps), x, 1.0, fps)
            srcs[f'bed:{kind}'] = src
    music, msrc = music_for(ch, n, DUR)
    vpath = stem(slug, n, 'voice')
    if not vpath:
        raise SystemExit(f'No voice for chapter {n}: run voice.py first.')
    V = decode(vpath)
    V = np.pad(V, (0, max(0, n_s - len(V))))[:n_s]
    # duck the music under the voice: about -7 dB while someone speaks, with smooth edges
    if music is not None:
        M = ch.get('sound', {}).get('music') or {}
        if M.get('until'):
            u = int(cue(M['until']) / fps * SR)
            fo = int(0.25 * SR)
            music[max(0, u - fo):u] *= np.linspace(1, 0, min(fo, u))
            music[u:] = 0
        env = np.sqrt(movavg(V ** 2, int(0.1 * SR)))
        act = (env > max(1e-4, np.percentile(env, 90) * 0.12)).astype(float)
        act = movavg(act, int(0.3 * SR))
        music = music * (1 - 0.55 * np.clip(act, 0, 1))
        fi, fo = int(0.8 * SR), int(1.2 * SR)
        music[:fi] *= np.linspace(0, 1, fi)
        music[-fo:] *= np.linspace(1, 0, fo)
    # ---- levels: each stem against the voice
    Lv = lufs(V, 'v')
    lv = {'sfx_lu': -3.0, 'bed_lu': -21.0, 'music_lu': -12.0}
    lv.update(OS.get('levels', {}))
    lv.update(S.get('levels', {}))

    def at_level(x, target, tag):
        L = lufs(x, tag)
        return x * 10 ** ((Lv + target - L) / 20) if np.isfinite(L) else x

    X = at_level(eff, lv['sfx_lu'], 'e') + at_level(bed, lv['bed_lu'], 'b')
    Mx = at_level(music, lv['music_lu'], 'm') if music is not None else np.zeros(n_s)
    peaks = {'voice': np.abs(V).max(), 'sfx': np.abs(X).max(), 'music': np.abs(Mx).max()}
    total_peak = np.abs(V + X + Mx).max()
    g = min(0.8, 0.95 / max(1e-9, total_peak), *(0.98 / max(1e-9, p) for p in peaks.values() if p > 0))
    pub = pub_dir(slug, n)
    write_wav(pub / 'sfx.wav', X, peak=0.98)
    if music is not None:
        write_wav(pub / 'music.wav', Mx, peak=0.98)
    elif (pub / 'music.wav').exists():
        (pub / 'music.wav').unlink()
    vols = {'voiceVol': round(g, 4), 'sfxVol': round(min(1, g * peaks['sfx'] / 0.98), 4)}
    if music is not None:
        vols['musicVol'] = round(min(1, g * peaks['music'] / 0.98), 4)
    audio = {k: v for k, v in tl.get('audio', {}).items() if not k.endswith('Vol') and k != 'music'}
    audio.update({'voice': f'{slug}/ch{n:02d}/{vpath.name}', 'sfx': f'{slug}/ch{n:02d}/sfx.wav', **vols, 'src': tl.get('src', '')})
    if music is not None:
        audio['music'] = f'{slug}/ch{n:02d}/music.wav'
    tl['audio'] = audio
    save_json(ch_dir(slug, n) / 'timeline.json', tl)
    save_json(out_dir(slug, n) / 'sound_events.json', [{'f': e[0], 'clip': e[1], 'gain': e[2]} for e in sorted(events, key=lambda e: e[0])])
    by = {}
    for v in srcs.values():
        by[v] = by.get(v, 0) + 1
    print(f'chapter {n}: {len(events)} events, {len(ambience_runs(ch, tl)) if S.get("ambience", True) else 0} ambience runs, music: {msrc}; sources {by}')
    print(f'  volumes {vols} (effects {lv["sfx_lu"]:+.0f} LU, beds {lv["bed_lu"]:+.0f} LU, music {lv["music_lu"]:+.0f} LU against the voice)')


for n in todo:
    mix(n)
if not dry:
    print(f'next: python {SKILL}/scripts/mixcheck.py {slug} {todo[0] if len(todo) == 1 else "all"}')
