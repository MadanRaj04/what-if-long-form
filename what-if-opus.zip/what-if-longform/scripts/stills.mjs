// Step 5 (per chapter): the storyboard stills. Renders one still per shot at its key frame from the chapter's
// <Id>ChNNBoard composition, bundling once. Run from the studio folder:
//   node <skill>/scripts/stills.mjs <slug> <chapter> [S1 S4 ...] [--scale 0.5]
//        writes out/<slug>/chNN/board/<shot>.png (with shot ids: only those, after a fix)
//   node <skill>/scripts/stills.mjs <slug> <chapter> --frames 120 300
//        frames of the chapter itself, to check a moment inside a shot: out/<slug>/chNN/frames/f0120.png
//   node <skill>/scripts/stills.mjs <slug> --thumb
//        the thumbnail (outline.json "thumbnail") at 1280 x 720: out/<slug>/thumbnail.png
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(path.resolve('package.json'));
const { bundle } = require('@remotion/bundler');
const { renderStill, selectComposition } = require('@remotion/renderer');

const args = process.argv.slice(2);
const slug = args[0];
if (!slug) throw new Error('usage: node stills.mjs <slug> <chapter> [shots...] | <slug> --thumb');
const outline = JSON.parse(fs.readFileSync(path.resolve('src/episodes', slug, 'outline.json'), 'utf8'));
const opt = (name) => (args.indexOf(name) >= 0 ? args[args.indexOf(name) + 1] : undefined);
const scale = Number(opt('--scale') ?? 0.5);
const serveUrl = await bundle({ entryPoint: path.resolve('src/index.ts'), publicDir: path.resolve('public') });

if (args.includes('--thumb')) {
  const composition = await selectComposition({ serveUrl, id: `${outline.id}Thumb` });
  const output = path.resolve('out', slug, 'thumbnail.png');
  fs.mkdirSync(path.dirname(output), { recursive: true });
  await renderStill({ serveUrl, composition, frame: 0, output, overwrite: true, scale: 2 / 3 });
  console.log(output);
  process.exit(0);
}

const n = Number(args[1]);
if (!n) throw new Error('give the chapter number: node stills.mjs <slug> <chapter>');
const NN = String(n).padStart(2, '0');
const id = `${outline.id}Ch${NN}`;
const tl = JSON.parse(fs.readFileSync(path.resolve('src/episodes', slug, `ch${NN}`, 'timeline.json'), 'utf8'));
const rest = args.slice(2).filter((a, i, all) => !a.startsWith('--') && all[i - 1] !== '--scale');

if (args.includes('--frames')) {
  const outDir = path.resolve('out', slug, `ch${NN}`, 'frames');
  fs.mkdirSync(outDir, { recursive: true });
  const composition = await selectComposition({ serveUrl, id });
  for (const fr of rest.map(Number)) {
    await renderStill({ serveUrl, composition, frame: fr, output: path.join(outDir, `f${String(fr).padStart(4, '0')}.png`), overwrite: true, scale });
    process.stdout.write(`${fr} `);
  }
} else {
  const outDir = path.resolve('out', slug, `ch${NN}`, 'board');
  fs.mkdirSync(outDir, { recursive: true });
  const composition = await selectComposition({ serveUrl, id: `${id}Board` });
  const want = rest.length ? rest : tl.shots.map((s) => s.id);
  for (const sid of want) {
    const i = tl.shots.findIndex((s) => s.id === sid);
    if (i < 0) throw new Error(`No shot ${sid} in chapter ${n}'s timeline (run plan.py after adding shots)`);
    await renderStill({ serveUrl, composition, frame: i, output: path.join(outDir, `${sid}.png`), overwrite: true, scale });
    process.stdout.write(`${sid} `);
  }
}
console.log('\ndone');
