"""Step 8 (per chapter, resumable): render chapters to video, then join them into the episode.

    python <skill>/scripts/render.py <slug>                 every chapter that changed since its last render, then the join
    python <skill>/scripts/render.py <slug> 3 4             just chapters 3 and 4
    python <skill>/scripts/render.py <slug> 3 --draft       half size, fast, to out/<slug>/drafts/ (for motiongrid.py)
    options: --concurrency 4   --force (render even if nothing changed)

A 60 to 90 s chapter takes several minutes on a laptop; a 9 minute episode can take an hour or more. Because each
chapter is its own render, you can stop any time and run it again: finished, unchanged chapters are skipped.
Writes out/<slug>/chapters/chNN.mp4 and, once all exist, out/<slug>/<slug>-raw.mp4 (master.py does the rest).
"""
import subprocess, sys, time

from wi import SKILL, STUDIO, ch_dir, chapter_fp, chapters, comp_id, duration, load_json, load_outline, need_studio, npx, out_dir, save_json, stem

need_studio()
args = sys.argv[1:]
if not args:
    raise SystemExit(__doc__)
slug = args[0]
nums = [int(a) for a in args[1:] if a.isdigit()]
draft = '--draft' in args
force = '--force' in args
conc = args[args.index('--concurrency') + 1] if '--concurrency' in args else None
outline = load_outline(slug)
allch = chapters(slug)
todo = nums or allch
od = out_dir(slug) / ('drafts' if draft else 'chapters')
od.mkdir(parents=True, exist_ok=True)
fpp = out_dir(slug) / 'chapters' / 'fingerprints.json'
fps_saved = load_json(fpp, {}) or {}
for n in todo:
    tl = load_json(ch_dir(slug, n) / 'timeline.json', {}) or {}
    if not tl or tl.get('placeholder'):
        raise SystemExit(f'Chapter {n} is not planned yet (python {SKILL}/scripts/plan.py {slug} {n}).')
    if not draft:
        if tl.get('draft_voice'):
            raise SystemExit(f'Chapter {n} still has the draft voice. Make the real one (voice.py) and re-plan before the final render, or use --draft.')
        if not tl.get('audio', {}).get('sfx'):
            print(f'  ! chapter {n} has no sound yet (sfx.py): rendering with the voice only')
    target = od / f'ch{n:02d}.mp4'
    fp = chapter_fp(slug, n)
    if not draft and not force and target.exists() and fps_saved.get(f'ch{n:02d}') == fp:
        print(f'chapter {n}: up to date, skipped')
        continue
    cmd = [npx(), 'remotion', 'render', 'src/index.ts', comp_id(outline, n), str(target), '--log', 'error']
    if draft:
        cmd += ['--scale', '0.5']
    if conc:
        cmd += ['--concurrency', conc]
    print(f'chapter {n}: rendering {tl["total"] / tl["fps"]:.0f} s ({" ".join(cmd[1:5])})')
    t0 = time.time()
    subprocess.run(cmd, cwd=STUDIO, check=True)
    print(f'chapter {n}: done in {time.time() - t0:.0f} s -> {target}')
    if not draft:
        fps_saved[f'ch{n:02d}'] = fp
        save_json(fpp, fps_saved)

if draft:
    print(f'drafts in {od}. Check motion: python {SKILL}/scripts/motiongrid.py {slug} {todo[0]} --draft')
    sys.exit(0)
missing = [n for n in allch if not (od / f'ch{n:02d}.mp4').exists()]
if missing:
    print(f'Chapters still to render: {missing}. Run render.py again when they are planned and have sound.')
    sys.exit(0)
lst = out_dir(slug) / 'chapters' / 'list.txt'
lst.write_text(''.join(f"file '{(od / f'ch{n:02d}.mp4').as_posix()}'\n" for n in allch), encoding='utf-8')
raw = out_dir(slug) / f'{slug}-raw.mp4'
subprocess.run(['ffmpeg', '-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', str(lst), '-c:v', 'copy', '-c:a', 'aac', '-b:a', '256k', '-ar', '48000', str(raw)], check=True)
print(f'joined {len(allch)} chapters: {raw} ({duration(raw) / 60:.2f} min)')
print(f'next: python {SKILL}/scripts/master.py {slug}')
