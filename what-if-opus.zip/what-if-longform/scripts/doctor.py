"""Is this machine ready? Checks every tool the pipeline needs and says how to fix what's missing.

    python <skill>/scripts/doctor.py          (from the studio folder, or anywhere for the system checks)
"""
import importlib, pathlib, shutil, subprocess, sys

ok = True


def line(good, what, fix=''):
    global ok
    print(('  ok   ' if good else '  MISSING ') + what + ('' if good else f'\n         -> {fix}'))
    if not good and fix and not fix.startswith('(optional'):
        ok = False


def ver(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=20).stdout.strip().splitlines()[0]
    except Exception:
        return ''


print('System')
nv = ver(['node', '--version'])
line(bool(nv) and int(nv.lstrip('v').split('.')[0]) >= 18, f'Node 18+ ({nv or "not found"})', 'install Node LTS from nodejs.org')
line(bool(shutil.which('npx') or shutil.which('npx.cmd')), 'npx', 'comes with Node')
line(bool(shutil.which('ffmpeg')), 'ffmpeg', 'Windows: winget install Gyan.FFmpeg   Mac: brew install ffmpeg   Linux: apt install ffmpeg')
line(bool(shutil.which('ffprobe')), 'ffprobe', 'comes with ffmpeg')
line(sys.version_info >= (3, 9), f'Python 3.9+ ({sys.version.split()[0]})', 'install Python 3.11 from python.org')
print('Python packages')
for mod, fix in [('numpy', 'pip install numpy'), ('PIL', 'pip install Pillow')]:
    try:
        importlib.import_module(mod)
        line(True, mod)
    except ImportError:
        line(False, mod, fix)
print('Voice (one is enough)')
for mod, what, fix in [('edge_tts', 'edge-tts: free online voice (default)', 'pip install edge-tts'),
                       ('kokoro', 'kokoro: free offline voice', '(optional) pip install kokoro soundfile, and espeak-ng'),
                       ('faster_whisper', 'faster-whisper: exact timings for your own recordings', '(optional) pip install faster-whisper')]:
    try:
        importlib.import_module(mod)
        line(True, what)
    except ImportError:
        line(False, what, fix)
cwd = pathlib.Path.cwd()
print('Studio')
if (cwd / 'src' / 'episodes').exists():
    line((cwd / 'node_modules' / 'remotion').exists(), 'npm install done', 'run: npm install   (in this folder)')
    line((cwd / 'src' / 'engine' / 'recipes').exists(), 'long-form engine in src/engine', 'copy <skill>/studio/src/engine over this studio\'s src/engine')
    eps = [p.name for p in (cwd / 'src' / 'episodes').iterdir() if (p / 'outline.json').exists()]
    print(f'  episodes: {", ".join(eps) or "none yet"}')
else:
    print('  (run from the studio folder to check it too)')
print('Ready.' if ok else 'Fix the MISSING lines above, then run doctor.py again.')
