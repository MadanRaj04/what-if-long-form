"""Step 0: start an episode, then its chapters.

    python <skill>/scripts/new.py <slug> "What if you could ...?" [--minutes 8]
        writes src/episodes/<slug>/outline.json: the whole story as 8 chapters with their beats, timings, word budgets
        and TODOs to fill in. Fill every TODO, then run check.py <slug>.

    python <skill>/scripts/new.py <slug> --chapters
        after the outline passes check.py: one folder per chapter (chNN/chapter.json) with the script lines to write,
        a chapter card as the first shot, and the glue code. Existing chapter files are never overwritten.
"""
import re, sys

from wi import SKILL, WPS, ch_dir, ep_dir, load_outline, need_studio, pascal, save_json, has_todo
from scaffold import scaffold

need_studio()
args = [a for a in sys.argv[1:] if not a.startswith('--')]
if not args:
    raise SystemExit(__doc__)
slug = args[0]
if not re.match(r'^[a-z0-9][a-z0-9-]*$', slug):
    raise SystemExit('The slug is the folder name: lower case letters, digits and hyphens, e.g. "pause-time".')

# The long form: the seven beats of the What If formula (references/formula.md), each given room, as 8 chapters.
BEATS = [
    ('Cold open', '1 cold open: three or four quick demos of the power (small and selfish, useful, a little uncanny), then the title card', 0.09, 'playful', 'the title card lands, then a line that promises the cost: "...but nobody told you the rules."'),
    ('The rules', '2 the premise and its rules: how it started, how it works, the first careful test, one rule we learn the hard way', 0.12, 'wonder', 'a rule we don\'t know yet: "That was rule one. Rule two, you find out on Tuesday."'),
    ('The fun part', '3 the fun part: escalating wins in everyday life (school, money, a friend, a crush): the best minute of the episode', 0.16, 'playful', 'one win goes slightly too far: "And that\'s when Mo noticed."'),
    ('Too far', '3b bigger and bolder: the hero gets greedy; the first small thing goes wrong (foreshadow the cost)', 0.12, 'tense', 'a sign something is off: "Your watch said 9:00. Your body said midnight."'),
    ('The catch', '4 the cost: the real science, one checked fact with a number ("That\'s real."), then its consequence on screen', 0.15, 'eerie', 'the cost turns personal: "And it gets worse. Because someone was watching."'),
    ('Someone noticed', '5 someone powerful notices: a man in a suit, a call, a car outside, an offer that is really a threat', 0.12, 'tense', 'the threat lands on family: "Then they mentioned your sister."'),
    ('The choice', '6 a moral choice with family at stake (the little sister): use the power one last time, whatever it costs', 0.13, 'sad', 'the choice is made: "So you did the one thing you swore you\'d never do."'),
    ('The ending', '7 climax and cliffhanger: the choice plays out, a twist, then a question for the comments (and "Part 2?")', 0.11, 'action', '(the last line of the episode: a question for the viewer, never a resolution)'),
]

if '--chapters' in sys.argv:
    o = load_outline(slug)
    if has_todo(o):
        raise SystemExit(f'outline.json still has TODOs. Fill them, run: python {SKILL}/scripts/check.py {slug}  and then make the chapters.')
    made = []
    for c in o['chapters']:
        n = int(c['n'])
        d = ch_dir(slug, n)
        d.mkdir(parents=True, exist_ok=True)
        p = d / 'chapter.json'
        if p.exists():
            continue
        words = int(c.get('seconds', 60) * WPS)
        shots = []
        if n > 1:
            shots.append({'id': 'S1', 'recipe': 'chapter', 'set': (c.get('sets') or ['sky'])[0], 'title': [f'PART {n}', c['title'].upper()], 'at': 'f:0', 'key': 30,
                          'note': 'the chapter card: the voice starts after it (the "lead" in voice.py)'})
        save_json(p, {
            'n': n,
            'title': c['title'],
            'beat': c['beat'],
            'mood': c.get('mood', 'playful'),
            'goal': c.get('goal', ''),
            'budget': f'about {words} words for {c.get("seconds", 60)} s; short lines, every line a picture',
            'script': [
                {'beat': 'open: a hook that pays off the last chapter\'s open loop' if n > 1 else 'demo 1 (small and selfish)', 'text': 'TODO'},
                {'beat': 'middle', 'text': 'TODO'},
                {'beat': 'end: the open loop into the next chapter' if n < len(o['chapters']) else 'end: the question for the comments', 'text': 'TODO'},
            ],
            'shots': shots,
            'fx': [],
            'sound': {'auto': True, 'events': []},
            'board_ok': False,
        })
        made.append(n)
    scaffold(slug)
    print(f'chapters made: {made or "none new"}. Next: write chapter 1\'s script lines, then: python {SKILL}/scripts/check.py {slug} 1')
    sys.exit(0)

topic = args[1] if len(args) > 1 else 'TODO: What if you could ...?'
minutes = float(sys.argv[sys.argv.index('--minutes') + 1]) if '--minutes' in sys.argv else 8.0
p = ep_dir(slug) / 'outline.json'
if p.exists():
    raise SystemExit(f'{p} already exists. Edit it, or choose another slug.')
ep_dir(slug).mkdir(parents=True, exist_ok=True)
total = minutes * 60
chs = []
for i, (title, beat, share, mood, loop) in enumerate(BEATS):
    secs = int(round(total * share / 5) * 5)
    chs.append({
        'n': i + 1, 'title': title, 'beat': beat, 'seconds': secs, 'words': int(secs * WPS), 'mood': mood,
        'goal': 'TODO: what happens in this chapter, in one or two sentences, in story terms',
        'sets': ['TODO: one to three of study, studyNight, kitchen, bedroom, classroom, stairwell, rooftop, office, street, sky, schematic'],
        'open_loop': f'TODO: the last line, an open loop into the next chapter. Example: {loop}',
    })
title2 = re.sub(r'^what if (you could )?', '', topic.strip().rstrip('?'), flags=re.I).upper()
save_json(p, {
    'id': pascal(slug),
    'slug': slug,
    'topic': topic,
    'title': ['WHAT IF YOU COULD', (title2 + '?') if title2 else 'TODO'],
    'youtube_title': topic,
    'logline': 'TODO: one sentence: you get the power, what it costs, who it puts in danger',
    'target_minutes': minutes,
    'power': {'word': 'TODO: the one word said every time it is used (Pause, Rewind, Copy...)', 'rule': 'TODO: how it works', 'limits': ['TODO: the rule we learn the hard way'],
              'look': 'power', 'sound': 'shimmer', 'color': '#7FD4FF'},
    'cast': {'you': 'pipHood', 'friend': 'mo', 'sister': 'sis', 'mum': 'mom', 'suit': 'suit'},
    'voice': {'provider': 'edge', 'voice': 'en-US-AndrewMultilingualNeural', 'rate': '+6%'},
    'sound': {'engine': 'free', 'levels': {'sfx_lu': -3, 'music_lu': -12}},
    'looks': {'power': {'saturate': 0.7, 'hue': -10, 'brightness': 1.04, 'chip': {'label': 'TODO: POWER WORD', 'icon': 'dot'}, 'tint': '#7FD4FF', 'tintO': 0.08, 'frame': True}},
    'thumbnail': {'set': 'rooftop', 'who': 'pipHood', 'expr': 'shock', 'lines': ['TODO', 'TWO WORDS'], 'accent': 'TODO', 'glint': 1},
    'science': [{'claim': 'TODO: the real fact with a number', 'working': 'TODO: the arithmetic, step by step', 'source': 'TODO: where it comes from'}],
    'chapters': chs,
    'end': {'question': 'TODO: the question for the comments', 'part2': True},
})
print(f'wrote {p}')
print(f'Fill every TODO (read {SKILL}/references/formula.md first), then: python {SKILL}/scripts/check.py {slug}')
