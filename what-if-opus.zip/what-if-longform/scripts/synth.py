"""Free sound: every effect, ambience and music bed the pipeline needs, synthesised with numpy. No account, no key, no
cost, nothing to download. Deterministic (same name and seed, same sound), so a clip never changes between renders.

    python <skill>/scripts/synth.py demo            writes out/synth-demo/ with one file per sound, to audition them
    python <skill>/scripts/synth.py pop 0.5         writes one sound to out/synth-demo/pop.wav

Effects: pop click tick whoosh swoosh riser boom thud drone sparkle shimmer ding chime bell buzzer select paste
         stamp glitch step heartbeat typing dizzy gasp
Beds:    room wind city night hum murmur
Music:   music(mood, seconds) with moods playful wonder tense eerie sad action triumph

Real recordings still sound better: drop .wav/.mp3 files into library/sfx/ (name them after the effect, e.g.
whoosh.wav) and library/music/<mood>/, and the pipeline uses yours first.
"""
import math, sys

import numpy as np

SR = 44100


def _t(d):
    return np.arange(int(max(0.01, d) * SR)) / SR


def _rng(seed):
    return np.random.default_rng(abs(int(seed)) % (2 ** 32))


def _env(n, a=0.005, r=0.2, curve=3.0):
    """Attack then exponential-ish release, n samples."""
    t = np.arange(n) / SR
    att = np.clip(t / max(a, 1e-4), 0, 1)
    rel = np.exp(-curve * np.clip(t - a, 0, None) / max(r, 1e-4))
    return att * rel


def _lp(x, cutoff):
    """One-pole low-pass; cutoff in Hz (scalar or array per sample)."""
    c = np.broadcast_to(np.asarray(cutoff, dtype=np.float64), x.shape)
    a = 1 - np.exp(-2 * np.pi * c / SR)
    y = np.empty_like(x)
    acc = 0.0
    # vectorised in blocks: exact recursion is cheap enough for clips under a minute
    for i in range(len(x)):
        acc += a[i] * (x[i] - acc)
        y[i] = acc
    return y


def _lp_fast(x, cutoff):
    """Static one-pole low-pass via FFT-friendly filtering (for long beds)."""
    from numpy.fft import rfft, irfft, rfftfreq
    n = len(x)
    f = rfftfreq(n, 1 / SR)
    H = 1 / np.sqrt(1 + (f / max(cutoff, 1)) ** 2)
    return irfft(rfft(x) * H, n)


def _bp_fast(x, lo, hi):
    from numpy.fft import rfft, irfft, rfftfreq
    n = len(x)
    f = rfftfreq(n, 1 / SR)
    H = ((f >= lo) & (f <= hi)).astype(float)
    # soft edges
    H = np.convolve(H, np.hanning(41) / np.hanning(41).sum(), mode='same')
    return irfft(rfft(x) * H, n)


def _add(buf, sig, o):
    """Mix sig into buf from sample o, clipped to buf's length."""
    if o >= len(buf) or o < 0:
        return buf
    L = min(len(sig), len(buf) - o)
    buf[o:o + L] += sig[:L]
    return buf


def _norm(x, peak=0.9):
    m = np.abs(x).max()
    return x / m * peak if m > 0 else x


def _sweep(f0, f1, d, curve='exp'):
    t = _t(d)
    if curve == 'exp':
        f = f0 * (f1 / f0) ** (t / d)
    else:
        f = f0 + (f1 - f0) * t / d
    return np.sin(2 * np.pi * np.cumsum(f) / SR)


def _fade(x, fi=0.0008, fo=0.02):
    n = len(x)
    a = min(n, int(fi * SR))
    b = min(n, int(fo * SR))
    if a:
        x[:a] *= np.linspace(0, 1, a)
    if b:
        x[-b:] *= np.linspace(1, 0, b)
    return x


# ---------------------------------------------------------------- one-shots
def pop(d=0.35, pitch=1.0, seed=1):
    t = _t(d)
    f = 900 * pitch * np.exp(-t * 18) + 260 * pitch
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * _env(len(t), 0.002, 0.07, 4)
    click = _rng(seed).normal(0, 1, len(t)) * _env(len(t), 0.0005, 0.006, 5) * 0.4
    return _fade(_norm(x + click))


def click(d=0.12, pitch=1.0, seed=2):
    t = _t(d)
    x = np.sin(2 * np.pi * 2400 * pitch * t) * _env(len(t), 0.0005, 0.012, 6)
    x += _rng(seed).normal(0, 1, len(t)) * _env(len(t), 0.0003, 0.004, 6) * 0.6
    return _fade(_norm(x))


def tick(d=0.08, pitch=1.0, seed=3):
    t = _t(d)
    x = np.sin(2 * np.pi * 1600 * pitch * t) * _env(len(t), 0.0005, 0.01, 6)
    return _fade(_norm(x, 0.7))


def whoosh(d=0.6, pitch=1.0, seed=4):
    n = int(d * SR)
    noise = _rng(seed).normal(0, 1, n)
    t = np.arange(n) / n
    shape = np.sin(np.pi * t) ** 2
    cut = 300 + 3200 * pitch * np.sin(np.pi * t) ** 1.5
    x = _lp(noise, cut) - 0.6 * _lp(noise, cut * 0.25)
    return _fade(_norm(x * shape))


def swoosh(d=0.35, pitch=1.3, seed=5):
    return whoosh(d, pitch, seed)


def riser(d=1.2, pitch=1.0, seed=6):
    n = int(d * SR)
    t = np.arange(n) / n
    noise = _rng(seed).normal(0, 1, n)
    x = _lp(noise, 400 + 5000 * t ** 2) * t ** 2
    tone = _sweep(180 * pitch, 900 * pitch, d) * t ** 3 * 0.5
    return _fade(_norm(x + tone), 0.02, 0.01)


def boom(d=1.6, pitch=1.0, seed=7):
    t = _t(d)
    f = 70 * pitch * np.exp(-t * 2.2) + 34 * pitch
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * _env(len(t), 0.003, 0.9, 3)
    noise = _lp_fast(_rng(seed).normal(0, 1, len(t)), 600) * _env(len(t), 0.001, 0.25, 4) * 2.5
    x = np.tanh((body + noise) * 1.8)
    return _fade(_norm(x), 0.001, 0.2)


def thud(d=0.35, pitch=1.0, seed=8):
    t = _t(d)
    f = 120 * pitch * np.exp(-t * 14) + 48 * pitch
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * _env(len(t), 0.002, 0.16, 4)
    x += _lp_fast(_rng(seed).normal(0, 1, len(t)), 900) * _env(len(t), 0.001, 0.03, 4) * 1.5
    return _fade(_norm(np.tanh(x * 1.5)))


def drone(d=3.0, pitch=1.0, seed=9):
    t = _t(d)
    x = sum(np.sin(2 * np.pi * (55 * pitch * k + dt) * t + k) / k for k, dt in [(1, 0), (1, 0.7), (2, -0.4), (3, 0.3)])
    x = x * np.minimum(1, t / 0.15) * np.exp(-t / (d * 0.6))
    x += _lp_fast(_rng(seed).normal(0, 1, len(t)), 200) * 0.6 * np.exp(-t / (d * 0.5))
    return _fade(_norm(np.tanh(x)), 0.005, 0.4)


def _bell(freq, d, partials=((1, 1), (2.76, 0.5), (5.4, 0.25), (8.93, 0.12)), decay=1.0):
    t = _t(d)
    x = sum(a * np.sin(2 * np.pi * freq * p * t) * np.exp(-t * (2.5 + p) / decay) for p, a in partials)
    return x * np.minimum(1, t / 0.002)


def ding(d=0.9, pitch=1.0, seed=10):
    return _fade(_norm(_bell(1318 * pitch, d)))


def chime(d=1.2, pitch=1.0, seed=11):
    x = _bell(1046 * pitch, d) + 0.7 * np.concatenate([np.zeros(int(0.09 * SR)), _bell(1568 * pitch, d)])[: int(d * SR)]
    return _fade(_norm(x))


def bell(d=2.0, pitch=1.0, seed=12):
    return _fade(_norm(_bell(523 * pitch, d, decay=2.5)))


def sparkle(d=0.8, pitch=1.0, seed=13):
    n = int(d * SR)
    x = np.zeros(n)
    rng = _rng(seed)
    notes = [2093, 2349, 2637, 3136, 3520, 4186]
    for k in range(7):
        at = int((k * 0.07 + rng.random() * 0.03) * SR)
        if at >= n:
            break
        b = _bell(notes[rng.integers(len(notes))] * pitch, 0.35, ((1, 1), (2.0, 0.3)), 0.5)
        L = min(len(b), n - at)
        x[at:at + L] += b[:L] * (1 - k / 9)
    return _fade(_norm(x))


def shimmer(d=1.0, pitch=1.0, seed=14):
    t = _t(d)
    x = sum(np.sin(2 * np.pi * f * pitch * t + i) for i, f in enumerate([880, 1320, 1760, 2640])) * np.sin(np.pi * t / d) ** 2
    x *= 0.6 + 0.4 * np.sin(2 * np.pi * 9 * t)
    return _fade(_norm(x))


def select(d=0.5, pitch=1.0, seed=15):
    t = _t(d)
    x = _sweep(600 * pitch, 2400 * pitch, d) * np.sin(np.pi * t / d) * 0.6
    x += shimmer(d, 1.4 * pitch, seed) * 0.4
    return _fade(_norm(x))


def paste(d=0.6, pitch=1.0, seed=16):
    a = whoosh(0.25, 1.6 * pitch, seed) * 0.6
    b = pop(0.35, 1.2 * pitch, seed)
    x = np.zeros(int(d * SR))
    _add(x, a, 0)
    o = int(0.2 * SR)
    _add(x, b, o)
    _add(x, sparkle(0.4, pitch, seed) * 0.3, o)
    return _fade(_norm(x))


def stamp(d=0.5, pitch=1.0, seed=17):
    x = thud(d, 0.9 * pitch, seed)
    slap = _bp_fast(_rng(seed).normal(0, 1, len(x)), 800, 4000) * _env(len(x), 0.001, 0.03, 4)
    return _fade(_norm(x + slap * 0.8))


def glitch(d=0.8, pitch=1.0, seed=18):
    rng = _rng(seed)
    n = int(d * SR)
    x = np.zeros(n)
    i = 0
    while i < n:
        L = int(rng.uniform(0.01, 0.06) * SR)
        if rng.random() > 0.35:
            f = rng.uniform(80, 1400) * pitch
            seg = np.sign(np.sin(2 * np.pi * f * np.arange(L) / SR)) * rng.uniform(0.3, 1)
            seg = np.round(seg * 4) / 4
            x[i:i + L] = seg[: n - i]
        i += L
    return _fade(_norm(x, 0.7))


def buzzer(d=0.7, pitch=1.0, seed=19):
    t = _t(d)
    x = (np.sign(np.sin(2 * np.pi * 120 * pitch * t)) + np.sign(np.sin(2 * np.pi * 123.5 * pitch * t))) * 0.5
    x = _lp_fast(x, 2200) * np.minimum(1, t / 0.01) * (t < d - 0.05)
    return _fade(_norm(x, 0.75))


def step(d=0.22, pitch=1.0, seed=20):
    t = _t(d)
    x = np.sin(2 * np.pi * 90 * pitch * t) * _env(len(t), 0.002, 0.05, 4)
    x += _bp_fast(_rng(seed).normal(0, 1, len(t)), 500, 3000) * _env(len(t), 0.001, 0.02, 4) * 0.7
    return _fade(_norm(x, 0.8))


def heartbeat(d=0.9, pitch=1.0, seed=21):
    x = np.zeros(int(d * SR))
    for at, g in [(0.0, 1.0), (0.22, 0.7)]:
        _add(x, thud(0.3, 0.6 * pitch, seed) * g, int(at * SR))
    return _fade(_norm(x))


def typing(d=1.2, pitch=1.0, seed=22):
    rng = _rng(seed)
    x = np.zeros(int(d * SR))
    at = 0.0
    while at < d - 0.05:
        _add(x, click(0.04, rng.uniform(0.7, 1.2) * pitch, int(at * 1000)) * rng.uniform(0.4, 1), int(at * SR))
        at += rng.uniform(0.06, 0.16)
    return _fade(_norm(x, 0.7))


def dizzy(d=1.2, pitch=1.0, seed=23):
    t = _t(d)
    f = 1500 * pitch + 300 * np.sin(2 * np.pi * 7 * t)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * (0.5 + 0.5 * np.sin(2 * np.pi * 5 * t)) * np.exp(-t / d)
    return _fade(_norm(x, 0.6))


def gasp(d=0.5, pitch=1.0, seed=24):
    n = int(d * SR)
    noise = _rng(seed).normal(0, 1, n)
    t = np.arange(n) / n
    x = _bp_fast(noise, 700 * pitch, 2600 * pitch) * np.sin(np.pi * t) ** 0.6 * (1 - t)
    return _fade(_norm(x, 0.6))


# ---------------------------------------------------------------- beds (ambiences), any length
def _brown(n, seed, slope=2.0):
    """Coloured noise by spectral shaping (slope 1 pink, 2 brown), no drift at the edges."""
    from numpy.fft import rfft, irfft, rfftfreq
    w = _rng(seed).normal(0, 1, n)
    f = rfftfreq(n, 1 / SR)
    f[0] = f[1] if len(f) > 1 else 1
    y = irfft(rfft(w) / f ** (slope / 2), n)
    return y / (np.abs(y).max() + 1e-9)


def room(d=10.0, pitch=1.0, seed=31):
    n = int(d * SR)
    x = _lp_fast(_brown(n, seed), 500) * 0.8 + np.sin(2 * np.pi * 60 * _t(d)) * 0.03
    return _fade(_norm(x, 0.5), 0.3, 0.3)


def wind(d=10.0, pitch=1.0, seed=32):
    n = int(d * SR)
    t = _t(d)
    gust = 0.55 + 0.45 * np.sin(2 * np.pi * 0.11 * t + 1) * np.sin(2 * np.pi * 0.047 * t)
    x = _bp_fast(_rng(seed).normal(0, 1, n), 150 * pitch, 1200 * pitch) * gust
    return _fade(_norm(x, 0.5), 0.5, 0.5)


def city(d=10.0, pitch=1.0, seed=33):
    n = int(d * SR)
    t = _t(d)
    x = _lp_fast(_brown(n, seed), 300) * 0.9
    rng = _rng(seed + 1)
    for k in range(int(d / 3) + 1):
        at = rng.uniform(0, d)
        car = np.exp(-((t - at) / 1.6) ** 2) * _bp_fast(rng.normal(0, 1, n), 80, 700) * 0.6
        x += car
    return _fade(_norm(x, 0.5), 0.5, 0.5)


def night(d=10.0, pitch=1.0, seed=34):
    n = int(d * SR)
    t = _t(d)
    x = room(d, pitch, seed) * 0.5
    rng = _rng(seed)
    for k in range(int(d * 1.4)):
        at = rng.uniform(0, d - 0.3)
        o = int(at * SR)
        L = int(0.12 * SR)
        tt = np.arange(L) / SR
        chirp = np.sin(2 * np.pi * 4300 * tt) * (np.sin(2 * np.pi * 30 * tt) > 0) * np.sin(np.pi * tt / 0.12)
        _add(x, chirp * 0.12, o)
    return _fade(_norm(x, 0.5), 0.5, 0.5)


def hum(d=10.0, pitch=1.0, seed=35):
    t = _t(d)
    x = sum(np.sin(2 * np.pi * 50 * pitch * k * t) / k ** 1.5 for k in range(1, 6)) * (0.8 + 0.2 * np.sin(2 * np.pi * 0.2 * t))
    x += _lp_fast(_rng(seed).normal(0, 1, len(t)), 300) * 0.4
    return _fade(_norm(x, 0.4), 0.5, 0.5)


def murmur(d=10.0, pitch=1.0, seed=36):
    n = int(d * SR)
    t = _t(d)
    rng = _rng(seed)
    x = np.zeros(n)
    for k in range(8):
        f0 = rng.uniform(140, 260) * pitch
        syl = 0.5 + 0.5 * np.sign(np.sin(2 * np.pi * rng.uniform(2.5, 5) * t + k))
        x += _bp_fast(rng.normal(0, 1, n), f0, f0 * 6) * syl * rng.uniform(0.3, 1)
    return _fade(_norm(_lp_fast(x, 2500), 0.45), 0.5, 0.5)


# ---------------------------------------------------------------- music beds
NOTE = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5, 'F#': 6, 'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}
MOODS = {
    #           bpm  key  scale                    chords (scale degrees)         instruments
    'playful': (112, 'F', [0, 2, 4, 5, 7, 9, 11], [[0, 2, 4], [3, 5, 7], [4, 6, 8], [0, 2, 4]], 'pluck bell bass kick'),
    'wonder': (84, 'D', [0, 2, 4, 5, 7, 9, 11], [[0, 2, 4], [5, 7, 9], [3, 5, 7], [4, 6, 8]], 'pad bell bass'),
    'tense': (96, 'A', [0, 2, 3, 5, 7, 8, 10], [[0, 2, 4], [0, 2, 4], [5, 7, 9], [6, 8, 10]], 'pad pulse bass tick'),
    'eerie': (70, 'C#', [0, 1, 3, 5, 7, 8, 10], [[0, 2, 4], [1, 3, 5], [0, 2, 4], [6, 8, 10]], 'pad bell drone'),
    'sad': (72, 'E', [0, 2, 3, 5, 7, 8, 10], [[0, 2, 4], [5, 7, 9], [2, 4, 6], [6, 8, 10]], 'pad pluck bass'),
    'action': (128, 'G', [0, 2, 3, 5, 7, 8, 10], [[0, 2, 4], [5, 7, 9], [6, 8, 10], [4, 6, 8]], 'pulse bass kick hat pad'),
    'triumph': (104, 'C', [0, 2, 4, 5, 7, 9, 11], [[0, 2, 4], [4, 6, 8], [5, 7, 9], [3, 5, 7]], 'pad bell bass kick'),
}


def _midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def _pluck(f, d, bright=1.0):
    t = _t(d)
    x = sum(np.sin(2 * np.pi * f * k * t) * np.exp(-t * (3 + k * 2.2 / bright)) / k for k in range(1, 7))
    return x * np.minimum(1, t / 0.003)


def _pad(f, d):
    t = _t(d)
    x = sum(np.sin(2 * np.pi * f * (1 + dt) * t + i) for i, dt in enumerate([0, 0.004, -0.0035, 0.5 * 0 + 0.0021]))
    x += 0.35 * sum(np.sin(2 * np.pi * 2 * f * (1 + dt) * t) for dt in [0.003, -0.002])
    env = np.minimum(1, t / min(0.6, d * 0.4)) * np.minimum(1, (d - t) / min(0.6, d * 0.4))
    return x * env * 0.5


def _bass(f, d):
    t = _t(d)
    x = np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t)
    return np.tanh(x * 1.4) * np.minimum(1, t / 0.01) * np.exp(-t * 1.5)


def _kick(d=0.4):
    t = _t(d)
    f = 120 * np.exp(-t * 25) + 45
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9)


def _hat(seed, d=0.06):
    return _bp_fast(_rng(seed).normal(0, 1, int(d * SR)), 6000, 12000) * _env(int(d * SR), 0.001, 0.02, 4)


def music(mood='playful', d=60.0, seed=1, pitch=1.0):
    """A looping bed for a chapter: chords, a melody of pentatonic-ish notes, bass and light percussion."""
    bpm, key, scale, prog, inst = MOODS.get(mood, MOODS['playful'])
    rng = _rng(seed)
    beat = 60 / bpm
    bar = beat * 4
    n = int(d * SR)
    x = np.zeros(n + int(3 * SR))
    root = 48 + NOTE[key]
    deg = lambda k: root + scale[k % 7] + 12 * (k // 7)

    def put(sig, at, g):
        o = int(at * SR)
        if o >= len(x):
            return
        L = min(len(sig), len(x) - o)
        x[o:o + L] += sig[:L] * g

    bars = int(d / bar) + 1
    melody = [0, 2, 4, 2, 5, 4, 2, 1]
    for b in range(bars):
        ch = prog[b % len(prog)]
        t0 = b * bar
        if 'pad' in inst:
            for k in ch:
                put(_pad(_midi(deg(k) + 12) * pitch, bar * 1.02), t0, 0.07)
        if 'drone' in inst:
            put(_pad(_midi(deg(0)) * pitch, bar * 1.02), t0, 0.06)
        if 'bass' in inst:
            for q in (0, 2) if bpm < 100 else (0, 1.5, 2, 3.5):
                put(_bass(_midi(deg(ch[0]) - 12) * pitch, beat * 1.4), t0 + q * beat, 0.22)
        if 'pluck' in inst:
            for s8 in range(8):
                if rng.random() < 0.72:
                    k = ch[(s8 + b) % 3] + (7 if s8 % 4 == 3 else 0)
                    put(_pluck(_midi(deg(k) + 12) * pitch, beat * 1.5), t0 + s8 * beat / 2, 0.09)
        if 'pulse' in inst:
            for s8 in range(8):
                put(_pluck(_midi(deg(ch[0]) + 12) * pitch, beat * 0.45, 0.6), t0 + s8 * beat / 2, 0.07)
        if 'bell' in inst:
            for q in range(4):
                if rng.random() < (0.35 if mood != 'playful' else 0.55):
                    k = ch[0] + melody[(b * 4 + q) % len(melody)]
                    put(_bell(_midi(deg(k) + 24) * pitch, 1.4, ((1, 1), (2.0, 0.25), (3.0, 0.1)), 1.0), t0 + q * beat, 0.05)
        if 'kick' in inst:
            for q in range(4):
                if q % 2 == 0 or bpm >= 120:
                    put(_kick(), t0 + q * beat, 0.2)
        if 'hat' in inst:
            for s8 in range(8):
                put(_hat(seed + b * 8 + s8), t0 + s8 * beat / 2 + beat / 4, 0.05)
        if 'tick' in inst:
            for s8 in range(8):
                put(tick(0.05, 1.3, s8) * 0.5, t0 + s8 * beat / 2, 0.05)
    y = x[:n]
    y = _lp_fast(y, 7000)
    return _fade(_norm(y, 0.8), 0.5, 1.2)


# ---------------------------------------------------------------- registry
ONE_SHOTS = {k: v for k, v in globals().items() if k in (
    'pop click tick whoosh swoosh riser boom thud drone sparkle shimmer ding chime bell buzzer select paste stamp glitch step heartbeat typing dizzy gasp').split()}
BEDS = {'room': room, 'wind': wind, 'city': city, 'night': night, 'hum': hum, 'murmur': murmur}
ALL = {**ONE_SHOTS, **BEDS}

# words in an ElevenLabs-style prompt that point to a synth (so old prompt clips still work for free)
KEYWORDS = [
    ('boom', 'boom'), ('impact', 'boom'), ('explosion', 'boom'), ('drone', 'drone'), ('ominous', 'drone'), ('whoosh', 'whoosh'), ('swoosh', 'swoosh'),
    ('rise', 'riser'), ('riser', 'riser'), ('pop', 'pop'), ('click', 'click'), ('tick', 'tick'), ('clock', 'tick'), ('ding', 'ding'), ('correct', 'ding'),
    ('chime', 'chime'), ('bell', 'bell'), ('sparkle', 'sparkle'), ('twinkle', 'sparkle'), ('magic', 'shimmer'), ('shimmer', 'shimmer'), ('buzzer', 'buzzer'),
    ('wrong', 'buzzer'), ('glitch', 'glitch'), ('electric', 'glitch'), ('step', 'step'), ('footstep', 'step'), ('stair', 'step'), ('thud', 'thud'),
    ('land', 'thud'), ('drop', 'thud'), ('heart', 'heartbeat'), ('typing', 'typing'), ('keyboard', 'typing'), ('dizzy', 'dizzy'), ('gasp', 'gasp'),
    ('crunch', 'click'), ('bite', 'click'), ('room tone', 'room'), ('indoor', 'room'), ('wind', 'wind'), ('breeze', 'wind'), ('traffic', 'city'),
    ('city', 'city'), ('cricket', 'night'), ('night', 'night'), ('hum', 'hum'), ('grid', 'hum'), ('murmur', 'murmur'), ('classroom', 'murmur'),
    ('select', 'select'), ('paste', 'paste'), ('appear', 'paste'), ('stamp', 'stamp'), ('switch', 'click'), ('shatter', 'glitch'), ('crack', 'glitch'),
    ('laugh', 'murmur'), ('cat', 'pop'), ('gulp', 'pop'), ('paper', 'swoosh'), ('rewind', 'riser'), ('music', 'music'),
]


def from_prompt(prompt):
    p = prompt.lower()
    for k, v in KEYWORDS:
        if k in p:
            return v
    return 'pop'


def make(kind, d=None, pitch=1.0, seed=1):
    if kind not in ALL:
        raise SystemExit(f'Unknown synth "{kind}". Choose one of: {", ".join(sorted(ALL))}')
    f = ALL[kind]
    if d is None:
        return f(pitch=pitch, seed=seed)
    return f(d, pitch=pitch, seed=seed)


if __name__ == '__main__':
    import pathlib, wave
    out = pathlib.Path.cwd() / 'out' / 'synth-demo'
    out.mkdir(parents=True, exist_ok=True)

    def w(name, x):
        with wave.open(str(out / f'{name}.wav'), 'wb') as f:
            f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR)
            f.writeframes((np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes())
        print(out / f'{name}.wav')

    if len(sys.argv) > 1 and sys.argv[1] != 'demo':
        k = sys.argv[1]
        d = float(sys.argv[2]) if len(sys.argv) > 2 else None
        w(k, music(sys.argv[2] if len(sys.argv) > 2 else 'playful', 20) if k == 'music' else make(k, d))
    else:
        for k in ONE_SHOTS:
            w(k, make(k))
        for k in BEDS:
            w(k, make(k, 6.0))
        for m in MOODS:
            w(f'music-{m}', music(m, 16))
