# What If, long form: 7 to 10 minute animated episodes, free

One topic line in ("What if you could pause everyone but you?"), and out comes a finished 7 to 10 minute animated
episode in the dusk-lit stick-figure style of the "What If" channels. It has chapters, a free voice, free sound and
music, captions, YouTube chapters, a description and a thumbnail.

This is a rework of the short "What If animation" skill (15 to 25 s clips) for long-form videos. It's built so that
**free models in OpenCode** can make a full episode:

- **You (or the model) write JSON, never code.** A recipe engine turns each shot's JSON into a drawn, lit, animated
  shot: 14 framings (wide, medium, close-up, over the shoulder, insert, schematic...), 11 sets, 7 characters, 16 poses,
  23 props, 14 on-screen marks, 6 science diagram layouts, camera moves and a "freeze the world" power.
- **The story comes in 8 chapters of about a minute,** built on the full seven-beat What If formula, with a hook,
  re-hooks and open loops for retention. Each chapter is made, checked and rendered on its own, so a free model never
  has to hold a whole episode in its head, and a render can stop and resume.
- **A checker after every step** says exactly what's wrong and how to fix it. **status.py always prints the one next
  command,** in any session.
- **Free all the way:** edge-tts or Kokoro for the voice, synthesised sound effects, ambiences and music (or your own
  files), Remotion for the render. No API key needed. ElevenLabs is still supported if you want it.
- **A complete example episode** ships ready to plan and render: "What if you could pause everyone but you?", 8 chapters,
  199 shots, about 8 minutes.

## What you need

- Node 18 or newer, ffmpeg (with ffprobe), Python 3.9+ with `numpy` and `Pillow`
- The free voice: `pip install edge-tts` (online), or Kokoro offline: `pip install kokoro soundfile` plus espeak-ng
- Optional: `pip install faster-whisper` for exact timings if you record your own voice

## Install (OpenCode, free model)

Windows (PowerShell):
```powershell
mkdir what-if; cd what-if
# put this folder at .claude\skills\what-if-longform (unzip it there)
mkdir .opencode\commands
copy .claude\skills\what-if-longform\opencode\commands\*.md .opencode\commands\
Copy-Item -Recurse .claude\skills\what-if-longform\studio .\what-if-studio
cd what-if-studio; npm install; cd ..
pip install numpy Pillow edge-tts
```
Mac or Linux:
```bash
mkdir what-if && cd what-if
# put this folder at .claude/skills/what-if-longform
mkdir -p .opencode/commands && cp .claude/skills/what-if-longform/opencode/commands/*.md .opencode/commands/
cp -r .claude/skills/what-if-longform/studio ./what-if-studio && (cd what-if-studio && npm install)
pip install numpy Pillow edge-tts
```
Check everything: `cd what-if-studio && python ../.claude/skills/what-if-longform/scripts/doctor.py`

Start OpenCode **from the `what-if` folder** (`opencode`), choose the best free model (`/models`, reasoning high with
Ctrl+T), then:

| Command | What it does |
|---|---|
| `/wi-new What if you could pause everyone but you?` | writes and checks the 8-chapter outline, then creates the chapters |
| `/wi-next <slug>` | does exactly the next step, then stops (use it over and over, a fresh session per chapter) |
| `/wi-chapter <slug> 3` | takes chapter 3 from script to an approved storyboard with sound |
| `/wi-finish <slug>` | renders, masters, and lists what to upload |

## See the example first

From `what-if-studio`:
```bash
npx remotion studio src/index.ts        # open PauseCh01 ... PauseCh08 and PauseThumb (silent until you make the voice)
S=../.claude/skills/what-if-longform/scripts
python $S/status.py pause               # what's next for the example
python $S/voice.py pause all            # the free voice for all 8 chapters (edge-tts)
python $S/plan.py pause all
python $S/sfx.py pause all
python $S/render.py pause               # a long render: chapter by chapter, resumable
python $S/master.py pause
```

## How an episode is made

1. **Outline**: `new.py <slug> "<topic>"` writes 8 chapters with beats, timings, word budgets and moods; fill the
   TODOs (story, power, science facts, open loops); `check.py`.
2. **Per chapter**: write the script lines, then `check.py` → `voice.py` → write the shots as JSON (each with the words
   it cuts on) → `check.py` → `plan.py` → `stills.mjs` + `board.py` (a storyboard) → self-check against the checklist →
   `sfx.py` + `mixcheck.py`.
3. **Finish**: `render.py` (each chapter, then joined) → `master.py` (-14 LUFS, captions.srt, chapters.txt,
   description.md, report.json) → `stills.mjs <slug> --thumb`.

Read `SKILL.md` for the full pipeline, `references/recipes.md` for the shot language, and
`references/free-models.md` for running it well with a free model.

## What's in the folder

| Path | What |
|---|---|
| `SKILL.md` | the pipeline the model follows |
| `references/` | formula (long form), recipes (shot JSON), look and checklist, sound, free models, traps, kit |
| `scripts/` | new, check, status, voice, align, plan, scaffold, stills, board, sfx, synth, mixcheck, render, master, motiongrid, doctor |
| `studio/` | the Remotion project: the engine and the recipe engine, 11 sets, the cast, the example `pause`, the two short examples |
| `opencode/commands/` | `/wi-new`, `/wi-next`, `/wi-chapter`, `/wi-finish` |

## Honest limits

- **Render time**: every frame is drawn in a browser. Expect several minutes per chapter-minute on a laptop; a full
  episode can take an hour or more. It resumes, so leave it running.
- **Synthesised sound is good, not great.** It's free and always in sync; for a channel you care about, drop real CC0
  recordings into `library/sfx/` and licensed music into `library/music/<mood>/`, and the pipeline uses them first.
- **Acting is simple**: poses, faces and walks, no lip sync. The look, the pace and the sound carry it, as in the genre.
- **A free model still needs the loop**: the checkers catch the mistakes, but the storyboard self-check is where an
  episode gets good. Look at it.

## Licences and rules

- Remotion is free for individuals and companies of up to three people; larger companies need a company licence.
- Voices: edge-tts uses Microsoft Edge's online read-aloud voices (check the terms before you monetise); Kokoro's model
  is Apache-2.0; ElevenLabs is under your account's terms.
- Fonts load from Google Fonts at render time (SIL Open Font License); put your own in `studio/public/fonts/` to work offline.
- Original characters and stories only. Never claim the viral channels are made with any particular tool. Every fact
  in a script is worked out and sourced (check.py enforces it).
- Based on the free What If animation skill by FreshStack; the code is free to use, change and share.
