---
description: Start a long-form What If episode (7-10 min) from a topic line
---
Load the what-if-longform skill (SKILL.md). <skill> means ../.claude/skills/what-if-longform when you are in the studio folder (what-if-studio) and follow it. Work from the studio folder (what-if-studio; if it doesn't exist, do the Setup in SKILL.md first).

Topic: $ARGUMENTS

1. Pick a short slug (lower case, hyphens) from the topic.
2. Run: python <skill>/scripts/new.py <slug> "<topic>"
3. Read references/formula.md and studio/src/episodes/pause/outline.json (the example).
4. Fill every TODO in src/episodes/<slug>/outline.json: logline, power, each chapter's goal, sets and open_loop, the science facts (claim, working, source: work the arithmetic), the look's chip label, the thumbnail lines, the end question.
5. Run: python <skill>/scripts/check.py <slug> and fix every error.
6. Run: python <skill>/scripts/new.py <slug> --chapters
7. Run: python <skill>/scripts/status.py <slug> and stop. Tell me the next step.
