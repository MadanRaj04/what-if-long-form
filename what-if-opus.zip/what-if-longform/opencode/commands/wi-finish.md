---
description: Render and master a finished What If long-form episode
---
Load the what-if-longform skill (SKILL.md). <skill> means ../.claude/skills/what-if-longform when you are in the studio folder (what-if-studio). Work from the studio folder.

Episode slug: $ARGUMENTS

1. python <skill>/scripts/status.py <slug>: every chapter must be at "render" or "done". If not, stop and say which chapter needs which step.
2. python <skill>/scripts/render.py <slug>   (long: several minutes per chapter; if it stops, run it again: it resumes)
3. python <skill>/scripts/master.py <slug>
4. node <skill>/scripts/stills.mjs <slug> --thumb
5. Report: the final file, its length, loudness, pace per chapter, the files to upload (captions.srt, chapters.txt, description.md, thumbnail.png) and the paid credits (0 if everything was free).
