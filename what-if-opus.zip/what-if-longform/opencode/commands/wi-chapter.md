---
description: Take one chapter of a What If long-form episode from script to approved storyboard and sound
---
Load the what-if-longform skill (SKILL.md). <skill> means ../.claude/skills/what-if-longform when you are in the studio folder (what-if-studio). Work from the studio folder.

Arguments (slug, chapter number): $ARGUMENTS

Repeat until status.py shows this chapter at "render" or "done":
1. python <skill>/scripts/status.py <slug>
2. Do the NEXT step for this chapter only (script -> voice -> shots -> plan -> board -> approve -> sound).
   - Script: read the chapter's beat, goal and open_loop in outline.json; write the "script" lines; check.py <slug> <n>.
   - Shots: read references/recipes.md and studio/src/episodes/pause/ch0<n>/chapter.json; write shots in batches of 6 to 10, each with "say" = the first words of its line; check.py after each batch; then plan.py <slug> <n>.
   - Board: node <skill>/scripts/stills.mjs <slug> <n> and python <skill>/scripts/board.py <slug> <n>; open the storyboard and every still; check each against references/look.md; fix and re-render failing shots; then set "board_ok": true.
   - Sound: python <skill>/scripts/sfx.py <slug> <n> and mixcheck.py <slug> <n>.
3. Never move to another chapter. Stop when this chapter is ready to render and report its length and pace.
