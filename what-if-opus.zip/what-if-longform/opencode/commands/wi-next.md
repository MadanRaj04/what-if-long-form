---
description: Do exactly the next step of a What If long-form episode, then stop
---
Load the what-if-longform skill (SKILL.md). <skill> means ../.claude/skills/what-if-longform when you are in the studio folder (what-if-studio). Work from the studio folder.

Episode slug: $ARGUMENTS

1. Run: python <skill>/scripts/status.py <slug>
2. Do ONLY the step after "NEXT:". If it says to write a script or shots, read the chapter in outline.json, references/recipes.md and the same chapter of studio/src/episodes/pause/ first, and copy their patterns.
3. Run the checker for that step (check.py <slug> <n>) and fix every error it reports.
4. Run status.py again and stop. Tell me what you did and what the next step is.
