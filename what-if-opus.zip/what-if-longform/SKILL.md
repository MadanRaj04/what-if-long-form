---
name: what-if-longform
description: Make a long-form "What If" animated episode (7 to 10 minutes) from one topic line ("What if you could pause everyone but you?"), in the dusk-lit stick-figure style of the What If channels. Writes the story as 8 chapters on the full seven-beat What If formula, voices it for free (edge-tts or Kokoro), lays every shot out as JSON that a recipe engine draws and animates in code (Remotion, SVG, an original cast on one rig, 11 sets), self-checks a storyboard per chapter, adds free synthesised sound and music, renders chapter by chapter (resumable) and masters the episode to -14 LUFS with captions, YouTube chapters, a description and a thumbnail. Built to work with free models in OpenCode. Use when someone asks for a long What If episode, a 7-10 minute What If video, a What If animation with chapters, or to continue one ("next step", "do chapter 3").
---

# What If, long form

One topic line in; a finished 7 to 10 minute episode out, made **one chapter at a time**. Everything you write is JSON
(an outline, then one chapter file per chapter). The engine turns each shot's JSON into a drawn, animated shot, so you
never need to write TypeScript. The scripts check your work at every step and always tell you the next command.

A complete example ships ready to plan and render: `studio/src/episodes/pause/` ("What if you could pause everyone
but you?", 8 chapters, 199 shots). **Before writing anything, open its outline.json and ch01/chapter.json and copy their
patterns.**

## The golden rules (read these every session)

1. **Run `status.py` first, and whenever unsure.** It reads the files and prints the ONE next step. Do that step, then
   run status.py again. Never skip ahead.
2. **One chapter at a time.** Finish a chapter's step before starting the next chapter's. Keep each work session to one
   or two chapters; status.py picks up exactly where you stopped, even in a new session.
3. **Run `check.py` after every edit.** Fix every `x` error before moving on. Read `!` warnings and fix the ones about
   pace, sentence length and repeated shot sizes.
4. **Copy the example.** For any shot you write, find a shot in `episodes/pause/` doing something similar and copy its
   shape. Only use values listed in `references/recipes.md` (sets, recipes, poses, faces, props, marks).
5. **Every number in the script is real.** It must appear in outline.json `science` with its working and source.
   check.py blocks any number that doesn't.
6. **Look at the storyboard before sound or render.** Open the stills and run the checklist in `references/look.md`.
7. **Never claim the viral channels are made with any tool.** Original characters and stories only; no real people,
   brands or famous characters.

## Setup (once per machine)

Needs Node 18+, ffmpeg and ffprobe, Python 3.9+ with `numpy` and `Pillow`, and for the free voice `pip install edge-tts`
(or Kokoro, offline: `pip install kokoro soundfile`). No API key is needed for anything.

```bash
cp -r <skill>/studio ./what-if-studio && cd what-if-studio && npm install
python <skill>/scripts/doctor.py
```

Everything below runs from the studio folder; `<skill>` is this skill's folder. `S=<skill>/scripts` below.

## The pipeline

| Step | You do | Then run |
|---|---|---|
| 0. Outline | `python $S/new.py <slug> "What if ...?"`, then fill every TODO in `src/episodes/<slug>/outline.json` (read `references/formula.md`) | `python $S/check.py <slug>` |
| 1. Chapters | | `python $S/new.py <slug> --chapters` |
| Per chapter N: | | |
| 2. Script | write the lines in `chNN/chapter.json` "script" (references/formula.md: writing rules) | `python $S/check.py <slug> N` |
| 3. Voice | | `python $S/voice.py <slug> N` |
| 4. Shots | write "shots" in chapter.json, one per picture, each with "say" = the first words of its line (references/recipes.md) | `python $S/check.py <slug> N` then `python $S/plan.py <slug> N` |
| 5. Storyboard | | `node $S/stills.mjs <slug> N` then `python $S/board.py <slug> N` |
| 6. Self-check | open `out/<slug>/chNN/storyboard.jpg` and every still in `board/`; run the look.md checklist; fix shots, re-run plan + stills for those shots (`stills.mjs <slug> N S3 S7`); when it passes set `"board_ok": true` | |
| 7. Sound | (nothing to write: it's automatic) | `python $S/sfx.py <slug> N` then `python $S/mixcheck.py <slug> N` |
| After all chapters: | | |
| 8. Render | | `python $S/render.py <slug>` (resumable: run again after a stop) |
| 9. Master | | `python $S/master.py <slug>` and `node $S/stills.mjs <slug> --thumb` |

`python $S/status.py <slug>` knows all of this and prints the exact next command.

### Step 0: the outline (the whole story, before any chapter)
`new.py` writes 8 chapters with their beats, target seconds, word budgets, moods and an example open loop each.
Fill in: `logline`, `power` (the word, the rule, the limit learned the hard way), each chapter's `goal`, `sets` and
`open_loop`, the `science` facts (claim, working, source), the `looks` chip label, the `thumbnail` lines, the
`end.question`. Search the web for the premise first: if a What If channel already has that exact episode, change the
power or the rule. Keep `voice.provider` as `"edge"` (free) or `"kokoro"` (free, offline).

### Step 2: a chapter's script
Read the chapter's `beat` and `goal` in the outline. Write 4 to 9 entries in "script", each a short beat of 1 to 4
sentences: second person, present or past tense, 3 to 12 words a sentence, every sentence a picture. Hit the word
`budget`. The first line pays off the previous chapter's open loop; the last line opens the next one.

### Step 3: the voice
`voice.py` makes the audio with word timings and tightens the pauses. Offline or planning early? Use
`--provider draft` (timed tones), board the chapter, then make the real voice before sound and render.

### Step 4: the shots (the big step)
Read `references/recipes.md` once fully. Then, line by line through the chapter's words:
- one shot per picture, roughly every 2 to 3 seconds (cold open: every 1.5 to 2);
- `"say"`: the first 2 to 5 words of the line the shot starts on, exactly as written in the script;
- change the size every cut: wide, medium, close-up, insert, schematic... never the same recipe and set twice in a row;
- the power: `"look"` (the outline's look) and `"freeze": 0` on every shot while the world is paused (a time power),
  or a `paste`/`marquee` for an object power; the hero's eyes `"glint"` when it switches on;
- the science line gets a `schematic` shot with a `diagram`; the fact's line ends on `"stamp": "THAT'S REAL"`;
- chapters 2+ open on the chapter card S1 that new.py put there.
Then `check.py` (fix errors) and `plan.py` (it prints the pace: aim for 26+ cuts a minute in chapter 1, 14+ after).

### Step 6: the self-check
Open the storyboard, then each still at full size. For every shot ask the look.md checklist questions. Typical fixes:
a character off-frame (change `at`), a prop floating (use the set's anchor, or `"at": "hand"`), two neighbours the same
size (change one recipe), a dark frame (lower `mood.dim`, choose a lit set), text too long (shorten it). Re-run
`plan.py` then `stills.mjs <slug> N <shots>` and `board.py`. When it passes, set `"board_ok": true`.

### Step 7: sound
Automatic: a sound for every visible action, a bed for every place, a music bed in the chapter's mood, ducked under the
voice. Your own sounds win: put `whoosh.wav` in `library/sfx/`, or music in `library/music/<mood>/`. Run
`mixcheck.py`; if many words are covered, lower `"levels": {"sfx_lu": -5}` in the chapter's "sound".

### Steps 8 and 9: render and master
`render.py` renders each chapter that changed (a few minutes each; the whole episode can take an hour or more on a
laptop), then joins them. `master.py` brings the loudness to -14 LUFS and writes `captions.srt`, `chapters.txt`,
`description.md` and `report.json`. Make the thumbnail with `stills.mjs <slug> --thumb`. Hand over the final file, the
thumbnail, the description, and the paid credits (0 when everything is free).

## Files

| Path | What |
|---|---|
| `references/formula.md` | The long-form What If formula: 8 chapters, retention (hooks, re-hooks, open loops), writing rules |
| `references/recipes.md` | The shot language: recipes, sets, cast, poses, faces, props, marks, diagrams, camera. **The reference for step 4** |
| `references/look.md` | The look, the pace, the storyboard checklist |
| `references/sound.md` | Free sound: auto events, the synth list, your own library, levels |
| `references/free-models.md` | How to run this well with a free model in OpenCode: sessions, prompts, recovering from mistakes |
| `references/traps.md` | What goes wrong and the fix |
| `references/kit.md` | The engine underneath (for custom TSX shots only) |
| `scripts/` | new, check, status, voice, plan, scaffold, stills, board, sfx, synth, mixcheck, render, master, motiongrid, doctor |
| `studio/` | The Remotion project: engine, recipe engine, sets, the example episode `pause`, the short examples |

## Where an episode lives

| Path | What |
|---|---|
| `src/episodes/<slug>/outline.json` | You write it: the whole story, chapters, science, looks, voice, thumbnail |
| `src/episodes/<slug>/chNN/chapter.json` | You write it: the chapter's script and shots (and optional fx, sound) |
| `src/episodes/<slug>/chNN/words.json, timeline.json, index.tsx` | The scripts write these. Don't edit them |
| `public/<slug>/chNN/` | voice.wav, sfx.wav, music.wav |
| `out/<slug>/chNN/` | storyboard.jpg, board stills, shotlist.md, motion grids |
| `out/<slug>/` | chapters/*.mp4, <slug>-final.mp4, captions.srt, chapters.txt, description.md, thumbnail.png, report.json |
| `library/sfx/`, `library/music/<mood>/` | Your own sounds and music (used before the synth) |
