import React from 'react';
import { clamp, easeOut, backOut } from '../anim';
import { Schematic, SCH, SchLabel, CountUp, PlantIcon, Arrow, DrawOn } from '../sets/schematic';
import { Dial, Stamp } from '../ui';
import { FONT } from '../fonts';
import type { DiagramSpec, IconName } from '../spec';

// The science beat, written as data. One idea per diagram; it builds in steps (each piece pops or draws on a beat
// after the last) so it can be read in the time it's up. Layouts: equation (A -> B -> C), count (a number counting up),
// icons (a grid lighting up), compare (bars), timeline (points along a line), list (ticked lines).

const PLANTS = ['tower', 'wind', 'solar', 'dam', 'factory'];

/** A line icon in the schematic style, about 120 units tall, centred on x, y; orange and glowing when lit. */
export const LineIcon: React.FC<{ x: number; y: number; icon: IconName; on: number; t: number; s?: number }> = ({ x, y, icon, on, t, s = 1 }) => {
  if (PLANTS.includes(icon)) return <PlantIcon x={x} y={y} kind={icon as 'tower'} on={on} t={t} s={s} />;
  const c = on > 0 ? SCH.live : SCH.dim;
  const body: Record<string, React.ReactNode> = {
    person: <g><circle cx={0} cy={-34} r={20} /><path d="M -34 50 Q -34 -6 0 -6 Q 34 -6 34 50" /></g>,
    clock: <g><circle r={50} /><path d={`M 0 0 L 0 -32 M 0 0 L ${Math.sin(t / 6) * 24} ${-Math.cos(t / 6) * 24}`} /></g>,
    bolt: <path d="M 10 -56 L -26 6 L 4 6 L -10 56 L 28 -8 L -2 -8 Z" />,
    heart: <path d="M 0 44 L -46 -2 Q -66 -30 -40 -48 Q -14 -60 0 -30 Q 14 -60 40 -48 Q 66 -30 46 -2 Z" />,
    eye: <g><path d="M -60 0 Q 0 -50 60 0 Q 0 50 -60 0 Z" /><circle r={16} /></g>,
    globe: <g><circle r={50} /><ellipse rx={22} ry={50} /><path d="M -50 0 L 50 0 M -42 -26 L 42 -26 M -42 26 L 42 26" /></g>,
    cookie: <g><circle r={46} /><circle cx={-14} cy={-10} r={4} /><circle cx={16} cy={-4} r={4} /><circle cx={0} cy={18} r={4} /></g>,
    coin: <g><circle r={46} /><circle r={32} /><path d="M 0 -18 L 0 18" /></g>,
    brain: <path d="M -40 30 Q -60 0 -40 -24 Q -34 -52 -6 -46 Q 10 -60 30 -44 Q 58 -40 52 -10 Q 64 18 36 34 Q 10 48 -14 40 Q -30 44 -40 30 Z M 0 -44 L 0 40" />,
    sun: <g><circle r={26} />{Array.from({ length: 8 }).map((_, i) => <path key={i} transform={`rotate(${i * 45 + t})`} d="M 0 -38 L 0 -56" />)}</g>,
    moon: <path d="M 14 -50 A 50 50 0 1 0 14 50 A 38 50 0 1 1 14 -50 Z" />,
    house: <path d="M -50 50 L -50 -6 L 0 -50 L 50 -6 L 50 50 Z M -14 50 L -14 14 L 14 14 L 14 50" />,
    car: <g><path d="M -60 20 L -60 -4 L -36 -10 L -20 -36 L 24 -36 L 42 -10 L 60 -4 L 60 20 Z" /><circle cx={-32} cy={24} r={12} /><circle cx={32} cy={24} r={12} /></g>,
    phone: <g><rect x={-28} y={-52} width={56} height={104} rx={10} /><path d="M -8 40 L 8 40" /></g>,
    drop: <path d="M 0 -56 Q 40 0 36 18 Q 30 52 0 52 Q -30 52 -36 18 Q -40 0 0 -56 Z" />,
  };
  return (
    <g transform={`translate(${x} ${y}) scale(${s * (1 + 0.12 * Math.sin(clamp(on) * Math.PI))})`} stroke={c} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" style={on > 0 ? { filter: `drop-shadow(0 0 10px ${SCH.glow})` } : undefined}>
      {body[icon] ?? body.bolt}
    </g>
  );
};

const fmt = (v: number, f?: string) => {
  if (f === 'short') {
    const a = Math.abs(v);
    const units: [number, string][] = [[1e15, ' QUADRILLION'], [1e12, ' TRILLION'], [1e9, ' BILLION'], [1e6, ' MILLION'], [1e3, 'K']];
    for (const [k, u] of units) if (a >= k) return `${(v / k).toFixed(a / k >= 100 ? 0 : 1)}${u}`;
    return Math.round(v).toString();
  }
  if (f === 'time') {
    const m = Math.floor(v);
    return `${String(m).padStart(2, '0')}:${String(Math.floor((v - m) * 60 + 0.01)).padStart(2, '0')}`;
  }
  if (f === 'decimal') return v.toFixed(1);
  return Math.round(v).toLocaleString('en-US');
};

export const Diagram: React.FC<{ d: DiagramSpec; t: number; len: number; id: string }> = ({ d, t, len, id }) => {
  const items = d.items ?? [];
  const parts: React.ReactNode[] = [];
  const top = d.heading ? 1 : 0;
  if (d.heading) parts.push(<SchLabel key="h" x={960} y={150} t={t - 2} text={d.heading} size={50} />);
  if (d.layout === 'equation') {
    const eq = items.slice(0, 3);
    const n = Math.max(1, eq.length);
    const xs = n === 1 ? [960] : n === 2 ? [600, 1320] : [400, 960, 1520];
    const anyIcon = eq.some((it) => it.icon);
    const slot = n === 1 ? 1400 : n === 2 ? 620 : 470;
    const sizes = eq.map((it) => Math.max(34, Math.min(anyIcon ? 56 : 96, slot / Math.max(1, it.text.length * 0.6))));
    const half = eq.map((it, k) => Math.max(anyIcon ? 90 : 0, (it.text.length * sizes[k] * 0.6) / 2));
    eq.forEach((it, k) => {
      const at = 4 + k * 14;
      if (it.icon) parts.push(<g key={`i${k}`} opacity={clamp((t - at) / 4)}><LineIcon x={xs[k]} y={400} icon={it.icon} on={clamp((t - at) / 6)} t={t} s={1.5} /></g>);
      parts.push(<SchLabel key={`t${k}`} x={xs[k]} y={anyIcon ? 590 : 520} t={t - at - 2} text={it.text} size={sizes[k]} color={k === n - 1 ? SCH.live : SCH.line} />);
      if (it.sub) parts.push(<SchLabel key={`s${k}`} x={xs[k]} y={anyIcon ? 650 : 590} t={t - at - 6} text={it.sub} size={30} color={SCH.dim} />);
      if (k > 0) {
        const x0 = xs[k - 1] + half[k - 1] + 24;
        const x1 = xs[k] - half[k] - 24;
        const ay = anyIcon ? 400 : 490;
        if (x1 - x0 > 50) parts.push(<Arrow key={`a${k}`} x0={x0} y0={ay} x1={x1} y1={ay} t={t - at + 4} bend={0.08} />);
      }
    });
  }
  if (d.layout === 'count' && d.count) {
    const c = d.count;
    const at = c.t ?? 8;
    if (items[0]) parts.push(<SchLabel key="ctx" x={960} y={top ? 300 : 260} t={t - 3} text={items[0].text} size={44} color={SCH.dim} />);
    parts.push(<CountUp key="c" x={960} y={590} t={t - at} to={c.to} dur={c.dur ?? 34} size={c.to >= 1e9 && c.format !== 'short' ? 92 : 150} suffix={c.suffix ?? ''} format={(v) => fmt((c.from ?? 0) + (c.to - (c.from ?? 0)) * (v / Math.max(1e-9, c.to)), c.format)} />);
    if (c.label) parts.push(<SchLabel key="cl" x={960} y={690} t={t - at - 4} text={c.label} size={40} color={SCH.dim} />);
  }
  if (d.layout === 'icons' && d.icons) {
    const n = Math.min(30, Math.max(1, d.icons.n));
    const cols = Math.min(10, n);
    const rows = Math.ceil(n / cols);
    const lit = d.icons.lit ?? n;
    const area = d.dial ? 1050 : 1500;
    const gx0 = d.dial ? 700 : 960;
    const gw = Math.min(150, area / cols);
    for (let i = 0; i < n; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const order = (col * 3 + row * 7) % n;
      const x = gx0 + (col - (cols - 1) / 2) * gw;
      const y = 520 + (row - (rows - 1) / 2) * 170 + (top ? 20 : 0);
      parts.push(<LineIcon key={`g${i}`} x={x} y={y} icon={d.icons.icon} on={i < lit ? clamp((t - 6 - order * 2) / 6) : 0} t={t} s={Math.min(1, gw / 150)} />);
    }
    if (d.icons.label) parts.push(<SchLabel key="gl" x={gx0} y={880} t={t - 10} text={d.icons.label} size={42} color={SCH.live} />);
  }
  if (d.layout === 'compare' && d.bars) {
    const bars = d.bars.slice(0, 4);
    const max = Math.max(...bars.map((b) => b.value), 1e-9);
    const gap = bars.length <= 2 ? 230 : 170;
    const y0 = 560 - ((bars.length - 1) * gap) / 2;
    bars.forEach((b, k) => {
      const at = 4 + k * 10;
      const y = y0 + k * gap;
      const w = 1080 * (b.value / max) * easeOut(clamp((t - at) / 16));
      parts.push(
        <g key={`b${k}`} opacity={clamp((t - at) / 4)}>
          <text x={300} y={y - 26} fontFamily={FONT.ui} fontSize={44} fill={SCH.line} letterSpacing={3}>{b.label}</text>
          <rect x={300} y={y} width={1080} height={74} rx={16} fill="#ffffff" opacity={0.08} />
          <rect x={300} y={y} width={Math.max(8, w)} height={74} rx={16} fill={k === bars.length - 1 ? SCH.live : SCH.line} opacity={0.9} style={k === bars.length - 1 ? { filter: `drop-shadow(0 0 14px ${SCH.glow})` } : undefined} />
          <text x={300 + Math.max(8, w) + 28} y={y + 54} fontFamily={FONT.ui} fontSize={52} fill={SCH.live}>{b.display ?? fmt(b.value)}</text>
        </g>,
      );
    });
  }
  if (d.layout === 'timeline') {
    const n = Math.min(6, Math.max(1, items.length));
    parts.push(<DrawOn key="tl" d="M 220 560 L 1700 560" t={t - 2} dur={14} width={6} />);
    items.slice(0, 6).forEach((it, k) => {
      const at = 8 + k * 12;
      const x = 220 + ((k + 0.5) * 1480) / n;
      const up = k % 2 === 0;
      const s = backOut(clamp((t - at) / 6));
      parts.push(
        <g key={`p${k}`}>
          <circle cx={x} cy={560} r={16 * s} fill={k === n - 1 ? SCH.live : SCH.line} />
          {it.icon ? <g opacity={clamp((t - at) / 4)}><LineIcon x={x} y={up ? 400 : 720} icon={it.icon} on={clamp((t - at) / 6)} t={t} s={0.8} /></g> : null}
          <SchLabel x={x} y={up ? (it.icon ? 300 : 490) : (it.icon ? 840 : 640)} t={t - at - 2} text={it.text} size={36} />
          {it.sub ? <SchLabel x={x} y={up ? (it.icon ? 258 : 448) : (it.icon ? 882 : 684)} t={t - at - 5} text={it.sub} size={26} color={SCH.dim} /> : null}
        </g>,
      );
    });
  }
  if (d.layout === 'list') {
    const big = items.length <= 3;
    const fs = big ? 66 : 48;
    const gap = big ? 150 : 110;
    const y0 = 540 - ((Math.min(6, items.length) - 1) * gap) / 2 + (top ? 30 : 0);
    items.slice(0, 6).forEach((it, k) => {
      const at = 4 + k * 12;
      const y = y0 + k * gap;
      const p = clamp((t - at) / 6);
      parts.push(
        <g key={`l${k}`} opacity={p}>
          <path d={`M 300 ${y - fs * 0.3} l ${fs * 0.33} ${fs * 0.37} l ${fs * 0.62} ${-fs * 0.75}`} stroke={SCH.live} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" strokeDasharray={140} strokeDashoffset={140 * (1 - p)} />
          <text x={300 + fs * 1.3 + (1 - easeOut(p)) * 40} y={y} fontFamily={FONT.ui} fontSize={fs} fill={SCH.line} letterSpacing={2}>{it.text}</text>
          {it.sub ? <text x={300 + fs * 1.3} y={y + fs * 0.8} fontFamily={FONT.ui} fontSize={30} fill={SCH.dim}>{it.sub}</text> : null}
        </g>,
      );
    });
  }
  if (d.dial) {
    const at = d.dial.t ?? 10;
    const dur = d.dial.dur ?? 50;
    const v = d.dial.to * Math.pow(clamp((t - at) / dur), 0.6);
    const read = d.dial.unit === 'min' ? fmt(v, 'time') : `${v >= 100 ? Math.round(v) : v.toFixed(1)}${d.dial.unit ?? ''}`;
    parts.push(<Dial key="dl" x={d.layout === 'count' ? 1580 : 1500} y={d.layout === 'count' ? 560 : 520} r={d.layout === 'icons' ? 150 : 190} p={clamp((t - at) / dur)} readout={read} size={80} />);
    if (d.dial.label) parts.push(<SchLabel key="dll" x={1500} y={800} t={t - at} text={d.dial.label} size={34} color={SCH.dim} />);
  }
  if (d.stamp) parts.push(<Stamp key="st" x={1440} y={900} t={t - (d.stampT ?? Math.max(20, len - 34))} text={d.stamp} size={58} />);
  return (
    <g>
      <g transform={`translate(960 540) scale(${1 + 0.04 * clamp(t / Math.max(1, len))}) translate(-960 -540)`}>
        <Schematic t={t} id={id} />
        {parts}
      </g>
    </g>
  );
};
