import React from 'react';
import { LEG_LEN } from '../rig';
import { Room } from '../room';
import { stand } from '../furnish';
import { DuskSky, Sun, Skyline, Haze, Bokeh } from '../kit';
import { Study, Desk, STUDY } from '../sets/study';
import { Kitchen, KitchenIsland, KITCHEN, islandTop } from '../sets/kitchen';
import { Bedroom, BedDuvet, BEDROOM, bedSit, bedTop } from '../sets/bedroom';
import { Classroom, SchoolDesk, CLS } from '../sets/classroom';
import { Stairwell, Banister, hipGround, stepTop } from '../sets/stairwell';
import { Rooftop } from '../sets/rooftop';
import { Schematic } from '../sets/schematic';
import { Office, OfficeDesk, OFFICE } from '../sets/office';
import { Street, STREET_GROUND } from '../sets/street';
import type { At, SetName } from '../spec';
import { av } from './util';

// Every set as a stage: how to draw it, where people stand on it, how a wide frames it, which near layer (a desk, the
// island, the banister) covers legs, and named anchors where props sit. Room sets place people on the floor by
// (u across, w toward camera) so scale and perspective come for free; flat sets place them by x on a ground line.

export type Placement = { x: number; y: number; scale: number; depth: number; ground: (x: number) => number };
export type StagePoint = { kind: 'room'; u: number; w: number; bed?: boolean } | { kind: 'flat'; x: number };
export type DrawOpts = { t: number; id: string; red: number; veil?: number; opts: Record<string, unknown>; inBed: boolean; castX: number[] };
export type NearLayer = { depth: number; node: React.ReactNode };

export type Stage = {
  rim: string;
  wide: { cx: number; cy: number; z: number };
  nativeRed: boolean;
  point: (at: At | undefined, i: number, n: number) => StagePoint;
  place: (p: StagePoint) => Placement;
  draw: (o: DrawOpts) => React.ReactNode;
  near: (o: DrawOpts) => NearLayer[];
  anchor: (name: string) => { x: number; y: number; s: number } | null;
};

const num = (v: unknown, d: number) => (typeof v === 'number' ? v : d);
const flag = (v: unknown, d: boolean) => (typeof v === 'boolean' ? v : d);
const str = (v: unknown, d: string) => (typeof v === 'string' ? v : d);
/** An option that can animate: a number or [from, to, f0, f1]. */
const anum = (v: unknown, t: number, d: number) => (typeof v === 'number' ? v : Array.isArray(v) && v.length === 4 ? av(v as [number, number, number, number], t) : d);

const SLOT_U: Record<string, number> = { farLeft: 0.16, left: 0.32, center: 0.5, right: 0.68, farRight: 0.84 };
const defaultSlot = (i: number, n: number) => (n <= 1 ? 'center' : n === 2 ? (i === 0 ? 'left' : 'right') : ['left', 'center', 'right', 'farLeft', 'farRight'][i % 5]);

/** A room stage: people stand on the floor at (u, cw) by default, k of the back wall's height tall. */
const roomPoint = (cw: number) => (at: At | undefined, i: number, n: number): StagePoint => {
  if (Array.isArray(at)) return { kind: 'room', u: at[0] ?? 0.5, w: at[1] ?? cw };
  if (at === 'bed') return { kind: 'room', u: 0.2, w: 0.085, bed: true };
  const slot = at ?? defaultSlot(i, n);
  return { kind: 'room', u: SLOT_U[slot] ?? 0.5, w: cw };
};
const roomPlace = (r: Room, k: number) => (p: StagePoint): Placement => {
  if (p.kind !== 'room') return { x: p.x, y: 700, scale: 1, depth: 0.5, ground: () => 840 };
  if (p.bed) {
    const b = bedSit(p.u, p.w);
    return { x: b.x, y: b.y, scale: b.scale, depth: p.w, ground: () => b.y + LEG_LEN * b.scale };
  }
  const s = stand(r, p.u, p.w, k);
  const g = s.y + LEG_LEN * s.scale;
  return { x: s.x, y: s.y, scale: s.scale, depth: p.w, ground: () => g };
};

/** A flat stage: people stand on a ground line (a number, or a function of x for stairs). */
const flatPoint = (xs: Record<string, number>) => (at: At | undefined, i: number, n: number): StagePoint => {
  if (Array.isArray(at)) return { kind: 'flat', x: at[0] ?? 960 };
  const slot = at ?? defaultSlot(i, n);
  return { kind: 'flat', x: xs[slot] ?? xs.center ?? 960 };
};
const flatPlace = (ground: (x: number) => number, scale: number) => (p: StagePoint): Placement => {
  const x = p.kind === 'flat' ? p.x : 960;
  return { x, y: ground(x) - LEG_LEN * scale, scale, depth: 0.4, ground };
};

const SkySet: React.FC<{ t: number; id: string; red: number }> = ({ t, id, red }) => (
  <g>
    <DuskSky id={`${id}sky`} horizonY={780} red={red} />
    <Sun x={1240} y={700} r={150} t={t} red={red} />
    <Skyline y={860} seed={7} color={red > 0.5 ? '#3A1222' : '#3E2A56'} h={200} />
    <Haze y={820} o={0.3} />
    <rect x={-400} y={930} width={2720} height={600} fill={red > 0.5 ? '#12060C' : '#1C1626'} />
    <rect x={-400} y={930} width={2720} height={3} fill="#FFB46A" opacity={0.4} />
    <Bokeh seed={3} x0={-200} y0={200} w={2300} h={600} t={t} o={0.18} />
  </g>
);

export const STAGES: Record<SetName, Stage> = {
  study: {
    rim: 'rimR',
    wide: { cx: 990, cy: 545, z: 0.9 },
    nativeRed: false,
    point: roomPoint(0.47),
    place: roomPlace(STUDY, 0.62),
    draw: (o) => <Study t={o.t} id={o.id} veil={o.veil ?? 0.4} shelf={anum(o.opts.shelf, o.t, 1)} />,
    near: (o) => (flag(o.opts.desk, true) ? [{ depth: 0.5, node: <Desk key="desk" x0={560} x1={1360} y={700} laptop={flag(o.opts.laptop, true)} lamp={flag(o.opts.lamp, true)} /> }] : []),
    anchor: (n) => ({ desk: { x: 1120, y: 700, s: 1 }, desk2: { x: 940, y: 700, s: 1 }, floor: { x: 980, y: 900, s: 1.3 } } as Record<string, { x: number; y: number; s: number }>)[n] ?? null,
  },
  studyNight: {
    rim: 'rimBlue',
    wide: { cx: 990, cy: 545, z: 0.9 },
    nativeRed: false,
    point: roomPoint(0.47),
    place: roomPlace(STUDY, 0.62),
    draw: (o) => <Study t={o.t} id={o.id} veil={o.veil ?? 0.46} night shelf={anum(o.opts.shelf, o.t, 1)} />,
    near: (o) => (flag(o.opts.desk, true) ? [{ depth: 0.5, node: <Desk key="desk" x0={560} x1={1360} y={700} laptop={flag(o.opts.laptop, true)} lamp={flag(o.opts.lamp, true)} /> }] : []),
    anchor: (n) => ({ desk: { x: 1120, y: 700, s: 1 }, desk2: { x: 940, y: 700, s: 1 }, floor: { x: 980, y: 900, s: 1.3 } } as Record<string, { x: number; y: number; s: number }>)[n] ?? null,
  },
  kitchen: {
    rim: 'rimR',
    wide: { cx: 960, cy: 565, z: 1.0 },
    nativeRed: true,
    point: roomPoint(0.4),
    place: roomPlace(KITCHEN, 0.62),
    draw: (o) => <Kitchen t={o.t} id={o.id} veil={o.veil ?? 0.45} red={o.red} />,
    near: (o) => (flag(o.opts.island, true) ? [{ depth: 0.45, node: <KitchenIsland key="isl" stools={flag(o.opts.stools, true)} /> }] : []),
    anchor: (n) => {
      if (n === 'island') { const p = islandTop(0.6, 0.45); return { x: p.x, y: p.y, s: 0.85 }; }
      if (n === 'island2') { const p = islandTop(0.4, 0.5); return { x: p.x, y: p.y, s: 0.85 }; }
      if (n === 'counter') { const p = KITCHEN.P(0.3, 0.7, 0.075); return { x: p.x, y: p.y, s: 0.6 }; }
      if (n === 'floor') { const p = KITCHEN.P(0.5, 1, 0.75); return { x: p.x, y: p.y, s: 1.3 }; }
      return null;
    },
  },
  bedroom: {
    rim: 'rimR',
    wide: { cx: 940, cy: 560, z: 1.0 },
    nativeRed: false,
    point: roomPoint(0.55),
    place: roomPlace(BEDROOM, 0.62),
    draw: (o) => <Bedroom t={o.t} id={o.id} veil={o.veil ?? 0.46} duvet={!o.inBed} clock={str(o.opts.clock, '03:12')} lamp={anum(o.opts.lamp, o.t, 1)} crossed={num(o.opts.crossed, 9)} />,
    near: (o) => (o.inBed ? [{ depth: 0.1, node: <BedDuvet key="duv" knees={0.7} /> }] : []),
    anchor: (n) => {
      if (n === 'nightstand') { const p = BEDROOM.P(0.47, 0.78, 0.08); return { x: p.x, y: p.y, s: 0.45 }; }
      if (n === 'bed') { const p = bedTop(0.28, 0.32); return { x: p.x, y: p.y, s: 0.7 }; }
      if (n === 'floor') { const p = BEDROOM.P(0.6, 1, 0.6); return { x: p.x, y: p.y, s: 1.2 }; }
      return null;
    },
  },
  classroom: {
    rim: 'rimL',
    wide: { cx: 900, cy: 520, z: 0.95 },
    nativeRed: false,
    point: roomPoint(0.62),
    place: roomPlace(CLS, 0.5),
    draw: (o) => (
      <Classroom
        t={o.t}
        id={o.id}
        solved={flag(o.opts.solved, false)}
        wrong={flag(o.opts.wrong, false)}
        laugh={anum(o.opts.laugh, o.t, 0)}
        board={typeof o.opts.board === 'string' ? <BoardText text={o.opts.board} /> : undefined}
      />
    ),
    near: (o) => (flag(o.opts.desk, false) && o.castX.length ? [{ depth: 0.7, node: <SchoolDesk key="sd" x={o.castX[0]} /> }] : []),
    anchor: (n) => ({ desk: { x: 1260, y: 744, s: 1 }, board: { x: 740, y: 400, s: 1 }, floor: { x: 960, y: 960, s: 1.3 } } as Record<string, { x: number; y: number; s: number }>)[n] ?? null,
  },
  stairwell: {
    rim: 'rimR',
    wide: { cx: 960, cy: 560, z: 0.85 },
    nativeRed: false,
    point: flatPoint({ landing: 230, left: 230, farLeft: 120, stairs: 900, center: 900, bottom: 1640, right: 1640, farRight: 1840 }),
    place: flatPlace(hipGround, 0.9),
    draw: (o) => <Stairwell t={o.t} id={o.id} />,
    near: () => [{ depth: 0.5, node: <Banister key="ban" /> }],
    anchor: (n) => ({ landing: { x: 320, y: 420, s: 0.9 }, bottom: { x: 1720, y: 910, s: 0.9 }, step: { x: 800, y: stepTop(800), s: 0.9 }, floor: { x: 1720, y: 910, s: 0.9 } } as Record<string, { x: number; y: number; s: number }>)[n] ?? null,
  },
  rooftop: {
    rim: 'rimR',
    wide: { cx: 960, cy: 540, z: 1.0 },
    nativeRed: true,
    point: flatPoint({ farLeft: 480, left: 720, center: 960, right: 1200, farRight: 1440 }),
    place: flatPlace(() => 842, 0.72),
    draw: (o) => (
      <Rooftop
        t={o.t}
        sunX={num(o.opts.sunX, 960)}
        sunY={anum(o.opts.sunY, o.t, 640)}
        clock={flag(o.opts.clock, false)}
        spin={anum(o.opts.spin, o.t, 0)}
        red={o.red}
        crack={anum(o.opts.crack, o.t, 0)}
        lightsOut={anum(o.opts.lightsOut, o.t, 0)}
        blackout={anum(o.opts.blackout, o.t, 0)}
        low={num(o.opts.low, 0)}
        cityLit={num(o.opts.cityLit, 1)}
      />
    ),
    near: () => [],
    anchor: (n) => ({ deck: { x: 1130, y: 846, s: 0.9 }, deck2: { x: 790, y: 846, s: 0.9 }, parapet: { x: 1180, y: 790, s: 0.7 }, floor: { x: 1130, y: 846, s: 0.9 } } as Record<string, { x: number; y: number; s: number }>)[n] ?? null,
  },
  office: {
    rim: 'rimR',
    wide: { cx: 960, cy: 560, z: 1.0 },
    nativeRed: true,
    point: roomPoint(0.4),
    place: roomPlace(OFFICE, 0.62),
    draw: (o) => <Office t={o.t} id={o.id} veil={o.veil ?? 0.5} red={o.red} lamp={anum(o.opts.lamp, o.t, 1)} />,
    near: (o) => (flag(o.opts.desk, true) ? [{ depth: 0.48, node: <OfficeDesk key="od" lamp={anum(o.opts.lamp, o.t, 1)} file={flag(o.opts.file, true)} /> }] : []),
    anchor: (n) => {
      if (n === 'desk') { const p = OFFICE.P(0.44, 0.66, 0.53); return { x: p.x, y: p.y, s: 0.9 }; }
      if (n === 'floor') { const p = OFFICE.P(0.5, 1, 0.75); return { x: p.x, y: p.y, s: 1.3 }; }
      return null;
    },
  },
  street: {
    rim: 'rimR',
    wide: { cx: 960, cy: 560, z: 1.0 },
    nativeRed: true,
    point: flatPoint({ farLeft: 300, left: 600, center: 960, right: 1320, farRight: 1640 }),
    place: flatPlace(() => STREET_GROUND, 0.9),
    draw: (o) => <Street t={o.t} id={o.id} night={flag(o.opts.night, false)} red={o.red} blackout={anum(o.opts.blackout, o.t, 0)} traffic={flag(o.opts.traffic, true)} />,
    near: () => [],
    anchor: (n) => ({ bench: { x: 1200, y: 878, s: 0.9 }, ground: { x: 960, y: 946, s: 1 }, floor: { x: 960, y: 946, s: 1 } } as Record<string, { x: number; y: number; s: number }>)[n] ?? null,
  },
  schematic: {
    rim: 'rimR',
    wide: { cx: 960, cy: 540, z: 1.0 },
    nativeRed: false,
    point: flatPoint({ farLeft: 300, left: 600, center: 960, right: 1320, farRight: 1640 }),
    place: flatPlace(() => 920, 0.8),
    draw: (o) => <Schematic t={o.t} id={o.id} />,
    near: () => [],
    anchor: () => ({ x: 960, y: 560, s: 1 }),
  },
  sky: {
    rim: 'rimR',
    wide: { cx: 960, cy: 540, z: 1.0 },
    nativeRed: true,
    point: flatPoint({ farLeft: 300, left: 640, center: 960, right: 1280, farRight: 1620 }),
    place: flatPlace(() => 930, 0.85),
    draw: (o) => <SkySet t={o.t} id={o.id} red={o.red} />,
    near: () => [],
    anchor: (n) => ({ ground: { x: 1140, y: 932, s: 1 }, floor: { x: 1140, y: 932, s: 1 } } as Record<string, { x: number; y: number; s: number }>)[n] ?? null,
  },
};

/** Chalk on the classroom board: one or two lines in the hand face. */
const BoardText: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split('\n').slice(0, 3);
  return (
    <g>
      {lines.map((l, i) => (
        <text key={i} x={740} y={330 + i * 110 - (lines.length - 1) * 40} textAnchor="middle" fontFamily="Kalam" fontSize={lines.length > 1 ? 86 : 110} fill="#EDEFE6" opacity={0.92}>
          {l}
        </text>
      ))}
    </g>
  );
};

export const stageOf = (name: SetName | undefined): Stage => STAGES[name ?? 'study'] ?? STAGES.study;
