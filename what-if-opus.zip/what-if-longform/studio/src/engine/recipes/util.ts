import { kf } from '../anim';
import type { Anim } from '../spec';

/** The value of an Anim at frame t: a number, or [from, to, f0, f1] eased between f0 and f1. */
export const av = (v: Anim | undefined, t: number, d = 0): number => {
  if (v === undefined || v === null) return d;
  if (typeof v === 'number') return v;
  if (Array.isArray(v) && v.length >= 4) return kf(t, [[v[2], v[0]], [v[3], v[1]]]);
  return d;
};

/** The camera as numbers: centre the world point (cx, cy) at zoom z, rolled a few degrees. */
export type Cam = { cx: number; cy: number; z: number; roll: number };
export const camTR = (c: Cam) => `translate(960 540) rotate(${c.roll}) scale(${c.z}) translate(${-c.cx} ${-c.cy})`;
export const toScreen = (c: Cam, p: { x: number; y: number }) => {
  const dx = (p.x - c.cx) * c.z;
  const dy = (p.y - c.cy) * c.z;
  const r = (c.roll * Math.PI) / 180;
  return { x: 960 + dx * Math.cos(r) - dy * Math.sin(r), y: 540 + dx * Math.sin(r) + dy * Math.cos(r) };
};
export const IDENTITY: Cam = { cx: 960, cy: 540, z: 1, roll: 0 };
