import React from 'react';
import { clamp, kf, easeInOut, easeOut } from '../anim';
import { Hero, HEAD, LOOKS, LEG_LEN, Look, joints, toWorld } from '../rig';
import { Foreground } from '../kit';
import { Glow, Dust, LightVeil } from '../light';
import { Tabletop } from '../furnish';
import { TitleCard, ChapterCard, HudChip, Dial, TapeLines, PasteIn } from '../ui';
import { defineEpisode, Timeline, ShotMap, ShotProps, LookDef } from '../episode';
import type { ShotSpec, ChapterSpec, LookSpec, OutlineSpec, CastSpec, ThumbSpec, PropSpec } from '../spec';
import { av, Cam, camTR, IDENTITY } from './util';
import { stageOf, Stage, DrawOpts } from './stages';
import { actorAt, Performer, handOf } from './actors';
import { DrawProp, DrawUI, PlacedProp, Targets } from './things';
import { Diagram } from './diagram';
import { FONT } from '../fonts';

// The recipe engine: one function turns a shot spec (JSON) into a drawn, animated shot. A recipe decides the framing
// and the layers; the spec fills in the set, who is in it, what they do and say with their body, the props, the marks
// and the camera move. Every recipe moves a little by default (a slow push in, a follow), so no shot is ever static.

export const POWER = '#7FD4FF';

const hash = (s: string) => {
  let h = 7;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 9973;
  return h;
};

const DEFAULT_MOVE: Record<string, { move: string; amount: number }> = {
  wide: { move: 'pushIn', amount: 0.6 },
  medium: { move: 'pushIn', amount: 0.5 },
  twoshot: { move: 'pushIn', amount: 0.4 },
  ots: { move: 'pushIn', amount: 0.4 },
  lowangle: { move: 'pushIn', amount: 0.7 },
  walk: { move: 'follow', amount: 1 },
  reveal: { move: 'pullOut', amount: 1.5 },
  title: { move: 'pushIn', amount: 0.9 },
};

const moveCam = (base: Cam, spec: ShotSpec, t: number, len: number): Cam => {
  const d = DEFAULT_MOVE[spec.recipe] ?? { move: 'static', amount: 0 };
  const move = spec.camera?.move ?? d.move;
  const a = spec.camera?.amount ?? d.amount;
  const p = easeInOut(clamp(t / Math.max(1, len)));
  let { cx, cy, z } = base;
  z *= spec.camera?.zoom ?? 1;
  cx += spec.camera?.dx ?? 0;
  cy += spec.camera?.dy ?? 0;
  if (move === 'pushIn') z *= 1 + 0.08 * a * p;
  if (move === 'pullOut') z *= 1 + 0.08 * a * (1 - p);
  if (move === 'panLeft') cx += (50 * a * (1 - 2 * p)) / z;
  if (move === 'panRight') cx -= (50 * a * (1 - 2 * p)) / z;
  if (move === 'tiltUp') cy += (40 * a * (1 - 2 * p)) / z;
  if (move === 'crashZoom') z *= 1 + 0.32 * a * easeOut(clamp(t / 6));
  if (move === 'handheld') {
    cx += (Math.sin(t * 0.13) * 5 + Math.sin(t * 0.37) * 2) * a / z;
    cy += (Math.cos(t * 0.11) * 4 + Math.sin(t * 0.29) * 1.5) * a / z;
  }
  return { cx, cy, z, roll: spec.camera?.roll ?? 0 };
};

/** Darker copy of a costume, for a blurred figure close to camera. */
const darkLook = (l: Look): Look => ({ ...l, skin: '#1A1724', skinShade: '#14121C', hand: '#1A1724', jacket: '#14121C', jacketShade: '#100E16', limb: '#14121C', accent: '#2A2434', face: '#0E0C14', hair: '#100E16', shoe: '#14121C', line: '#0B0A10' });

const ActorNode: React.FC<{ a: Performer; t: number; color: string; dark?: boolean }> = ({ a, t, color, dark }) => {
  const hero = <Hero look={dark ? darkLook(a.look) : a.look} pose={a.pose} rimId={dark ? 'rimL' : a.rim} shadow={dark ? 0 : 0.5} />;
  if (a.spec.paste !== undefined) {
    const cy = a.pose.y - 60 * a.pose.scale;
    return (
      <PasteIn x={a.pose.x} y={cy} t={t - a.spec.paste} color={color} ring={160 * a.pose.scale}>
        {hero}
      </PasteIn>
    );
  }
  return hero;
};

/** Props placed in world units on this stage (or on screen for inserts). */
const placeProps = (props: PropSpec[] | undefined, stage: Stage, actors: Performer[], screen: boolean): PlacedProp[] =>
  (props ?? []).map((q, i) => {
    const n = (props ?? []).length;
    const s0 = q.s ?? 1;
    if (q.at === 'hand' && actors[q.hand ?? 0]) {
      const a = actors[q.hand ?? 0];
      const h = handOf(a);
      return { spec: q, x: h.x, y: h.y + 26 * a.pose.scale, s: s0 * a.pose.scale * 0.9 };
    }
    if (Array.isArray(q.at)) return { spec: q, x: q.at[0] ?? 960, y: q.at[1] ?? 540, s: s0 };
    if (typeof q.at === 'string' && !screen) {
      const an = stage.anchor(q.at);
      if (an) return { spec: q, x: an.x + (i > 0 && q.at === (props ?? [])[i - 1]?.at ? 90 * i : 0), y: an.y, s: s0 * an.s };
    }
    return screen ? { spec: q, x: 960 + (i - (n - 1) / 2) * 380, y: 600, s: s0 } : { spec: q, x: 960 + (i - (n - 1) / 2) * 160, y: 846, s: s0 };
  });

const ForegroundShapes: React.FC<{ side: string }> = ({ side }) => (
  <Foreground blur={10}>
    {side === 'left' || side === 'both' ? (
      <g>
        <path d="M -140 1220 L -140 860 Q -128 786 -30 786 L 236 786 Q 322 786 334 862 L 344 1220 Z" fill="#140F1A" />
        <path d="M -60 790 Q 110 776 262 790" stroke="#FFB46A" strokeWidth={4} fill="none" opacity={0.35} />
      </g>
    ) : null}
    {side === 'right' || side === 'both'
      ? [[1790, 1160, -150, -330], [1880, 1180, -40, -380], [1960, 1150, -210, -250], [1840, 1200, 90, -300]].map(([x, y, dx, dy], i) => (
          <path key={i} d={`M ${x} ${y} Q ${x + dx * 0.2} ${y + dy * 0.6} ${x + dx} ${y + dy} Q ${x + dx * 0.6} ${y + dy * 0.3} ${x} ${y} Z`} fill="#0E1610" />
        ))
      : null}
    {side === 'bottom' ? <rect x={-100} y={960} width={2120} height={200} rx={20} fill="#120D16" /> : null}
  </Foreground>
);

/** A big dark head and shoulder in the near foreground: the over-the-shoulder figure. */
const ShoulderFigure: React.FC<{ side: 'left' | 'right' }> = ({ side }) => (
  <Foreground blur={16}>
    <g transform={side === 'right' ? 'translate(1920 0) scale(-1 1)' : undefined}>
      <path d="M -120 1120 Q -100 700 120 640 Q 330 600 420 760 Q 500 840 560 1120 Z" fill="#14121C" />
      <circle cx={230} cy={520} r={190} fill="#1A1724" />
      <path d="M 70 470 Q 100 300 230 300 Q 360 300 390 470" stroke="#FFB46A" strokeWidth={6} fill="none" opacity={0.3} />
    </g>
  </Foreground>
);

// ---------- the recipes ----------
type RP = { spec: ShotSpec; t: number; len: number; f: number; color: string };

const prep = (spec: ShotSpec, t: number, len: number, color: string, override?: Partial<Stage>) => {
  const stage = { ...stageOf(spec.set ?? (spec.recipe === 'schematic' ? 'schematic' : 'study')), ...(override ?? {}) } as Stage;
  const wt = spec.freeze !== undefined ? Math.min(t, spec.freeze) : t; // the world's clock: it stops when the power pauses it
  const red = clamp(av(spec.mood?.red, wt, 0));
  const cast = spec.cast ?? [];
  const actors = cast.map((c, i) => actorAt(stage, c, i, cast.length, c.frozen ? wt : t, len, red, color));
  const inBed = cast.some((c) => c.at === 'bed');
  const st = wt + (hash(spec.id) % 240);
  const opts: DrawOpts = { t: st, id: `${spec.id.toLowerCase()}s`, red, veil: spec.mood?.veil, opts: spec.opts ?? {}, inBed, castX: actors.map((a) => a.pose.x) };
  return { stage, red, actors, opts, wt };
};

const StageShot: React.FC<RP> = ({ spec, t, len, color }) => {
  const r = spec.recipe;
  const lowRoof = r === 'lowangle' && (spec.set === 'rooftop' || spec.set === 'sky');
  const override: Partial<Stage> | undefined = lowRoof
    ? { place: (p) => ({ x: p.kind === 'flat' ? p.x : 960, y: 1042 - LEG_LEN * 1.8, scale: 1.8, depth: 0.4, ground: () => 1042 }) }
    : undefined;
  const { stage, red, actors, opts, wt } = prep(spec, t, len, color, override);
  const pt = (p: PlacedProp) => (p.spec.live || p.spec.at === 'hand' ? t : wt);
  if (lowRoof) opts.opts = { low: 260, ...opts.opts };
  const a0 = actors[0];
  const a1 = actors[1];
  let base: Cam = { ...stage.wide, roll: 0 };
  if (a0 && (r === 'medium' || r === 'ots' || (r === 'lowangle' && !lowRoof))) {
    const s = a0.pose.scale;
    const z = clamp((r === 'ots' ? 700 : 810) / (378 * s), 1.1, 3.6);
    base = { cx: a0.place.x, cy: a0.place.y - 110 * s, z, roll: 0 };
    if (r === 'ots') base.cx = a0.place.x - 190 / z;
    if (r === 'lowangle') base = { ...base, cy: a0.place.y - 40 * s, z: z * 1.05 };
  }
  if (lowRoof) base = { cx: 960, cy: 540, z: 1, roll: 0 };
  if (r === 'twoshot' && a0 && a1) {
    const s = (a0.pose.scale + a1.pose.scale) / 2;
    base = { cx: (a0.place.x + a1.place.x) / 2, cy: (a0.place.y + a1.place.y) / 2 - 90 * s, z: clamp(1500 / (Math.abs(a0.place.x - a1.place.x) + 420 * s), 0.9, 2.4), roll: 0 };
  }
  if (r === 'walk' && a0) {
    const s = a0.pose.scale;
    base = { cx: clamp(a0.pose.x, 640, 1280), cy: a0.pose.y - 60 * s, z: clamp(0.95 / s, 0.9, 2.2), roll: 0 };
  }
  const cam = moveCam(base, spec, t, len);
  if ((spec.camera?.move ?? DEFAULT_MOVE[r]?.move) === 'follow' && a0) cam.cx = clamp(a0.pose.x, 520, 1400) + (spec.camera?.dx ?? 0);
  const props = placeProps(spec.props, stage, actors, false);
  const layers: { depth: number; node: React.ReactNode }[] = [];
  actors.forEach((a, i) => {
    if (!a.spec.blur) layers.push({ depth: a.depth + i * 1e-4, node: <ActorNode key={`a${i}`} a={a} t={t} color={color} /> });
  });
  stage.near(opts).forEach((nl, i) => layers.push({ depth: nl.depth, node: <g key={`n${i}`}>{nl.node}</g> }));
  layers.sort((x, y) => x.depth - y.depth);
  const T: Targets = { actors, props, cam };
  const blurred = actors.filter((a) => a.spec.blur);
  return (
    <g>
      <g transform={camTR(cam)}>
        {stage.draw(opts)}
        {red > 0 && !stage.nativeRed ? <rect x={-1500} y={-1500} width={5000} height={4500} fill="#3A0010" opacity={0.42 * red} style={{ mixBlendMode: 'multiply' }} /> : null}
        {props.map((p, i) => (p.spec.back ? <DrawProp key={`pb${i}`} p={p} t={pt(p)} color={color} /> : null))}
        {layers.map((l) => l.node)}
        {props.map((p, i) => (!p.spec.back ? <DrawProp key={`pf${i}`} p={p} t={pt(p)} color={color} /> : null))}
      </g>
      {spec.mood?.dim ? <rect x={0} y={0} width={1920} height={1080} fill="#07040C" opacity={spec.mood.dim} /> : null}
      {blurred.map((a, i) => (
        <Foreground key={`bf${i}`} blur={16}>
          <g transform={camTR(cam)}>
            <ActorNode a={a} t={t} color={color} dark />
          </g>
        </Foreground>
      ))}
      {r === 'ots' && !blurred.length ? <ShoulderFigure side={a0 && a0.place.x - cam.cx >= 0 ? 'left' : 'right'} /> : null}
      {r === 'lowangle' && !lowRoof ? <Foreground blur={10}><rect x={-100} y={990} width={2120} height={200} fill="#0E0B12" /></Foreground> : null}
      {spec.foreground && spec.foreground !== 'none' ? <ForegroundShapes side={spec.foreground} /> : null}
      {r === 'title' ? <TitleCard t={t} lines={[spec.title?.[0] ?? 'WHAT IF YOU COULD', spec.title?.[1] ?? '...']} accent={spec.accent} accentT={34} size={(spec.title?.[1] ?? '').length > 20 ? 88 : (spec.title?.[1] ?? '').length > 14 ? 104 : 128} y={170} /> : null}
      {(spec.ui ?? []).map((u, i) => <DrawUI key={`u${i}`} u={u} t={t} T={T} color={color} />)}
    </g>
  );
};

const CloseShot: React.FC<RP> = ({ spec, t, len, color }) => {
  const { stage, red, actors, opts, wt } = prep(spec, t, len, color);
  const a0 = actors[0];
  if (!a0) return <StageShot spec={{ ...spec, recipe: 'wide' }} t={t} len={len} f={0} color={color} />;
  const xcu = spec.recipe === 'xcu';
  const hx = a0.pose.x;
  const hy = a0.pose.y + HEAD.y * a0.pose.scale;
  const p = easeInOut(clamp(t / Math.max(1, len)));
  const move = spec.camera?.move ?? 'pushIn';
  const push = move === 'pushIn' ? 1 + 0.05 * (spec.camera?.amount ?? 1) * p : move === 'pullOut' ? 1.05 - 0.05 * p : move === 'crashZoom' ? 1 + 0.3 * easeOut(clamp(t / 6)) : 1;
  const sc = (xcu ? 6.4 : 3.7) * (spec.camera?.zoom ?? 1) * push;
  const yaw = a0.pose.yaw;
  const sx = xcu ? 960 : yaw > 0.2 ? 820 : yaw < -0.2 ? 1100 : 960;
  const sy = xcu ? 700 : 570;
  const hh = move === 'handheld' ? { x: Math.sin(t * 0.13) * 6, y: Math.cos(t * 0.11) * 5 } : { x: 0, y: 0 };
  const giant: Performer = { ...a0, pose: { ...a0.pose, x: sx + hh.x, y: sy + hh.y - HEAD.y * sc, scale: sc } };
  const bg = `translate(${960 - 2 * hx} ${540 - 2 * hy}) scale(2)`;
  const others = actors.slice(1);
  const props = placeProps(spec.props, stage, [giant, ...others], true).map((pp, i) => (spec.props?.[i]?.at === 'hand' ? pp : { ...pp }));
  const T: Targets = { actors: [giant, ...others], props, cam: IDENTITY };
  return (
    <g transform={spec.camera?.roll ? `rotate(${spec.camera.roll} 960 540)` : undefined}>
      <g filter="url(#blur16)">
        <g transform={bg}>
          {stage.draw({ ...opts, id: `${opts.id}cb` })}
          {others.map((a, i) => <ActorNode key={`o${i}`} a={a} t={t} color={color} />)}
          {stage.near(opts).map((nl, i) => <g key={`n${i}`}>{nl.node}</g>)}
        </g>
      </g>
      <rect x={0} y={0} width={1920} height={1080} fill="#07040C" opacity={0.22 + (spec.mood?.dim ?? 0)} />
      {red > 0 ? <rect x={0} y={0} width={1920} height={1080} fill="#5A0010" opacity={0.3 * red} style={{ mixBlendMode: 'multiply' }} /> : null}
      <ActorNode a={giant} t={t} color={color} />
      {props.map((pp, i) => <DrawProp key={`p${i}`} p={pp} t={pp.spec.live || pp.spec.at === 'hand' ? t : wt} color={color} />)}
      {spec.foreground && spec.foreground !== 'none' ? <ForegroundShapes side={spec.foreground} /> : null}
      {(spec.ui ?? []).map((u, i) => <DrawUI key={`u${i}`} u={u} t={t} T={T} color={color} />)}
    </g>
  );
};

const InsertShot: React.FC<RP> = ({ spec, t, len, color }) => {
  const top = spec.recipe === 'topdown';
  const surf = spec.surface ?? 'wood';
  const edge = spec.edge ?? (top ? 1400 : 900);
  const p = clamp(t / Math.max(1, len));
  const props = placeProps(spec.props, stageOf(spec.set), [], true);
  const wt = spec.freeze !== undefined ? Math.min(t, spec.freeze) : t;
  const arm = spec.arm;
  const look = LOOKS[arm?.who ?? 'pipHood'] ?? LOOKS.pipHood;
  let armNode: React.ReactNode = null;
  if (arm && arm.keys && arm.keys.length) {
    const hx = kf(t, arm.keys.map((k) => [k[0], k[1]] as [number, number]));
    const hy = kf(t, arm.keys.map((k) => [k[0], k[2]] as [number, number]));
    const from = arm.from ?? 'right';
    const off = from === 'right' ? { x: 2300, y: hy - 380 } : from === 'left' ? { x: -380, y: hy - 380 } : from === 'top' ? { x: hx + 260, y: -420 } : { x: hx + 200, y: 1500 };
    const mid = { x: (hx + off.x) / 2 + (from === 'top' || from === 'bottom' ? 60 : 0), y: (hy + off.y) / 2 + (from === 'left' || from === 'right' ? 90 : 0) };
    const ang = (Math.atan2(hy - off.y, hx - off.x) * 180) / Math.PI - 90;
    const d = `M ${hx} ${hy} Q ${mid.x} ${mid.y} ${off.x} ${off.y}`;
    armNode = (
      <g filter="url(#rimR)">
        <path d={d} stroke={look.line} strokeWidth={124} fill="none" strokeLinecap="round" />
        <path d={d} stroke={look.limb} strokeWidth={106} fill="none" strokeLinecap="round" />
        <g transform={`translate(${hx} ${hy}) rotate(${ang}) scale(4.8)`}>
          {arm.point !== false ? (
            <g>
              <rect x={-4} y={10} width={8} height={24} rx={4} fill={look.hand} stroke={look.line} strokeWidth={2.3} />
              <path d="M -11 -2 Q -14 14 -6 18 L 7 18 Q 14 14 11 -2 Z" fill={look.hand} stroke={look.line} strokeWidth={2.5} strokeLinejoin="round" />
              <ellipse cx={-10} cy={6} rx={4.5} ry={7} fill={look.hand} stroke={look.line} strokeWidth={2.3} />
            </g>
          ) : (
            <g>
              <ellipse cx={-10} cy={3} rx={5.5} ry={9} fill={look.hand} stroke={look.line} strokeWidth={2.4} />
              <ellipse cx={0} cy={10} rx={11} ry={15} fill={look.hand} stroke={look.line} strokeWidth={2.4} />
            </g>
          )}
        </g>
      </g>
    );
  }
  const frame = top ? `translate(960 540) rotate(${-2 + t * 0.05}) scale(${1 + t * 0.002}) translate(-960 -540)` : `translate(960 540) scale(${1 + 0.05 * easeInOut(p)}) translate(-960 -540)`;
  const T: Targets = { actors: [], props, cam: IDENTITY };
  return (
    <g>
      <g transform={frame}>
        {surf === 'paper' ? (
          <g>
            <rect x={-400} y={-400} width={2720} height={1880} fill="#E9E0CC" />
            {Array.from({ length: 30 }).map((_, i) => <path key={i} d={`M -400 ${-300 + i * 64} L 2320 ${-300 + i * 64}`} stroke="#B9C4D6" strokeWidth={2} opacity={0.6} />)}
          </g>
        ) : surf === 'stone' ? (
          <Tabletop edge={edge} wood="#A89C8A" grain="#968A78" lip="#8E8474" kind="stone" floor="#2C2A30" floorLines="#232127" />
        ) : (
          <Tabletop edge={edge} />
        )}
        <LightVeil id={`${spec.id}iv`} lights={[[960, 460, 820]]} o={0.42} />
        <Glow x={980} y={430} r={640} o={0.32} />
        {props.map((pp, i) => <DrawProp key={`p${i}`} p={pp} t={pp.spec.live ? t : wt} color={color} />)}
        {armNode}
      </g>
      {spec.foreground && spec.foreground !== 'none' ? <ForegroundShapes side={spec.foreground} /> : null}
      {(spec.ui ?? []).map((u, i) => <DrawUI key={`u${i}`} u={u} t={t} T={T} color={color} />)}
    </g>
  );
};

const ChapterShot: React.FC<RP> = ({ spec, t, len, color }) => {
  const { stage, actors, opts } = prep(spec, t, len, color);
  const z = 1.08 + 0.04 * clamp(t / Math.max(1, len));
  return (
    <g>
      <g filter="url(#blur10)">
        <g transform={camTR({ ...stage.wide, z: stage.wide.z * z, roll: 0 })}>
          {stage.draw(opts)}
          {actors.map((a, i) => <ActorNode key={i} a={a} t={t} color={color} />)}
        </g>
      </g>
      <rect x={0} y={0} width={1920} height={1080} fill="#07040C" opacity={0.55} />
      <Dust t={t} seed={77} x0={300} y0={200} w={1320} h={700} n={30} o={0.35} />
      <ChapterCard t={t} label={spec.title?.[0] ?? 'PART'} title={spec.title?.[1] ?? ''} color={spec.accent ?? undefined} size={(spec.title?.[1] ?? '').length > 18 ? 96 : 120} />
      {(spec.ui ?? []).map((u, i) => <DrawUI key={`u${i}`} u={u} t={t} T={{ actors: [], props: [], cam: IDENTITY }} color={color} />)}
    </g>
  );
};

const SchematicShot: React.FC<RP> = ({ spec, t, len, color }) => (
  <g>
    <Diagram d={spec.diagram ?? { layout: 'list', items: [{ text: spec.note ?? '' }] }} t={t} len={len} id={`${spec.id.toLowerCase()}d`} />
    {(spec.ui ?? []).map((u, i) => <DrawUI key={`u${i}`} u={u} t={t} T={{ actors: [], props: [], cam: IDENTITY }} color={color} />)}
  </g>
);

export const RecipeShot: React.FC<RP> = (p) => {
  switch (p.spec.recipe) {
    case 'closeup':
    case 'xcu':
      return <CloseShot {...p} />;
    case 'insert':
    case 'topdown':
      return <InsertShot {...p} />;
    case 'chapter':
      return <ChapterShot {...p} />;
    case 'schematic':
      return <SchematicShot {...p} />;
    default:
      return <StageShot {...p} />;
  }
};

/** Every shot in a chapter as a component the episode engine can play, cut back to, hold or reverse. */
export const makeShots = (ch: ChapterSpec, color = POWER): ShotMap => {
  const m: ShotMap = {};
  for (const s of ch.shots ?? []) {
    if (s.custom) continue;
    const Comp: React.FC<ShotProps> = ({ t, len, f }) => <RecipeShot spec={s} t={t} len={len} f={f} color={color} />;
    m[s.id] = Comp;
  }
  return m;
};

/** A power's look from outline.json: the grade while it runs and what goes on top (a chip, tape lines, a dial, a tint). */
export const makeLooks = (looks: Record<string, LookSpec> | undefined): Record<string, LookDef> => {
  const out: Record<string, LookDef> = {};
  for (const [name, L] of Object.entries(looks ?? {})) {
    out[name] = {
      grade: (lv) =>
        `saturate(${1 + ((L.saturate ?? 1) - 1) * lv}) hue-rotate(${(L.hue ?? 0) * lv}deg) brightness(${1 + ((L.brightness ?? 1) - 1) * lv}) contrast(${1 + ((L.contrast ?? 1) - 1) * lv})`,
      jitter: L.jitter,
      Overlay: ({ f, p }) => {
        const dv = L.dial ? L.dial.from + (L.dial.to - L.dial.from) * p : 0;
        const read = L.dial ? `${Math.abs(dv) >= 100 ? Math.round(dv) : dv.toFixed(1)}${L.dial.unit ?? ''}` : '';
        return (
          <g>
            {L.tint ? <rect x={0} y={0} width={1920} height={1080} fill={L.tint} opacity={L.tintO ?? 0.12} /> : null}
            {L.tape ? <TapeLines f={f} /> : null}
            {L.frame ? (
              <g stroke="#F6EFE3" strokeWidth={6} fill="none" opacity={0.8}>
                <path d="M 60 140 L 60 60 L 140 60 M 1780 60 L 1860 60 L 1860 140 M 60 940 L 60 1020 L 140 1020 M 1780 1020 L 1860 1020 L 1860 940" />
              </g>
            ) : null}
            {L.chip ? <HudChip f={f} label={L.chip.label} icon={L.chip.icon ?? 'dot'} /> : null}
            {L.dial ? <Dial p={1 - p} readout={read} /> : null}
          </g>
        );
      },
    };
  }
  return out;
};

/** A chapter as two compositions (<Id> and <Id>Board), built from its JSON, with any hand-drawn shots merged in. */
export const makeChapter = (compId: string, chapter: ChapterSpec, outline: OutlineSpec, timeline: Timeline, custom: ShotMap = {}) =>
  defineEpisode(compId, {
    timeline,
    shots: { ...makeShots(chapter, outline.power?.color ?? POWER), ...custom },
    looks: makeLooks(outline.looks),
  });

// ---------- the thumbnail ----------
/** The thumbnail: the set soft behind, the hero huge on one side with a strong face, 2 to 4 big words on the other. */
export const Thumbnail: React.FC<{ spec: ThumbSpec; color?: string }> = ({ spec, color = POWER }) => {
  const stage = stageOf(spec.set ?? 'rooftop');
  const cast: CastSpec = { who: spec.who ?? 'pipHood', face: 'left', expr: [[0, spec.expr ?? 'shock']], glint: spec.glint ? [0, spec.glint] : undefined, glintColor: spec.glintColor };
  const a = actorAt(stage, cast, 0, 1, 12, 24, 0, color);
  const sc = 5.2;
  const giant: Performer = { ...a, pose: { ...a.pose, x: 1460, y: 600 - HEAD.y * sc, scale: sc, blink: 0, look: -0.5 }, rim: spec.red ? 'rimRed' : 'rimR' };
  const lines = spec.lines ?? ['WHAT', 'IF?'];
  const opts: DrawOpts = { t: 40, id: 'thumbs', red: spec.red ?? 0, opts: {}, inBed: false, castX: [] };
  return (
    <g>
      <g filter="url(#blur6)">
        <g transform={camTR({ ...stage.wide, z: stage.wide.z * 1.15, roll: 0 })}>{stage.draw(opts)}</g>
      </g>
      <defs>
        <linearGradient id="thumbFade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#07040C" stopOpacity={0.85} />
          <stop offset="60%" stopColor="#07040C" stopOpacity={0.2} />
          <stop offset="100%" stopColor="#07040C" stopOpacity={0} />
        </linearGradient>
      </defs>
      <rect x={0} y={0} width={1920} height={1080} fill="url(#thumbFade)" />
      <Glow x={1460} y={520} r={620} o={0.45} kind={spec.red ? 'red' : 'warm'} />
      <Hero look={giant.look} pose={giant.pose} rimId={giant.rim} shadow={0} />
      {lines.slice(0, 4).map((l, i) => {
        const acc = spec.accent && l.replace(/[^\w]/g, '') === spec.accent.replace(/[^\w]/g, '');
        const longest = Math.max(...lines.slice(0, 4).map((x) => x.length), 1);
        const size = Math.min(lines.length > 2 ? 170 : 220, 860 / (longest * 0.64));
        return (
          <text key={i} x={90} y={300 + i * (size * 0.98)} fontFamily={FONT.title} fontWeight={800} fontSize={size} fill={acc ? '#FFE27A' : '#F6EFE3'} stroke="#120C1E" strokeWidth={18} paintOrder="stroke" style={{ filter: acc ? 'drop-shadow(0 0 26px rgba(255,226,122,0.6))' : undefined }}>
            {l}
          </text>
        );
      })}
    </g>
  );
};

export { joints, toWorld };
