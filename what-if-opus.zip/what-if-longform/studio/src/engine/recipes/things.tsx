import React from 'react';
import { clamp, backOut, easeIn, easeOut, settle, rnd } from '../anim';
import { HEAD } from '../rig';
import {
  Cookie, CookieTop, CookieStack, Mug, Plate, PlateTop, Paper, PaperStack, Phone, OpenBook, BookTower, AlarmClock, WallCalendar, PizzaSlice, PizzaBox, PaperBall, Cat, LaptopBack,
} from '../props';
import { Marquee, PasteIn, Tag, Toast, FloatLabel, Sparkle, FocusRings, DizzyStars, HudChip, Dial, Gauge, Stamp, UI } from '../ui';
import { Arrow } from '../sets/schematic';
import { FONT } from '../fonts';
import type { PropSpec, UISpec, PropKind } from '../spec';
import { av, Cam, toScreen } from './util';
import type { Performer } from './actors';
import { headOf, boxOf } from './actors';

// Props and on-screen marks for the recipe engine. Props draw in world units inside the camera; marks draw on the
// screen after it, so a selection box or a stamp keeps the same weight at any zoom.

// ---------- a few props the long form needs that the kit didn't have ----------
const CashStack: React.FC<{ x: number; y: number; n?: number; s?: number }> = ({ x, y, n = 4, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <ellipse cx={6} cy={2} rx={110} ry={12} fill="#000" opacity={0.3} />
    {Array.from({ length: n }).map((_, i) => (
      <g key={i} transform={`translate(${Math.sin(i * 2.1) * 6} ${-i * 16})`}>
        <polygon points="-100,0 100,0 84,-14 -84,-14" fill={i === n - 1 ? '#8FC48A' : '#6FA46A'} />
        <rect x={-100} y={0} width={200} height={4} fill="#4E7E4A" />
        <rect x={-14} y={-14} width={28} height={14} fill="#E9E2D2" opacity={0.7} />
      </g>
    ))}
  </g>
);
const Envelope: React.FC<{ x: number; y: number; s?: number; rot?: number }> = ({ x, y, s = 1, rot = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-96} y={-62} width={192} height={124} rx={6} fill="#000" opacity={0.3} transform="translate(8 10)" />
    <rect x={-96} y={-62} width={192} height={124} rx={6} fill="#EFE6D2" />
    <path d="M -96 -62 L 0 10 L 96 -62" stroke="#C9BCA2" strokeWidth={5} fill="none" />
    <circle cx={0} cy={10} r={16} fill="#A8323E" />
  </g>
);
const Badge: React.FC<{ x: number; y: number; s?: number; rot?: number }> = ({ x, y, s = 1, rot = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-110} y={-70} width={220} height={140} rx={14} fill="#1E2230" />
    <rect x={-96} y={-56} width={70} height={84} rx={6} fill="#3A4256" />
    <circle cx={-61} cy={-26} r={18} fill="#D9C6AE" />
    <rect x={-10} y={-50} width={104} height={12} rx={6} fill="#C9A86A" />
    <rect x={-10} y={-26} width={86} height={8} rx={4} fill="#9AA2AE" />
    <rect x={-10} y={-8} width={70} height={8} rx={4} fill="#9AA2AE" />
    <rect x={-110} y={44} width={220} height={26} fill="#A8323E" />
  </g>
);
const Glass: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <ellipse cx={4} cy={2} rx={34} ry={7} fill="#000" opacity={0.3} />
    <path d="M -26 -90 L 26 -90 L 20 0 L -20 0 Z" fill="#BFD6FF" opacity={0.35} />
    <path d="M -24 -56 L 24 -56 L 20 0 L -20 0 Z" fill="#9FC0FF" opacity={0.45} />
    <path d="M -20 -84 L -16 -6" stroke="#FFFFFF" strokeWidth={5} opacity={0.5} strokeLinecap="round" />
  </g>
);
const Parcel: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <ellipse cx={8} cy={2} rx={110} ry={12} fill="#000" opacity={0.3} />
    <path d="M -90 0 L 90 0 L 90 -110 L -90 -110 Z" fill="#B98A5A" />
    <path d="M -90 -110 L -60 -140 L 120 -140 L 90 -110 Z" fill="#CFA070" />
    <path d="M 90 0 L 120 -30 L 120 -140 L 90 -110 Z" fill="#9A6E44" />
    <path d="M -10 -110 L 20 -140 M -10 0 L -10 -110" stroke="#E9D9A0" strokeWidth={10} />
  </g>
);

/** Rough size of each prop at s = 1 in world units, for selection boxes: [width, height]. */
const SIZE: Record<PropKind, [number, number]> = {
  cookie: [80, 46], cookieTop: [130, 130], cookies: [80, 90], mug: [70, 80], plate: [170, 30], plateTop: [340, 340], paper: [300, 390], papers: [230, 80],
  phone: [200, 410], book: [210, 100], books: [170, 120], clock: [130, 60], calendar: [300, 400], pizza: [210, 150], pizzaBox: [270, 200], ball: [80, 80],
  cat: [150, 110], laptop: [190, 130], cash: [210, 80], envelope: [200, 130], badge: [220, 140], glass: [60, 92], box: [220, 150],
};

export type PlacedProp = { spec: PropSpec; x: number; y: number; s: number };

/** A prop's selection box in world units: [x, y, w, h]. */
export const propBox = (p: PlacedProp): [number, number, number, number] => {
  const [w, h] = SIZE[p.spec.kind] ?? [120, 100];
  const sw = w * p.s;
  const sh = h * p.s;
  const centred = ['cookieTop', 'plateTop', 'paper', 'phone', 'calendar', 'ball', 'envelope', 'badge'].includes(p.spec.kind);
  return centred ? [p.x - sw / 2, p.y - sh / 2, sw, sh] : [p.x - sw / 2, p.y - sh, sw, sh];
};

const PropBody: React.FC<{ p: PlacedProp; t: number }> = ({ p, t }) => {
  const { spec: q, x, y, s } = p;
  const rot = av(q.rot, t, 0);
  const sc = (k: number, node: React.ReactNode) => <g transform={`translate(${x} ${y}) scale(${k}) translate(${-x} ${-y})`}>{node}</g>;
  switch (q.kind) {
    case 'cookie': return <Cookie x={x} y={y} s={0.85 * s} rot={rot} bite={av(q.bite, t, 0)} seed={Math.round(x + y) % 997} />;
    case 'cookieTop': return <CookieTop x={x} y={y} r={60 * s} rot={rot} />;
    case 'cookies': return <CookieStack x={x} y={y} n={q.n ?? 5} s={0.8 * s} />;
    case 'mug': return sc(s, <Mug x={x} y={y} rot={rot} steam={av(q.on, t, 1)} f={t} />);
    case 'plate': return <Plate x={x} y={y} s={0.7 * s} />;
    case 'plateTop': return <PlateTop x={x} y={y} r={170 * s} />;
    case 'paper': return <Paper x={x} y={y} w={300 * s} rot={rot} done={q.done ?? true} grade={q.grade ?? 'A+'} fill={av(q.fill, t, 1)} />;
    case 'papers': return <PaperStack x={x} y={y} n={q.n ?? 8} w={220 * s} />;
    case 'phone': return <Phone x={x} y={y} w={200 * s} rot={rot} on={av(q.on, t, 0)} caller={q.caller ?? 'MUM'} buzz={av(q.buzz, t, 0)} f={t} />;
    case 'book': return <OpenBook x={x} y={y} w={200 * s} rot={rot} turn={av(q.turn, t, 0)} />;
    case 'books': return <BookTower x={x} y={y} n={q.n ?? 6} s={s} />;
    case 'clock': return <AlarmClock x={x} y={y} s={0.5 * s} text={q.text ?? '03:00'} on={av(q.on, t, 1)} />;
    case 'calendar': return <WallCalendar x={x} y={y} w={300 * s} crossed={q.n ?? 0} drawing={av(q.fill, t, 0)} rot={rot} />;
    case 'pizza': return <PizzaSlice x={x} y={y} len={200 * s} rot={rot} bite={av(q.bite, t, 0)} />;
    case 'pizzaBox': return <PizzaBox x={x} y={y} w={260 * s} />;
    case 'ball': return <PaperBall x={x} y={y} r={40 * s} rot={rot} />;
    case 'cat': return sc(s, <Cat x={x} y={y} mood={q.mood ?? 'sleep'} f={t} />);
    case 'laptop': return <LaptopBack x={x} y={y} w={180 * s} glow={av(q.on, t, 1)} />;
    case 'cash': return <CashStack x={x} y={y} n={q.n ?? 4} s={s} />;
    case 'envelope': return <Envelope x={x} y={y} s={s} rot={rot} />;
    case 'badge': return <Badge x={x} y={y} s={s} rot={rot} />;
    case 'glass': return <Glass x={x} y={y} s={s} />;
    case 'box': return <Parcel x={x} y={y} s={s} />;
    default: return null;
  }
};

/** A prop with its entrance: a pop (t), the power's paste (paste) or a fall (drop); a glitching ghost if asked. */
export const DrawProp: React.FC<{ p: PlacedProp; t: number; color: string }> = ({ p, t, color }) => {
  const q = p.spec;
  if (q.paste !== undefined) {
    const [, , , h] = propBox(p);
    return (
      <PasteIn x={p.x} y={p.y - h / 2} t={t - q.paste} color={color} ring={Math.max(50, h * 0.6)}>
        <PropBody p={p} t={t} />
      </PasteIn>
    );
  }
  if (q.drop !== undefined) {
    if (t < q.drop - 8) return null;
    const k = easeIn(clamp((t - (q.drop - 8)) / 8));
    const dy = -420 * (1 - k) + (t > q.drop ? settle(t - q.drop, 8, 1.6, 4) : 0);
    return (
      <g transform={`translate(0 ${dy})`}>
        <PropBody p={p} t={t} />
      </g>
    );
  }
  if (q.t !== undefined) {
    if (t < q.t) return null;
    const s = backOut(clamp((t - q.t) / 6));
    const [, , , h] = propBox(p);
    return (
      <g transform={`translate(${p.x} ${p.y - h / 2}) scale(${0.4 + 0.6 * s}) translate(${-p.x} ${-(p.y - h / 2)})`} opacity={clamp((t - q.t) / 3)}>
        <PropBody p={p} t={t} />
      </g>
    );
  }
  if (q.glitch) {
    const g = Math.floor(t / 2);
    const on = rnd(g, 3) > 0.4;
    return (
      <g>
        <g opacity={on ? 0.45 : 0.15} transform={`translate(${(rnd(g, 1) - 0.5) * 22 + 12} ${(rnd(g, 2) - 0.5) * 10})`} style={{ mixBlendMode: 'screen' }}>
          <PropBody p={p} t={t} />
        </g>
        <PropBody p={p} t={t} />
      </g>
    );
  }
  return <PropBody p={p} t={t} />;
};

// ---------- marks on the screen ----------
export type Targets = { actors: Performer[]; props: PlacedProp[]; cam: Cam };

/** A target to a screen box [x, y, w, h]. */
export const screenBox = (target: string | number[] | undefined, T: Targets): [number, number, number, number] => {
  if (Array.isArray(target)) {
    if (target.length >= 4) return [target[0], target[1], target[2], target[3]];
    return [(target[0] ?? 960) - 60, (target[1] ?? 540) - 60, 120, 120];
  }
  const m = /^(cast|prop|head)(\d+)$/.exec(target ?? 'cast0');
  const kind = m ? m[1] : 'cast';
  const i = m ? Number(m[2]) : 0;
  let wb: [number, number, number, number] = [900, 480, 120, 120];
  if (kind === 'prop' && T.props[i]) wb = propBox(T.props[i]);
  else if (kind === 'head' && T.actors[i]) {
    const h = headOf(T.actors[i]);
    const r = HEAD.r * T.actors[i].pose.scale;
    wb = [h.x - r, h.y - r, 2 * r, 2 * r];
  } else if (T.actors[i]) wb = boxOf(T.actors[i]);
  const a = toScreen(T.cam, { x: wb[0], y: wb[1] });
  const b = toScreen(T.cam, { x: wb[0] + wb[2], y: wb[1] + wb[3] });
  return [Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y)];
};

export const DrawUI: React.FC<{ u: UISpec; t: number; T: Targets; color: string }> = ({ u, t, T, color }) => {
  const lt = t - (u.t ?? 0);
  const [bx, by, bw, bh] = screenBox(u.target, T);
  const cx = bx + bw / 2;
  switch (u.kind) {
    case 'marquee': {
      const pad = 14;
      return <Marquee x={bx - pad} y={by - pad} w={bw + 2 * pad} h={bh + 2 * pad} t={lt} color={u.color ?? color} label={u.text} />;
    }
    case 'tag': return <Tag x={cx} y={Math.max(80, by - 70)} t={lt} text={u.text ?? '?'} mark={u.mark} markT={8} w={Math.max(148, (u.text ?? '').length * 34 + 60)} />;
    case 'toast': return <Toast x={Array.isArray(u.target) || u.target ? cx : 960} y={Array.isArray(u.target) || u.target ? Math.max(80, by - 50) : 160} t={lt} text={u.text ?? 'OK'} hold={u.hold ?? 26} color={u.color ?? UI.live} />;
    case 'float': return <FloatLabel x={cx} y={by} t={lt} text={u.text ?? '+1'} size={u.size ?? 72} color={u.color} />;
    case 'sparkle': return <Sparkle x={bx + bw * 0.85} y={by + bh * 0.1} t={lt} s={u.size ?? 1.3} />;
    case 'rings': return <FocusRings x={cx} y={by + bh / 2} t={lt} r0={Math.max(40, bw * 0.45)} color={u.color} />;
    case 'dizzy': return <DizzyStars x={cx} y={by} t={lt} rx={Math.max(60, bw * 0.8)} ry={Math.max(28, bw * 0.35)} />;
    case 'hud': return lt >= 0 ? <HudChip f={t} label={u.text ?? 'POWER'} icon={u.icon ?? 'dot'} /> : null;
    case 'dial': {
      if (lt < 0) return null;
      const c = u.count;
      const v = c ? av(c, t) : 0;
      const read = c ? `${Math.abs(v) >= 100 ? Math.round(v) : v.toFixed(1)}${u.unit ?? ''}` : u.readout ?? '';
      const tx = Array.isArray(u.target) ? u.target[0] : 1720;
      const ty = Array.isArray(u.target) ? u.target[1] : 150;
      return <Dial x={tx} y={ty} p={av(u.p, t, c ? clamp((t - c[2]) / Math.max(1, c[3] - c[2])) : 1)} readout={read} r={u.size ?? 84} />;
    }
    case 'gauge': {
      if (lt < 0) return null;
      const gx = Array.isArray(u.target) ? u.target[0] : 120;
      const gy = Array.isArray(u.target) ? u.target[1] : 960;
      return <Gauge x={gx} y={gy} p={av(u.p, t, 0.5)} label={u.text ?? ''} />;
    }
    case 'label': {
      if (lt < 0) return null;
      const s = backOut(clamp(lt / 6));
      const txt = u.text ?? '';
      const w = txt.length * 22 + 44;
      const lx = Array.isArray(u.target) && u.target.length === 2 ? u.target[0] : cx;
      const ly = Array.isArray(u.target) && u.target.length === 2 ? u.target[1] : Math.max(70, by - 40);
      return (
        <g transform={`translate(${lx} ${ly}) scale(${s})`}>
          <rect x={-w / 2} y={-30} width={w} height={52} rx={14} fill={UI.pill} opacity={0.72} />
          <text y={8} textAnchor="middle" fontFamily={FONT.ui} fontSize={32} fill={UI.text} letterSpacing={2}>{txt}</text>
        </g>
      );
    }
    case 'stamp': {
      const sx = Array.isArray(u.target) && u.target.length === 2 ? u.target[0] : u.target ? cx : 1460;
      const sy = Array.isArray(u.target) && u.target.length === 2 ? u.target[1] : u.target ? by + bh / 2 : 880;
      return <Stamp x={sx} y={sy} t={lt} text={u.text ?? "THAT'S REAL"} color={u.color} size={u.size ?? 64} />;
    }
    case 'arrow': {
      const a = Array.isArray(u.target) && u.target.length >= 4 ? u.target : [700, 540, 1100, 540];
      return lt >= 0 ? <Arrow x0={a[0]} y0={a[1]} x1={a[2]} y1={a[3]} t={lt} color={u.color ?? '#F6EFE3'} /> : null;
    }
    case 'question': {
      if (lt < 0) return null;
      const s = backOut(clamp(lt / 7));
      const bob = Math.sin(lt / 5) * 6;
      return (
        <text x={cx + bw * 0.35} y={by - 10 + bob} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={(u.size ?? 140) * s} fill="#FFE27A" stroke="#1A1230" strokeWidth={10} paintOrder="stroke">
          {u.text ?? '?'}
        </text>
      );
    }
    default:
      return null;
  }
};

export { easeOut };
