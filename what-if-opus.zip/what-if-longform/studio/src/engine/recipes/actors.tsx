import { clamp, lerp, easeOut, easeInOut } from '../anim';
import { basePose, poseAt, faceAt, walkPose, LOOKS, LEG_LEN, HEAD, joints, toWorld, Pose, Limb, Look, Expr } from '../rig';
import type { CastSpec, PoseName, Facing } from '../spec';
import type { Stage, Placement, StagePoint } from './stages';

// The actors: a cast spec becomes a pose at frame t. Pose names are written for the NEAR arm (the one toward camera),
// so a character facing left raises armL and one facing right raises armR, as the rig needs (traps.md: the raised
// hand is the near one). Every change of pose gets an overshoot and a settle; faces swap through a blink; everyone
// breathes, blinks on their own clock and lets their drawstrings sway, so nothing is ever a frozen frame.

type ArmKey = 'armL' | 'armR';
type Part = { near?: Limb; far?: Limb; tilt?: number; headTilt?: number; squash?: number; point?: boolean; legs?: Limb; drop?: number };

const POSES: Record<PoseName, Part> = {
  idle: { near: { a: 12, b: -8 }, far: { a: 10, b: -8 }, tilt: 0, headTilt: 0 },
  point: { near: { a: 95, b: -5 }, far: { a: 10, b: -8 }, headTilt: 3, point: true },
  cheer: { near: { a: 150, b: 10 }, far: { a: 150, b: 10 }, squash: -0.04 },
  shrug: { near: { a: 40, b: 80 }, far: { a: 40, b: 80 }, headTilt: -10 },
  think: { near: { a: 120, b: 110 }, far: { a: -10, b: -70 }, headTilt: 8 },
  shock: { near: { a: 60, b: 40 }, far: { a: 60, b: 40 }, tilt: -5 },
  wave: { near: { a: 150, b: 20 }, far: { a: 10, b: -8 } },
  reach: { near: { a: 80, b: 0 }, far: { a: 14, b: -6 }, tilt: 6 },
  lean: { near: { a: 160, b: 120 }, far: { a: 160, b: 120 }, tilt: -11, headTilt: -6 },
  present: { near: { a: 70, b: -20 }, far: { a: 30, b: 10 }, headTilt: 4 },
  fist: { near: { a: 30, b: 110 }, far: { a: 30, b: 110 }, tilt: 3 },
  scared: { near: { a: 50, b: 90 }, far: { a: 50, b: 90 }, tilt: -6, headTilt: 6, squash: 0.04 },
  sad: { near: { a: 6, b: -4 }, far: { a: 6, b: -4 }, tilt: 4, headTilt: 12 },
  hold: { near: { a: 50, b: 60 }, far: { a: 40, b: 60 } },
  stop: { near: { a: 90, b: -60 }, far: { a: 10, b: -8 }, tilt: -3 },
  sit: { near: { a: 30, b: 40 }, far: { a: 30, b: 40 }, legs: { a: 80, b: -80 }, drop: 46 },
};

const EXPR_FOR: Partial<Record<PoseName, Expr>> = { cheer: 'happy', shock: 'shock', scared: 'worried', sad: 'worried', lean: 'smug', think: 'worried', fist: 'cool' };

export type Performer = {
  spec: CastSpec;
  pose: Pose;
  place: Placement;
  look: Look;
  near: ArmKey;
  depth: number;
  rim: string;
  act: PoseName;
};

const yawOf = (f: Facing) => (f === 'right' ? 0.45 : f === 'left' ? -0.45 : 0.08);
const eyesOf = (f: Facing) => (f === 'right' ? 0.6 : f === 'left' ? -0.6 : 0);

/** The pose a part asks for, turned into rig fields for this facing. */
const partPose = (p: Part, near: ArmKey, dir: 1 | -1): Partial<Pose> => {
  const far: ArmKey = near === 'armR' ? 'armL' : 'armR';
  const o: Partial<Pose> = {};
  if (p.near) o[near] = p.near;
  if (p.far) o[far] = p.far;
  if (p.tilt !== undefined) o.tilt = p.tilt * dir;
  if (p.headTilt !== undefined) o.headTilt = p.headTilt;
  o.squash = p.squash ?? 0;
  if (p.legs) {
    o.legL = p.legs;
    o.legR = p.legs;
  } else {
    o.legL = { a: 5, b: 0 };
    o.legR = { a: -5, b: 0 };
  }
  return o;
};

const over = (a: Limb | undefined, b: Limb | undefined): Limb | undefined => (a && b ? { a: a.a + Math.sign(a.a - b.a) * 7, b: a.b + Math.sign(a.b - b.b) * 4 } : a);

/** Where a cast member stands at frame t (walking between two points if they walk). */
export const placeAt = (stage: Stage, c: CastSpec, i: number, n: number, t: number, len: number): { place: Placement; walking: boolean; phase: number; dir: 1 | -1 } => {
  const p0 = stage.point(c.at, i, n);
  if (!c.walk) return { place: stage.place(p0), walking: false, phase: 0, dir: 1 };
  const p1 = stage.point(c.walk.to, i, n);
  const from = c.walk.from ?? 0;
  const dur = Math.max(6, c.walk.dur ?? Math.max(12, (len - from) * 0.8));
  const k = clamp((t - from) / dur);
  let pt: StagePoint;
  let dir: 1 | -1 = 1;
  if (p0.kind === 'room' && p1.kind === 'room') {
    pt = { kind: 'room', u: lerp(p0.u, p1.u, k), w: lerp(p0.w, p1.w, k) };
    dir = p1.u >= p0.u ? 1 : -1;
  } else {
    const x0 = p0.kind === 'flat' ? p0.x : 960;
    const x1 = p1.kind === 'flat' ? p1.x : 960;
    pt = { kind: 'flat', x: lerp(x0, x1, k) };
    dir = x1 >= x0 ? 1 : -1;
  }
  return { place: stage.place(pt), walking: t >= from && t < from + dur, phase: (t - from) * 0.6, dir };
};

export const actorAt = (stage: Stage, c: CastSpec, i: number, n: number, t: number, len: number, red: number, powerColor: string): Performer => {
  const { place: pl0, walking, phase, dir } = placeAt(stage, c, i, n, t, len);
  const look = LOOKS[c.who] ?? LOOKS.pipHood;
  const k = c.scale ?? 1;
  const scale = pl0.scale * k;
  const groundY = pl0.y + LEG_LEN * pl0.scale;
  const place: Placement = { ...pl0, scale, y: groundY - LEG_LEN * scale };
  const facing: Facing = c.face ?? (c.walk ? (dir > 0 ? 'right' : 'left') : place.x <= 960 ? 'right' : 'left');
  const yaw = yawOf(facing);
  const near: ArmKey = yaw >= 0 ? 'armR' : 'armL';
  const fdir: 1 | -1 = yaw >= 0 ? 1 : -1;
  const acts = c.act && c.act.length ? c.act : ([[0, 'idle']] as [number, PoseName][]);
  const base: Partial<Pose> = { x: place.x, y: place.y, scale, yaw, facing: fdir, look: eyesOf(facing) };
  const keys: { f: number; p: Partial<Pose>; ease?: (x: number) => number }[] = [];
  let prev: Partial<Pose> | null = null;
  acts.forEach(([f, name], j) => {
    const part = POSES[name] ?? POSES.idle;
    const target = { ...partPose(part, near, fdir), ...(part.drop ? { y: place.y + part.drop * scale } : { y: place.y }) };
    if (j === 0) keys.push({ f: Math.min(0, f), p: { ...base, ...target } });
    else {
      keys.push({ f, p: {} });
      const os: Partial<Pose> = { ...target, [near]: over(target[near] as Limb | undefined, prev?.[near] as Limb | undefined) };
      keys.push({ f: f + 5, p: os, ease: easeOut });
      keys.push({ f: f + 9, p: target, ease: easeInOut });
    }
    prev = target;
  });
  let pose = poseAt(t, keys as never);
  let act: PoseName = acts[0][1];
  for (const [f, name] of acts) if (t >= f) act = name;
  const nearHand = near === 'armR' ? 'handR' : 'handL';
  if (POSES[act]?.point) pose = { ...pose, [nearHand]: 'point' };
  if (act === 'wave') {
    const L = pose[near];
    pose = { ...pose, [near]: { a: L.a + Math.sin(t / 2.6) * 16, b: L.b } };
  }
  if (walking) {
    pose = { ...walkPose(place.x, phase, () => groundY, scale, {}, dir), look: dir * 0.5 };
  }
  // life: breathing, a drawstring sway, a blink on each character's own clock
  const firstExpr: Expr = EXPR_FOR[acts[0][1]] ?? 'neutral';
  const face = faceAt(t, c.expr && c.expr.length ? c.expr : [[0, firstExpr]]);
  const period = 88 + i * 17;
  const autoBlink = (t + i * 37) % period < 2 ? 1 : 0;
  pose = {
    ...pose,
    expr: face.expr,
    blink: Math.max(face.blink, autoBlink),
    y: pose.y + (walking ? 0 : Math.sin(t / 16 + i * 1.3) * 1.6 * scale),
    sway: pose.sway + Math.sin(t / 18 + i) * 4,
  };
  if (c.glint && t >= c.glint[0]) pose = { ...pose, glint: c.glint[1] * clamp((t - c.glint[0]) / 6), glintColor: c.glintColor ?? powerColor };
  const rimFor: Record<string, string> = { warm: 'rimR', cool: 'rimBlue', red: 'rimRed', left: 'rimL', right: 'rimR' };
  const rim = red > 0.5 ? 'rimRed' : c.rim ? rimFor[c.rim] : stage.rim;
  return { spec: c, pose, place, look, near, depth: place.depth, rim, act };
};

/** Where the near hand is in world space, for a prop held in it. */
export const handOf = (a: Performer) => {
  const j = joints(a.pose);
  return toWorld(a.pose, j[a.near].end);
};
/** The head's centre in world space. */
export const headOf = (a: Performer) => ({ x: a.pose.x + a.pose.yaw * 30 * a.pose.scale * 0.2, y: a.pose.y + HEAD.y * a.pose.scale });
/** A box round the whole character in world space: [x, y, w, h]. */
export const boxOf = (a: Performer): [number, number, number, number] => {
  const s = a.pose.scale;
  return [a.pose.x - 85 * s, a.pose.y - 248 * s, 170 * s, 400 * s];
};
export { basePose };
