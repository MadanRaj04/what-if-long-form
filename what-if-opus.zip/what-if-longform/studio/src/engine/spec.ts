// The JSON shapes a long-form episode is written in. Free models only ever write these (outline.json and each
// chapter's chapter.json); the recipe engine (recipes.tsx) turns every shot spec into a drawn, animated shot, so no
// TypeScript is needed for an episode. A shot can still opt out with "custom": true and a component in shots.tsx.
import type { CastName, Expr } from './rig';

/** A value that can animate: a plain number, or [from, to, startFrame, endFrame] on the shot's own clock. */
export type Anim = number | [number, number, number, number];

export type SetName =
  | 'study' | 'studyNight' | 'kitchen' | 'bedroom' | 'classroom' | 'stairwell' | 'rooftop' | 'office' | 'street' | 'schematic' | 'sky';

export type Slot = 'left' | 'center' | 'right' | 'farLeft' | 'farRight' | 'bed' | 'landing' | 'stairs' | 'bottom';
/** Where someone or something is: a named slot, [u, w] on a room's floor (0..1 each), or [x] / [x, y] in world units on flat sets. */
export type At = Slot | number[];

export type PoseName =
  | 'idle' | 'point' | 'cheer' | 'shrug' | 'think' | 'shock' | 'wave' | 'reach' | 'lean' | 'present' | 'fist' | 'scared' | 'sad' | 'hold' | 'stop' | 'sit';

export type Facing = 'left' | 'right' | 'camera' | 'away';

export type CastSpec = {
  who: CastName;
  at?: At;
  face?: Facing;
  /** pose keys on the shot clock: [[0, "idle"], [8, "point"]]. Each change gets anticipation, overshoot and settle. */
  act?: [number, PoseName][];
  /** expression keys: [[0, "neutral"], [10, "smug"]]. Swaps happen through a blink. */
  expr?: [number, Expr][];
  /** walk from `at` to `to`, starting at frame `from` for `dur` frames. */
  walk?: { to: At; from?: number; dur?: number };
  /** size multiplier on top of the set's own scale (a child: 0.72) */
  scale?: number;
  /** the power lights the eyes: [startFrame, strength 0..1] */
  glint?: [number, number];
  glintColor?: string;
  /** appears with the power's pop (PasteIn) at this frame */
  paste?: number;
  /** blurred, dark, in front of camera (over-the-shoulder figure) */
  blur?: boolean;
  rim?: 'warm' | 'cool' | 'red' | 'left' | 'right';
  /** stops with the world when the shot has "freeze" (everyone the power pauses) */
  frozen?: boolean;
};

export type PropKind =
  | 'cookie' | 'cookieTop' | 'cookies' | 'mug' | 'plate' | 'plateTop' | 'paper' | 'papers' | 'phone' | 'book' | 'books'
  | 'clock' | 'calendar' | 'pizza' | 'pizzaBox' | 'ball' | 'cat' | 'laptop' | 'cash' | 'envelope' | 'badge' | 'glass' | 'box';

export type PropSpec = {
  kind: PropKind;
  /** a set anchor ("desk", "island", "nightstand", "deck", "floor", "hand"), [x, y] in world units, or [x, y] on screen for inserts */
  at?: string | number[];
  /** with at "hand": which cast member's near hand holds it (0 = first) */
  hand?: number;
  s?: number;
  rot?: Anim;
  /** appears at this frame (a quick pop) */
  t?: number;
  /** appears with the power's pop and ring at this frame */
  paste?: number;
  /** falls into place at this frame */
  drop?: number;
  n?: number;
  text?: string;
  on?: Anim;
  bite?: Anim;
  fill?: Anim;
  turn?: Anim;
  done?: boolean;
  grade?: string;
  mood?: 'sleep' | 'alert' | 'peek';
  caller?: string;
  buzz?: Anim;
  /** draw behind the characters (default: in front, after the desk or island) */
  back?: boolean;
  /** a ghosted, flickering copy (an unstable power) */
  glitch?: boolean;
  /** keeps moving when the shot has "freeze" (props held by the hero are live anyway) */
  live?: boolean;
};

export type UIKind =
  | 'marquee' | 'tag' | 'toast' | 'float' | 'sparkle' | 'rings' | 'dizzy' | 'hud' | 'dial' | 'gauge' | 'label' | 'stamp' | 'arrow' | 'question';

export type UISpec = {
  kind: UIKind;
  t?: number;
  /** what it points at: "cast0", "cast1", "prop0", "head0", or a screen box [x, y, w, h] / point [x, y] */
  target?: string | number[];
  text?: string;
  mark?: 'x' | 'check';
  color?: string;
  icon?: 'rewind' | 'pause' | 'copy' | 'paste' | 'dot' | 'skip';
  /** dial / gauge fill: [from, to, startFrame, endFrame] */
  p?: Anim;
  readout?: string;
  /** dial counts a number: [from, to, startFrame, endFrame] shown with `unit` */
  count?: [number, number, number, number];
  unit?: string;
  size?: number;
  hold?: number;
};

export type DiagramLayout = 'equation' | 'count' | 'icons' | 'compare' | 'timeline' | 'list';
export type IconName = 'tower' | 'wind' | 'solar' | 'dam' | 'factory' | 'person' | 'clock' | 'bolt' | 'heart' | 'eye' | 'globe' | 'cookie' | 'coin' | 'brain' | 'sun' | 'moon' | 'house' | 'car' | 'phone' | 'drop';

export type DiagramSpec = {
  layout: DiagramLayout;
  heading?: string;
  /** equation: up to 3 items joined by arrows. list / timeline: up to 6. */
  items?: { text: string; sub?: string; icon?: IconName }[];
  count?: { to: number; from?: number; label?: string; suffix?: string; format?: 'comma' | 'short' | 'time' | 'decimal'; dur?: number; t?: number };
  icons?: { icon: IconName; n: number; label?: string; lit?: number };
  bars?: { label: string; value: number; display?: string }[];
  dial?: { to: number; unit?: string; label?: string; t?: number; dur?: number };
  /** "THAT'S REAL" style stamp that lands at `stampT` */
  stamp?: string;
  stampT?: number;
};

export type CameraSpec = {
  move?: 'static' | 'pushIn' | 'pullOut' | 'panLeft' | 'panRight' | 'handheld' | 'follow' | 'tiltUp' | 'crashZoom';
  /** how strong the move is (1 = default) */
  amount?: number;
  /** zoom multiplier on the recipe's framing */
  zoom?: number;
  /** nudge the frame in world units */
  dx?: number;
  dy?: number;
  /** tilt the frame a few degrees (a dutch angle for unease) */
  roll?: number;
};

export type Recipe =
  | 'wide' | 'medium' | 'closeup' | 'xcu' | 'twoshot' | 'ots' | 'lowangle' | 'insert' | 'topdown' | 'title' | 'chapter' | 'schematic' | 'walk' | 'reveal';

export type ShotSpec = {
  id: string;
  recipe: Recipe;
  set?: SetName;
  /** the words this shot starts on (the first 2 to 5 words of its line, as spoken) */
  say?: string;
  /** or a cue: a word ("cookie", "paste#2"), "+18" frames after the previous cut, "s:4.2", "f:126" */
  at?: string;
  /** a power look while this shot runs (defined in outline.json "looks") */
  look?: string;
  /** the frame of the shot's own clock the storyboard shows */
  key?: number;
  note?: string;
  cast?: CastSpec[];
  props?: PropSpec[];
  ui?: UISpec[];
  camera?: CameraSpec;
  /** set options: anything the set takes (clock, lamp, board, crossed, sunY, blackout, lightsOut, desk, island, cityLit, low...) */
  opts?: Record<string, unknown>;
  mood?: { red?: Anim; veil?: number; dim?: number };
  /** title recipe: the two lines; chapter recipe: [part label, chapter title] */
  title?: string[];
  accent?: string;
  diagram?: DiagramSpec;
  /** insert / topdown: the surface and a character's arm reaching in */
  surface?: 'wood' | 'stone' | 'desk' | 'paper';
  edge?: number;
  arm?: { who?: CastName; from?: 'left' | 'right' | 'top' | 'bottom'; keys: number[][]; point?: boolean };
  /** a dark blurred shape near the camera for depth: "left", "right", "bottom" or "both" */
  foreground?: 'left' | 'right' | 'bottom' | 'both' | 'none';
  /** the world stops at this frame of the shot's clock: the set, props and "frozen" cast hold still while everyone
   * else keeps moving (a time-stop power). 0 = frozen from the first frame. */
  freeze?: number;
  /** the automatic punch-in may not split this shot */
  punch?: boolean;
  /** the shot is drawn by hand in shots.tsx (export const <id>) */
  custom?: boolean;
};

export type LookSpec = {
  saturate?: number;
  hue?: number;
  brightness?: number;
  contrast?: number;
  jitter?: number;
  chip?: { label: string; icon?: 'rewind' | 'pause' | 'copy' | 'paste' | 'dot' | 'skip' };
  tape?: boolean;
  dial?: { from: number; to: number; unit?: string };
  tint?: string;
  tintO?: number;
  frame?: boolean;
};

export type ThumbSpec = {
  set?: SetName;
  who?: CastName;
  expr?: Expr;
  lines?: string[];
  accent?: string;
  glint?: number;
  glintColor?: string;
  prop?: PropKind;
  red?: number;
};

export type ChapterSpec = {
  n: number;
  title: string;
  shots: ShotSpec[];
};

export type OutlineSpec = {
  id: string;
  slug: string;
  looks?: Record<string, LookSpec>;
  thumbnail?: ThumbSpec;
  power?: { color?: string };
};
