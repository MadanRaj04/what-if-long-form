import React from 'react';
import { rnd } from '../anim';
import { DuskSky, Sun, Skyline, NightSky, Stars, Moon } from '../kit';
import { S3 } from '../room';
import { Glow, LightVeil, Dust } from '../light';

// The street at dusk, side-on: the sky and a far skyline, a row of shops across the road (lit windows, an awning, a
// café), the road with its lane marks, and the near pavement where characters stand (feet at y 940, STREET_GROUND).
// Streetlamps at x 300 and 1560, a bench, a bus-stop sign, a hydrant. `night` swaps the dusk for stars and the moon,
// `red` floods it for the turn, `blackout` (0..1) turns the shop lights off from the left, `traffic` runs cars.

export const STREET_GROUND = 940;

const Shopfronts: React.FC<{ blackout: number; red: number }> = ({ blackout, red }) => {
  const out: React.ReactNode[] = [];
  const cols = ['#3E2E48', '#352A40', '#40304A', '#2E2A3E'];
  let x = -420;
  let i = 0;
  while (x < 2340) {
    const w = 220 + rnd(71, i) * 160;
    const h = 260 + rnd(72, i) * 240;
    const top = 770 - h;
    const off = blackout > 0 && (x + 420) / 2760 < blackout * 1.15 - rnd(73, i) * 0.15;
    out.push(<rect key={`b${i}`} x={x} y={top} width={w + 1} height={h} fill={red > 0.5 ? '#2A0E18' : cols[i % cols.length]} />);
    // upper windows
    for (let r = 0; r < Math.floor((h - 130) / 64); r++) {
      for (let c = 0; c < Math.floor((w - 30) / 56); c++) {
        const q = rnd(74, i * 31 + r * 7 + c);
        if (q > 0.45) out.push(<rect key={`w${i}-${r}-${c}`} x={x + 22 + c * 56} y={top + 24 + r * 64} width={30} height={38} fill={off ? '#1C1626' : q > 0.9 ? '#9FC0FF' : '#FFC27A'} opacity={off ? 1 : 0.55 + q * 0.4} />);
      }
    }
    // the shop at street level: a lit window and an awning
    const lit = !off;
    out.push(<rect key={`s${i}`} x={x + 16} y={680} width={w - 32} height={86} fill={lit ? '#FFC98A' : '#1E1828'} opacity={lit ? 0.75 : 1} />);
    if (lit) out.push(<rect key={`sg${i}`} x={x + 16} y={680} width={w - 32} height={86} fill="url(#g3fadeDown)" opacity={0.5} />);
    out.push(<path key={`aw${i}`} d={`M ${x + 8} 680 L ${x + w - 8} 680 L ${x + w + 6} 650 L ${x - 6} 650 Z`} fill={['#8A3A3E', '#3E6A6A', '#8A6A3A', '#5A3E6A'][i % 4]} />);
    if (lit) out.push(<Glow key={`gl${i}`} x={x + w / 2} y={724} r={w * 0.7} o={0.35} />);
    x += w + 4;
    i++;
  }
  return <g>{out}</g>;
};

export const Street: React.FC<{ t: number; id?: string; night?: boolean; red?: number; blackout?: number; traffic?: boolean; veil?: number }> = ({
  t, id = 'st', night = false, red = 0, blackout = 0, traffic = true, veil = 0.42,
}) => {
  const lamps = [300, 1560];
  const lampOn = (x: number) => !(blackout > 0 && (x + 420) / 2760 < blackout * 1.15 - 0.05);
  return (
    <g>
      {night ? (
        <g>
          <NightSky id={`${id}sky`} horizonY={700} />
          <Stars seed={9} x0={-400} y0={-400} w={2720} h={900} t={t} n={90} />
          <Moon x={1420} y={220} r={46} />
        </g>
      ) : (
        <g>
          <DuskSky id={`${id}sky`} horizonY={700} red={red} />
          <Sun x={1180} y={560} r={120} t={t} red={red} />
        </g>
      )}
      <Skyline y={640} seed={17} color={red > 0.5 ? '#3A1222' : night ? '#141634' : '#4A3260'} h={220} />
      <Shopfronts blackout={blackout} red={red} />
      {/* far pavement, road, near kerb and pavement */}
      <rect x={-400} y={766} width={2720} height={18} fill="#3A3240" />
      <rect x={-400} y={784} width={2720} height={100} fill={red > 0.5 ? '#160810' : '#1E1A24'} />
      {Array.from({ length: 16 }).map((_, i) => (
        <rect key={`ln${i}`} x={-380 + i * 180} y={830} width={90} height={7} fill="#E9D9A0" opacity={0.55} />
      ))}
      {traffic
        ? [0, 1].map((k) => {
            const dir = k ? -1 : 1;
            const cx = ((t * 9 * dir + k * 1300) % 3000 + 3000) % 3000 - 500;
            const y = k ? 800 : 846;
            return (
              <g key={`car${k}`} transform={`translate(${cx} ${y}) scale(${dir} 1)`}>
                <rect x={-110} y={-34} width={220} height={40} rx={14} fill={k ? '#3E5A7A' : '#8A3A3E'} />
                <path d="M -60 -34 L -40 -62 L 50 -62 L 72 -34 Z" fill={k ? '#2E4A6A' : '#6A2A2E'} />
                <circle cx={-66} cy={8} r={16} fill="#111" />
                <circle cx={66} cy={8} r={16} fill="#111" />
                <circle cx={106} cy={-18} r={7} fill="#FFE7B8" />
                <Glow x={130} y={-18} r={90} o={0.5} />
              </g>
            );
          })
        : null}
      <rect x={-400} y={884} width={2720} height={14} fill="#5A5262" />
      <rect x={-400} y={884} width={2720} height={3} fill={S3.warm} opacity={0.4} />
      <rect x={-400} y={898} width={2720} height={600} fill={red > 0.5 ? '#12060C' : '#2A2430'} />
      {Array.from({ length: 22 }).map((_, i) => (
        <path key={`ps${i}`} d={`M ${-400 + i * 130} 898 L ${-460 + i * 150} 1500`} stroke="#211C26" strokeWidth={3} />
      ))}
      {/* the bench, a bus-stop sign and a hydrant */}
      <g>
        <ellipse cx={1200} cy={946} rx={130} ry={10} fill="#000" opacity={0.35} />
        <rect x={1080} y={880} width={240} height={14} rx={4} fill="#6A4A3E" />
        <rect x={1080} y={846} width={240} height={12} rx={4} fill="#6A4A3E" />
        <path d="M 1100 894 L 1096 944 M 1300 894 L 1304 944" stroke="#1E1A22" strokeWidth={8} />
        <rect x={1080} y={846} width={240} height={3} fill={S3.warm} opacity={0.5} />
      </g>
      <path d="M 820 940 L 820 700" stroke="#2A2632" strokeWidth={8} />
      <rect x={784} y={690} width={72} height={46} rx={6} fill="#3E7A9A" />
      <rect x={796} y={702} width={48} height={8} fill="#F6EFE3" opacity={0.8} />
      <path d="M 620 940 L 620 896 Q 620 880 636 880 L 652 880 Q 668 880 668 896 L 668 940 Z" fill="#B0463A" />
      <rect x={612} y={900} width={64} height={8} rx={3} fill="#8A2E26" />
      {/* the streetlamps */}
      {lamps.map((x, i) => {
        const on = lampOn(x);
        return (
          <g key={`lp${i}`}>
            <path d={`M ${x} 944 L ${x} 430 Q ${x} 400 ${x + 40} 400 L ${x + 70} 400`} stroke="#15131A" strokeWidth={12} fill="none" />
            <path d={`M ${x + 46} 396 L ${x + 100} 396 L ${x + 90} 420 L ${x + 56} 420 Z`} fill={on ? '#FFE2B0' : '#3A3440'} />
            {on ? <Glow x={x + 73} y={424} r={260} o={0.6} /> : null}
            {on ? <path d={`M ${x + 58} 420 L ${x + 88} 420 L ${x + 260} 944 L ${x - 110} 944 Z`} fill="url(#g3cone)" opacity={0.35} style={{ mixBlendMode: 'screen' }} /> : null}
          </g>
        );
      })}
      <LightVeil id={`${id}veil`} lights={[[373, 600, 460], [1633, 600, 460], [960, 720, 900]]} o={veil} />
      {lamps.map((x, i) => (lampOn(x) ? <Glow key={`lg${i}`} x={x + 73} y={424} r={150} o={0.45} /> : null))}
      <Dust t={t} seed={51} x0={1500} y0={430} w={300} h={480} n={16} o={0.4} />
      {red > 0 ? <rect x={-400} y={-400} width={2720} height={1900} fill="#16000A" opacity={0.4 * red} /> : null}
    </g>
  );
};
