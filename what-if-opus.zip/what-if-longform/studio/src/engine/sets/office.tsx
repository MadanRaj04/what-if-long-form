import React from 'react';
import { makeRoom, Box } from '../room';
import { RoomShell, BackWindow, WallFrame, WallClock, FloorShadow, FloorPlant } from '../furnish';
import { Glow, Cone, LightVeil, Dust } from '../light';

// The office at night, built with the room kit: where "someone powerful notices" (beat 5). A wide window with blinds
// onto the lit city, filing cabinets on the left wall, framed certificates, a big desk in the middle with a green
// banker's lamp, a phone and a file stamped CONFIDENTIAL. The lamp is the main light; the city answers it.
// Someone behind the desk stands at w 0.4 (stand(OFFICE, u, 0.4)); a visitor in front at w 0.72. The desk is the near
// layer at w 0.48 to 0.6: draw <OfficeDesk /> after anyone behind it and before anyone in front.

export const OFFICE = makeRoom({ x: 960, y: 500 }, { x0: 520, x1: 1400, y0: 330, y1: 745 }, 3.4);
const O = { wall: '#2C3440', side: '#232A34', floor: '#262229', ceiling: '#171B22', lines: '#1D1A20' };
export const OFFICE_LAMP = (() => {
  const p = OFFICE.P(0.66, 0.66, 0.5);
  return { x: p.x, y: p.y - 70 };
})();

export const Office: React.FC<{ t: number; id?: string; veil?: number; red?: number; lamp?: number }> = ({ t, id = 'ofc', veil = 0.5, red = 0, lamp = 1 }) => {
  const r = OFFICE;
  const { P, Q } = r;
  const win = { x0: 690, x1: 1230, y0: 372, y1: 590 };
  return (
    <g>
      <RoomShell r={r} id={id} floor="tiles" wall={O.wall} side={O.side} floorC={O.floor} ceiling={O.ceiling} lines={O.lines} />
      {/* the window onto the city at night, with blinds half drawn */}
      <BackWindow r={r} id={`${id}w`} t={t} x0={win.x0} x1={win.x1} y0={win.y0} y1={win.y1} sun={{ x: 1130, y: 410 }} cols={3} curtains={false} night />
      {Array.from({ length: 9 }).map((_, i) => (
        <rect key={`bl${i}`} x={win.x0 - 6} y={win.y0 + i * 12} width={win.x1 - win.x0 + 12} height={7} fill="#1A1E26" opacity={0.92} />
      ))}
      <rect x={win.x0 - 10} y={win.y0 - 18} width={win.x1 - win.x0 + 20} height={10} rx={3} fill="#12151B" />
      {/* framed certificates and a clock */}
      <WallFrame x={560} y={400} w={90} h={70} art={2} />
      <WallFrame x={1268} y={392} w={96} h={124} art={1} />
      <WallClock x={1316} y={570} r={22} t={t} />
      {/* filing cabinets on the left wall */}
      <FloorShadow r={r} u={[0, 0.08]} w={[0.08, 0.46]} o={0.4} />
      <Box r={r} u={[0, 0.07]} v={[0.42, 1]} w={[0.08, 0.26]} front="#3A414C" side="#2C323B" top="#4A515C" />
      <Box r={r} u={[0, 0.07]} v={[0.42, 1]} w={[0.27, 0.45]} front="#3A414C" side="#2C323B" top="#4A515C" />
      {[0.55, 0.7, 0.85].map((v, i) =>
        [0.17, 0.36].map((w, j) => {
          const h = P(0.07, v, w);
          return <rect key={`fh${i}${j}`} x={h.x - 10} y={h.y - 3} width={20} height={6} rx={3} fill="#9AA2AE" />;
        }),
      )}
      {/* a tall plant in the far right corner and a coat stand */}
      <FloorPlant r={r} u={0.93} w={0.12} size={1.1} />
      {(() => {
        const b = P(0.84, 1, 0.08);
        return (
          <g>
            <path d={`M ${b.x} ${b.y} L ${b.x} ${b.y - 220}`} stroke="#15181E" strokeWidth={8} />
            <path d={`M ${b.x - 30} ${b.y} L ${b.x + 30} ${b.y}`} stroke="#15181E" strokeWidth={8} strokeLinecap="round" />
            <path d={`M ${b.x - 4} ${b.y - 200} Q ${b.x - 40} ${b.y - 150} ${b.x - 28} ${b.y - 60} L ${b.x + 22} ${b.y - 60} Q ${b.x + 30} ${b.y - 150} ${b.x + 4} ${b.y - 200} Z`} fill="#3A2E2A" />
          </g>
        );
      })()}
      {/* the desk chair behind the desk */}
      {(() => {
        const c = P(0.52, 0.62, 0.36);
        const s = r.s(0.36);
        return (
          <g>
            <rect x={c.x - 70 * s} y={c.y - 120 * s} width={140 * s} height={170 * s} rx={22 * s} fill="#1A1C22" />
            <rect x={c.x - 70 * s} y={c.y - 120 * s} width={140 * s} height={8 * s} rx={4} fill="#FFC98A" opacity={0.25} />
          </g>
        );
      })()}
      <LightVeil
        id={`${id}veil`}
        lights={[
          [OFFICE_LAMP.x, OFFICE_LAMP.y + 40, 420 * (0.3 + 0.7 * lamp)],
          [(win.x0 + win.x1) / 2, 480, 360],
          [960, 940, 360],
        ]}
        o={veil}
      />
      <circle cx={1130} cy={410} r={280} fill="url(#kitMoonBloom)" opacity={0.22} />
      <Dust t={t} seed={41} x0={OFFICE_LAMP.x - 220} y0={OFFICE_LAMP.y - 60} w={440} h={300} n={18} o={0.4 * lamp} />
      {red > 0 ? <rect x={-1500} y={-1500} width={5000} height={4500} fill="#3A0010" opacity={0.4 * red} style={{ mixBlendMode: 'multiply' }} /> : null}
    </g>
  );
};

/** The desk: the near layer. A wide top, front panel, a green lamp, a phone, a file and a nameplate. */
export const OfficeDesk: React.FC<{ lamp?: number; file?: boolean }> = ({ lamp = 1, file = true }) => {
  const r = OFFICE;
  const { P } = r;
  const top = 0.66;
  const lb = P(0.66, top, 0.5);
  const ph = P(0.36, top, 0.52);
  const fl = P(0.5, top, 0.54);
  return (
    <g>
      <FloorShadow r={r} u={[0.24, 0.78]} w={[0.46, 0.62]} o={0.45} />
      <Box r={r} u={[0.24, 0.76]} v={[top, 1]} w={[0.48, 0.6]} front="#3E2A24" side="#2E1F1B" top="#5A3E34" rim />
      <rect x={P(0.26, 0.72, 0.6).x} y={P(0.26, 0.72, 0.6).y} width={P(0.74, 0.72, 0.6).x - P(0.26, 0.72, 0.6).x} height={6} fill="#2A1C18" />
      {/* the banker's lamp */}
      <ellipse cx={lb.x} cy={lb.y - 2} rx={26} ry={7} fill="#B89A5A" />
      <path d={`M ${lb.x} ${lb.y - 4} L ${lb.x} ${lb.y - 60}`} stroke="#B89A5A" strokeWidth={6} />
      <path d={`M ${OFFICE_LAMP.x - 50} ${OFFICE_LAMP.y + 6} Q ${OFFICE_LAMP.x} ${OFFICE_LAMP.y - 34} ${OFFICE_LAMP.x + 50} ${OFFICE_LAMP.y + 6} Z`} fill={lamp > 0.3 ? '#2F7A52' : '#1E3A2A'} />
      <path d={`M ${OFFICE_LAMP.x - 50} ${OFFICE_LAMP.y + 6} L ${OFFICE_LAMP.x + 50} ${OFFICE_LAMP.y + 6}`} stroke="#FFE7B8" strokeWidth={4} opacity={lamp} />
      <Cone d={`M ${OFFICE_LAMP.x - 48} ${OFFICE_LAMP.y + 6} L ${OFFICE_LAMP.x + 48} ${OFFICE_LAMP.y + 6} L ${OFFICE_LAMP.x + 170} ${lb.y + 6} L ${OFFICE_LAMP.x - 170} ${lb.y + 6} Z`} o={0.5 * lamp} />
      <Glow x={OFFICE_LAMP.x} y={OFFICE_LAMP.y + 10} r={260} o={0.55 * lamp} />
      {/* a desk phone */}
      <rect x={ph.x - 40} y={ph.y - 26} width={80} height={24} rx={6} fill="#1A1C22" />
      <path d={`M ${ph.x - 44} ${ph.y - 30} Q ${ph.x} ${ph.y - 52} ${ph.x + 44} ${ph.y - 30}`} stroke="#1A1C22" strokeWidth={14} strokeLinecap="round" fill="none" />
      {/* the file */}
      {file ? (
        <g transform={`translate(${fl.x} ${fl.y - 4}) rotate(-6)`}>
          <rect x={-70} y={-16} width={140} height={16} fill="#C9A86A" />
          <rect x={-46} y={-14} width={92} height={10} fill="#A8323E" opacity={0.85} />
        </g>
      ) : null}
    </g>
  );
};
