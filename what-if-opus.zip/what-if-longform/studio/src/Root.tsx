import React from 'react';
import { Composition } from 'remotion';
import './engine/fonts';
import { STUDIO } from './studio.config';
import { EPISODES, THUMBS } from './episodes';
import { CastSheet } from './CastSheet';

// Every chapter gets two compositions: <Id>ChNN (the film) and <Id>ChNNBoard (one frame per shot, at its key frame,
// for the storyboard). Each long episode also gets <Id>Thumb (its thumbnail). Cast renders the cast sheet.
// The list comes from src/episodes/index.ts, which scripts/scaffold.py writes.
//   npx remotion studio src/index.ts --port 3430
export const Root: React.FC = () => {
  const common = { width: STUDIO.width, height: STUDIO.height, fps: STUDIO.fps };
  return (
    <>
      {EPISODES.map((e) => (
        <React.Fragment key={e.id}>
          <Composition id={e.id} component={e.Main} durationInFrames={Math.max(1, e.total)} {...common} />
          <Composition id={`${e.id}Board`} component={e.Board} durationInFrames={Math.max(1, e.shotCount)} {...common} />
        </React.Fragment>
      ))}
      {THUMBS.map((t) => (
        <Composition key={t.id} id={t.id} component={t.Comp} durationInFrames={1} {...common} />
      ))}
      <Composition id="Cast" component={CastSheet} durationInFrames={1} {...common} />
    </>
  );
};
